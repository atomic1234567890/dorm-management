package com.dorm.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 违纪记录
 */
@Data
public class Violation {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long studentId;

    private String type;

    private String description;

    /** 扣分 */
    private Integer points;

    private LocalDate recordDate;

    private Long recorderId;

    private LocalDateTime createTime;

    @TableField(exist = false)
    private String studentName;

    @TableField(exist = false)
    private String studentNo;

    @TableField(exist = false)
    private String className;

    @TableField(exist = false)
    private String roomNo;

    @TableField(exist = false)
    private String buildingName;

    @TableField(exist = false)
    private Long buildingId;

    @TableField(exist = false)
    private String recorderName;
}
