package com.dorm.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.dorm.common.RequireRole;
import com.dorm.common.Result;
import com.dorm.dto.HandleDTO;
import com.dorm.entity.AdjustRequest;
import com.dorm.service.AdjustService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 调宿申请
 */
@RestController
@RequestMapping("/api/adjust-requests")
@RequiredArgsConstructor
public class AdjustController {

    private final AdjustService adjustService;

    @GetMapping
    public Result<IPage<AdjustRequest>> page(@RequestParam(defaultValue = "1") long page,
                                             @RequestParam(defaultValue = "10") long size,
                                             @RequestParam(required = false) Integer status) {
        return Result.ok(adjustService.page(page, size, status));
    }

    @PostMapping
    @RequireRole("STUDENT")
    public Result<Void> apply(@RequestBody AdjustRequest request) {
        adjustService.apply(request);
        return Result.ok("申请已提交，请等待审批", null);
    }

    @PutMapping("/{id}/approve")
    @RequireRole({"ADMIN", "MANAGER"})
    public Result<Void> approve(@PathVariable Long id, @RequestBody HandleDTO dto) {
        adjustService.approve(id, dto.getApprove(), dto.getRemark());
        return Result.ok("审批完成", null);
    }
}
