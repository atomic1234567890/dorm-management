package com.dorm.dto;

import lombok.Data;

/**
 * 报修处理相关请求：派单 / 完成 / 审批等通用字段
 */
@Data
public class HandleDTO {

    /** 派单：维修人 id */
    private Long handlerId;

    /** 完成：处理结果 */
    private String result;

    /** 调宿审批：是否通过 */
    private Boolean approve;

    /** 审批意见 */
    private String remark;
}
