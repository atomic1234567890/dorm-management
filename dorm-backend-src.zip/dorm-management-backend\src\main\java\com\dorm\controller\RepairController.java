package com.dorm.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.dorm.common.RequireRole;
import com.dorm.common.Result;
import com.dorm.dto.HandleDTO;
import com.dorm.entity.Repair;
import com.dorm.service.RepairService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 报修管理
 */
@RestController
@RequestMapping("/api/repairs")
@RequiredArgsConstructor
public class RepairController {

    private final RepairService repairService;

    @GetMapping
    public Result<IPage<Repair>> page(@RequestParam(defaultValue = "1") long page,
                                      @RequestParam(defaultValue = "10") long size,
                                      @RequestParam(required = false) Integer status,
                                      @RequestParam(required = false) String keyword) {
        return Result.ok(repairService.page(page, size, status, keyword));
    }

    @GetMapping("/{id}")
    public Result<Repair> detail(@PathVariable Long id) {
        return Result.ok(repairService.detail(id));
    }

    @PostMapping
    @RequireRole("STUDENT")
    public Result<Void> create(@RequestBody Repair repair) {
        repairService.create(repair);
        return Result.ok("报修提交成功，请等待宿管派单", null);
    }

    @PutMapping("/{id}/dispatch")
    @RequireRole({"ADMIN", "MANAGER"})
    public Result<Void> dispatch(@PathVariable Long id, @RequestBody HandleDTO dto) {
        repairService.dispatch(id, dto.getHandlerId());
        return Result.ok("派单成功", null);
    }

    @PutMapping("/{id}/finish")
    @RequireRole({"ADMIN", "MANAGER"})
    public Result<Void> finish(@PathVariable Long id, @RequestBody HandleDTO dto) {
        repairService.finish(id, dto.getResult());
        return Result.ok("报修已完成", null);
    }

    @PutMapping("/{id}/cancel")
    public Result<Void> cancel(@PathVariable Long id) {
        repairService.cancel(id);
        return Result.ok("已取消", null);
    }
}
