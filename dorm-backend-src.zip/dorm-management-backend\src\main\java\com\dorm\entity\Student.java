package com.dorm.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 学生
 */
@Data
public class Student {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 关联登录账号 */
    private Long userId;

    private String studentNo;

    private String name;

    /** 1 男 / 0 女 */
    private Integer gender;

    private String className;

    private String phone;

    private Long dormitoryId;

    private Integer bedNo;

    /** 1 在住 / 0 退宿 / 2 待分配 */
    private Integer status;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    @TableField(exist = false)
    private String roomNo;

    @TableField(exist = false)
    private String buildingName;

    @TableField(exist = false)
    private String buildingCode;

    @TableField(exist = false)
    private Long buildingId;
}
