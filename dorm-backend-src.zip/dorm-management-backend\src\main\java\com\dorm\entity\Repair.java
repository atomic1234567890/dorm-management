package com.dorm.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 报修单
 */
@Data
public class Repair {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long studentId;

    private Long dormitoryId;

    /** 水电 / 门窗 / 家具 / 网络 / 其他 */
    private String type;

    private String description;

    /** 图片地址，逗号分隔 */
    private String images;

    /** 0 待派单 / 1 维修中 / 2 已完成 / 3 已取消 */
    private Integer status;

    private Long handlerId;

    private String result;

    private LocalDateTime createTime;

    private LocalDateTime dispatchTime;

    private LocalDateTime finishTime;

    private LocalDateTime updateTime;

    @TableField(exist = false)
    private String studentName;

    @TableField(exist = false)
    private String studentNo;

    @TableField(exist = false)
    private String phone;

    @TableField(exist = false)
    private String roomNo;

    @TableField(exist = false)
    private String buildingName;

    @TableField(exist = false)
    private Long buildingId;

    @TableField(exist = false)
    private String handlerName;
}
