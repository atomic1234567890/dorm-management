package com.dorm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dorm.entity.User;
import org.apache.ibatis.annotations.Select;

/**
 * 用户 Mapper
 */
public interface UserMapper extends BaseMapper<User> {

    @Select("select b.name from building b where b.manager_id = #{userId} limit 1")
    String selectBuildingName(Long userId);

    @Select("select count(*) from student s where s.user_id = #{userId}")
    int countStudentByUserId(Long userId);
}
