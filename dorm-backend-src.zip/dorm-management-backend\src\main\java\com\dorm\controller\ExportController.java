package com.dorm.controller;

import com.dorm.common.RequireRole;
import com.dorm.service.ExportService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Excel 导出
 */
@RestController
@RequestMapping("/api/export")
@RequiredArgsConstructor
public class ExportController {

    private final ExportService exportService;

    @GetMapping("/students")
    @RequireRole({"ADMIN", "MANAGER"})
    public void students(HttpServletResponse response,
                         @RequestParam(required = false) String keyword,
                         @RequestParam(required = false) Long buildingId) throws IOException {
        exportService.exportStudents(response, keyword, buildingId);
    }

    @GetMapping("/repairs")
    public void repairs(HttpServletResponse response,
                        @RequestParam(required = false) Integer status,
                        @RequestParam(required = false) String keyword) throws IOException {
        exportService.exportRepairs(response, status, keyword);
    }
}
