package com.dorm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.entity.Visitor;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * 访客 Mapper
 */
public interface VisitorMapper extends BaseMapper<Visitor> {

    @Select("<script>" +
            "select v.*, d.room_no, b.name as building_name, s.name as student_name, u.real_name as registrar_name " +
            "from visitor v " +
            "join dormitory d on v.dormitory_id = d.id " +
            "join building b on d.building_id = b.id " +
            "left join student s on v.student_id = s.id " +
            "left join sys_user u on v.registrar_id = u.id " +
            "where 1 = 1 " +
            "<if test='status != null'> and v.status = #{status} </if>" +
            "<if test='managerId != null'> and b.manager_id = #{managerId} </if>" +
            "<if test='keyword != null and keyword != \"\"'>" +
            "  and (v.name like concat('%', #{keyword}, '%') or d.room_no like concat('%', #{keyword}, '%'))" +
            "</if>" +
            "order by v.visit_time desc" +
            "</script>")
    IPage<Visitor> selectPageDetail(Page<Visitor> page,
                                    @Param("status") Integer status,
                                    @Param("managerId") Long managerId,
                                    @Param("keyword") String keyword);
}
