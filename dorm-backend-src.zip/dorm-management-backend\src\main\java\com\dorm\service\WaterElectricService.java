package com.dorm.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.common.BusinessException;
import com.dorm.common.LoginUser;
import com.dorm.common.UserContext;
import com.dorm.entity.Dormitory;
import com.dorm.entity.Student;
import com.dorm.entity.WaterElectric;
import com.dorm.mapper.DormitoryMapper;
import com.dorm.mapper.StudentMapper;
import com.dorm.mapper.WaterElectricMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * 水电费录入、查询、缴费
 */
@Service
@RequiredArgsConstructor
public class WaterElectricService {

    private final WaterElectricMapper waterElectricMapper;
    private final DormitoryMapper dormitoryMapper;
    private final StudentMapper studentMapper;

    public IPage<WaterElectric> page(long page, long size, String billMonth, Integer paid, Long buildingId) {
        LoginUser user = UserContext.require();
        Long managerId = null;
        Long dormitoryId = null;
        if (user.isManager()) {
            managerId = user.getId();
        } else if (user.isStudent()) {
            Student student = studentMapper.selectByUserId(user.getId());
            if (student == null || student.getDormitoryId() == null) {
                throw new BusinessException(400, "你还没有分配宿舍，暂无水电费记录");
            }
            dormitoryId = student.getDormitoryId();
        }
        return waterElectricMapper.selectPageDetail(new Page<>(page, size), billMonth, paid,
                buildingId, managerId, dormitoryId);
    }

    public List<String> months() {
        return waterElectricMapper.selectMonths();
    }

    @Transactional
    public void create(WaterElectric bill) {
        if (bill.getDormitoryId() == null) {
            throw new BusinessException(400, "请选择宿舍");
        }
        if (!StringUtils.hasText(bill.getBillMonth()) || !bill.getBillMonth().matches("\\d{4}-\\d{2}")) {
            throw new BusinessException(400, "账期格式应为 yyyy-MM，例如 2026-11");
        }
        Dormitory dorm = dormitoryMapper.selectById(bill.getDormitoryId());
        if (dorm == null) {
            throw new BusinessException(400, "宿舍不存在");
        }
        Long exists = waterElectricMapper.selectCount(new LambdaQueryWrapper<WaterElectric>()
                .eq(WaterElectric::getDormitoryId, bill.getDormitoryId())
                .eq(WaterElectric::getBillMonth, bill.getBillMonth()));
        if (exists > 0) {
            throw new BusinessException(400, "该宿舍本月水电费已录入，请直接修改");
        }
        BigDecimal waterUsage = nvl(bill.getWaterUsage());
        BigDecimal electricUsage = nvl(bill.getElectricUsage());
        BigDecimal waterFee = nvl(bill.getWaterFee());
        BigDecimal electricFee = nvl(bill.getElectricFee());
        bill.setId(null);
        bill.setWaterUsage(waterUsage);
        bill.setElectricUsage(electricUsage);
        bill.setWaterFee(waterFee);
        bill.setElectricFee(electricFee);
        bill.setTotalFee(waterFee.add(electricFee));
        bill.setPaid(0);
        bill.setPayTime(null);
        waterElectricMapper.insert(bill);
    }

    @Transactional
    public void update(WaterElectric bill) {
        WaterElectric old = waterElectricMapper.selectById(bill.getId());
        if (old == null) {
            throw new BusinessException(404, "水电费记录不存在");
        }
        old.setWaterUsage(nvl(bill.getWaterUsage()));
        old.setElectricUsage(nvl(bill.getElectricUsage()));
        old.setWaterFee(nvl(bill.getWaterFee()));
        old.setElectricFee(nvl(bill.getElectricFee()));
        old.setTotalFee(old.getWaterFee().add(old.getElectricFee()));
        waterElectricMapper.updateById(old);
    }

    @Transactional
    public void pay(Long id) {
        WaterElectric bill = waterElectricMapper.selectById(id);
        if (bill == null) {
            throw new BusinessException(404, "水电费记录不存在");
        }
        if (bill.getPaid() != null && bill.getPaid() == 1) {
            throw new BusinessException(400, "该账期已缴费");
        }
        bill.setPaid(1);
        bill.setPayTime(LocalDateTime.now());
        waterElectricMapper.updateById(bill);
    }

    private BigDecimal nvl(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value;
    }
}
