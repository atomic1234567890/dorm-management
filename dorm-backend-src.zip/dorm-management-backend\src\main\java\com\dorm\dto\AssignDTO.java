package com.dorm.dto;

import lombok.Data;

/**
 * 学生分配宿舍
 */
@Data
public class AssignDTO {

    private Long dormitoryId;

    private Integer bedNo;
}
