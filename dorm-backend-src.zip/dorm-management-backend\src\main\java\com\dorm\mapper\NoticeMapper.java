package com.dorm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.entity.Notice;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * 公告 Mapper
 */
public interface NoticeMapper extends BaseMapper<Notice> {

    @Select("<script>" +
            "select n.*, u.real_name as publisher_name " +
            "from notice n left join sys_user u on n.publisher_id = u.id " +
            "where 1 = 1 " +
            "<if test='status != null'> and n.status = #{status} </if>" +
            "<if test='keyword != null and keyword != \"\"'> and n.title like concat('%', #{keyword}, '%') </if>" +
            "order by n.create_time desc" +
            "</script>")
    IPage<Notice> selectPageDetail(Page<Notice> page,
                                   @Param("status") Integer status,
                                   @Param("keyword") String keyword);

    @Select("select n.*, u.real_name as publisher_name from notice n " +
            "left join sys_user u on n.publisher_id = u.id where n.id = #{id}")
    Notice selectDetail(Long id);
}
