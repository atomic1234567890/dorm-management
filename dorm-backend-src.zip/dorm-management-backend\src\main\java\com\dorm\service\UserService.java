package com.dorm.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.common.BusinessException;
import com.dorm.common.UserContext;
import com.dorm.entity.User;
import com.dorm.mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * 账号管理（仅管理员）：宿管账号、重置密码、启用禁用
 */
@Service
@RequiredArgsConstructor
public class UserService {

    private static final String DEFAULT_PASSWORD = "123456";

    private final UserMapper userMapper;
    private final BCryptPasswordEncoder passwordEncoder;

    public IPage<User> page(long page, long size, String keyword, String role) {
        LambdaQueryWrapper<User> qw = new LambdaQueryWrapper<>();
        if (StringUtils.hasText(role)) {
            qw.eq(User::getRole, role);
        }
        if (StringUtils.hasText(keyword)) {
            qw.and(w -> w.like(User::getUsername, keyword)
                    .or().like(User::getRealName, keyword)
                    .or().like(User::getPhone, keyword));
        }
        qw.orderByDesc(User::getCreateTime);
        IPage<User> result = userMapper.selectPage(new Page<>(page, size), qw);
        result.getRecords().forEach(u -> {
            u.setPassword(null);
            if ("MANAGER".equals(u.getRole())) {
                u.setBuildingName(userMapper.selectBuildingName(u.getId()));
            }
        });
        return result;
    }

    public List<User> managers() {
        List<User> list = userMapper.selectList(new LambdaQueryWrapper<User>()
                .eq(User::getRole, "MANAGER")
                .eq(User::getStatus, 1)
                .orderByAsc(User::getUsername));
        list.forEach(u -> u.setPassword(null));
        return list;
    }

    public void create(User user) {
        if (!StringUtils.hasText(user.getUsername()) || !StringUtils.hasText(user.getRealName())) {
            throw new BusinessException(400, "账号和姓名不能为空");
        }
        if (!"ADMIN".equals(user.getRole()) && !"MANAGER".equals(user.getRole())
                && !"STUDENT".equals(user.getRole())) {
            throw new BusinessException(400, "角色不合法");
        }
        Long count = userMapper.selectCount(new LambdaQueryWrapper<User>()
                .eq(User::getUsername, user.getUsername().trim()));
        if (count > 0) {
            throw new BusinessException(400, "账号已存在");
        }
        user.setId(null);
        user.setUsername(user.getUsername().trim());
        user.setPassword(passwordEncoder.encode(DEFAULT_PASSWORD));
        user.setStatus(user.getStatus() == null ? 1 : user.getStatus());
        userMapper.insert(user);
    }

    public void update(User user) {
        User old = userMapper.selectById(user.getId());
        if (old == null) {
            throw new BusinessException(404, "账号不存在");
        }
        if (StringUtils.hasText(user.getUsername()) && !user.getUsername().equals(old.getUsername())) {
            Long count = userMapper.selectCount(new LambdaQueryWrapper<User>()
                    .eq(User::getUsername, user.getUsername().trim())
                    .ne(User::getId, user.getId()));
            if (count > 0) {
                throw new BusinessException(400, "账号已存在");
            }
            old.setUsername(user.getUsername().trim());
        }
        old.setRealName(user.getRealName());
        old.setPhone(user.getPhone());
        if (user.getStatus() != null) {
            old.setStatus(user.getStatus());
        }
        // 不允许把最后一个管理员降级
        if (StringUtils.hasText(user.getRole()) && !user.getRole().equals(old.getRole())) {
            if ("ADMIN".equals(old.getRole()) && countAdmin() <= 1) {
                throw new BusinessException(400, "系统至少需要保留一个管理员");
            }
            old.setRole(user.getRole());
        }
        old.setPassword(null);
        userMapper.updateById(old);
    }

    public void resetPassword(Long id) {
        User user = userMapper.selectById(id);
        if (user == null) {
            throw new BusinessException(404, "账号不存在");
        }
        user.setPassword(passwordEncoder.encode(DEFAULT_PASSWORD));
        userMapper.updateById(user);
    }

    public void toggleStatus(Long id) {
        User user = userMapper.selectById(id);
        if (user == null) {
            throw new BusinessException(404, "账号不存在");
        }
        if (user.getId().equals(UserContext.require().getId())) {
            throw new BusinessException(400, "不能禁用当前登录账号");
        }
        user.setStatus(user.getStatus() != null && user.getStatus() == 1 ? 0 : 1);
        userMapper.updateById(user);
    }

    public void delete(Long id) {
        User user = userMapper.selectById(id);
        if (user == null) {
            throw new BusinessException(404, "账号不存在");
        }
        if (user.getId().equals(UserContext.require().getId())) {
            throw new BusinessException(400, "不能删除当前登录账号");
        }
        if ("ADMIN".equals(user.getRole()) && countAdmin() <= 1) {
            throw new BusinessException(400, "系统至少需要保留一个管理员");
        }
        if (userMapper.countStudentByUserId(id) > 0) {
            throw new BusinessException(400, "该账号关联学生档案，请先在学生管理中删除学生");
        }
        userMapper.deleteById(id);
    }

    private long countAdmin() {
        return userMapper.selectCount(new LambdaQueryWrapper<User>().eq(User::getRole, "ADMIN"));
    }
}
