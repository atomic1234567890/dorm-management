package com.dorm.service;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.dorm.common.BusinessException;
import com.dorm.common.JwtUtil;
import com.dorm.common.LoginUser;
import com.dorm.common.UserContext;
import com.dorm.dto.LoginDTO;
import com.dorm.dto.LoginVO;
import com.dorm.dto.PasswordDTO;
import com.dorm.entity.Student;
import com.dorm.entity.User;
import com.dorm.mapper.StudentMapper;
import com.dorm.mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * 登录与账号服务
 */
@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserMapper userMapper;
    private final StudentMapper studentMapper;
    private final JwtUtil jwtUtil;
    private final BCryptPasswordEncoder passwordEncoder;

    public LoginVO login(LoginDTO dto) {
        if (!StringUtils.hasText(dto.getUsername()) || !StringUtils.hasText(dto.getPassword())) {
            throw new BusinessException(400, "请输入账号和密码");
        }
        User user = userMapper.selectOne(Wrappers.<User>lambdaQuery()
                .eq(User::getUsername, dto.getUsername().trim()));
        if (user == null || !passwordEncoder.matches(dto.getPassword(), user.getPassword())) {
            throw new BusinessException(400, "账号或密码错误");
        }
        if (user.getStatus() != null && user.getStatus() == 0) {
            throw new BusinessException(403, "该账号已被禁用，请联系管理员");
        }
        LoginUser loginUser = new LoginUser(user.getId(), user.getUsername(), user.getRealName(), user.getRole());
        return buildVO(user, jwtUtil.generate(loginUser));
    }

    public LoginVO me() {
        LoginUser current = UserContext.require();
        User user = userMapper.selectById(current.getId());
        if (user == null) {
            throw new BusinessException(401, "账号不存在");
        }
        return buildVO(user, null);
    }

    public void changePassword(PasswordDTO dto) {
        LoginUser current = UserContext.require();
        if (!StringUtils.hasText(dto.getNewPassword()) || dto.getNewPassword().length() < 6) {
            throw new BusinessException(400, "新密码长度不能少于 6 位");
        }
        User user = userMapper.selectById(current.getId());
        if (user == null) {
            throw new BusinessException(401, "账号不存在");
        }
        if (!passwordEncoder.matches(dto.getOldPassword(), user.getPassword())) {
            throw new BusinessException(400, "原密码不正确");
        }
        user.setPassword(passwordEncoder.encode(dto.getNewPassword()));
        userMapper.updateById(user);
    }

    private LoginVO buildVO(User user, String token) {
        LoginVO vo = new LoginVO();
        vo.setToken(token);
        vo.setId(user.getId());
        vo.setUsername(user.getUsername());
        vo.setRealName(user.getRealName());
        vo.setRole(user.getRole());
        vo.setPhone(user.getPhone());
        if ("STUDENT".equals(user.getRole())) {
            Student student = studentMapper.selectByUserId(user.getId());
            if (student != null) {
                vo.setStudentId(student.getId());
            }
        } else if ("MANAGER".equals(user.getRole())) {
            vo.setBuildingName(userMapper.selectBuildingName(user.getId()));
        }
        return vo;
    }
}
