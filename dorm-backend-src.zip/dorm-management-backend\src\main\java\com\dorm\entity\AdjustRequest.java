package com.dorm.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 调宿申请
 */
@Data
public class AdjustRequest {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long studentId;

    private Long fromDormitoryId;

    private Long toDormitoryId;

    private String reason;

    /** 0 待审批 / 1 已通过 / 2 已驳回 */
    private Integer status;

    private Long approverId;

    private String approveRemark;

    private LocalDateTime createTime;

    private LocalDateTime approveTime;

    @TableField(exist = false)
    private String studentName;

    @TableField(exist = false)
    private String studentNo;

    @TableField(exist = false)
    private String fromRoom;

    @TableField(exist = false)
    private String fromBuilding;

    @TableField(exist = false)
    private String toRoom;

    @TableField(exist = false)
    private String toBuilding;

    @TableField(exist = false)
    private String approverName;
}
