package com.dorm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.entity.Dormitory;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * 宿舍 Mapper
 */
public interface DormitoryMapper extends BaseMapper<Dormitory> {

    @Select("<script>" +
            "select d.*, b.name as building_name, b.code as building_code, b.manager_id " +
            "from dormitory d join building b on d.building_id = b.id " +
            "where 1 = 1 " +
            "<if test='buildingId != null'> and d.building_id = #{buildingId} </if>" +
            "<if test='managerId != null'> and b.manager_id = #{managerId} </if>" +
            "<if test='status != null'> and d.status = #{status} </if>" +
            "<if test='keyword != null and keyword != \"\"'> and d.room_no like concat('%', #{keyword}, '%') </if>" +
            "order by b.code, d.floor, d.room_no" +
            "</script>")
    IPage<Dormitory> selectPageWithBuilding(Page<Dormitory> page,
                                            @Param("buildingId") Long buildingId,
                                            @Param("managerId") Long managerId,
                                            @Param("status") Integer status,
                                            @Param("keyword") String keyword);

    @Select("select d.*, b.name as building_name, b.code as building_code, b.manager_id " +
            "from dormitory d join building b on d.building_id = b.id where d.id = #{id}")
    Dormitory selectDetail(Long id);
}
