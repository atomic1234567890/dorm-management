package com.dorm.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 宿舍
 */
@Data
public class Dormitory {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long buildingId;

    private String roomNo;

    private Integer floor;

    /** 最大入住人数 */
    private Integer capacity;

    /** 已住人数 */
    private Integer occupied;

    /** 0 正常 / 1 满员 / 2 维修中 */
    private Integer status;

    private String remark;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    @TableField(exist = false)
    private String buildingName;

    @TableField(exist = false)
    private String buildingCode;

    /** 宿管查看本楼栋时使用 */
    @TableField(exist = false)
    private Long managerId;
}
