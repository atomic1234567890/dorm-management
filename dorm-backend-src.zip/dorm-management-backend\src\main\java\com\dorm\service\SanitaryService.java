package com.dorm.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.common.BusinessException;
import com.dorm.common.LoginUser;
import com.dorm.common.UserContext;
import com.dorm.entity.Dormitory;
import com.dorm.entity.Sanitary;
import com.dorm.mapper.DormitoryMapper;
import com.dorm.mapper.SanitaryMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

/**
 * 卫生检查记录
 */
@Service
@RequiredArgsConstructor
public class SanitaryService {

    private final SanitaryMapper sanitaryMapper;
    private final DormitoryMapper dormitoryMapper;

    public IPage<Sanitary> page(long page, long size, Long dormitoryId) {
        LoginUser user = UserContext.require();
        Long managerId = user.isManager() ? user.getId() : null;
        return sanitaryMapper.selectPageDetail(new Page<>(page, size), dormitoryId, managerId, null);
    }

    public void create(Sanitary sanitary) {
        if (sanitary.getDormitoryId() == null) {
            throw new BusinessException(400, "请选择宿舍");
        }
        if (sanitary.getScore() == null || sanitary.getScore() < 0 || sanitary.getScore() > 100) {
            throw new BusinessException(400, "卫生得分应在 0 - 100 之间");
        }
        Dormitory dorm = dormitoryMapper.selectDetail(sanitary.getDormitoryId());
        if (dorm == null) {
            throw new BusinessException(400, "宿舍不存在");
        }
        LoginUser user = UserContext.require();
        if (user.isManager() && dorm.getManagerId() != null && !dorm.getManagerId().equals(user.getId())) {
            throw new BusinessException(403, "只能登记自己负责楼栋的卫生检查");
        }
        sanitary.setId(null);
        sanitary.setCheckerId(user.getId());
        if (sanitary.getCheckDate() == null) {
            sanitary.setCheckDate(LocalDate.now());
        }
        sanitaryMapper.insert(sanitary);
    }

    public void delete(Long id) {
        LoginUser user = UserContext.require();
        if (!user.isAdmin()) {
            throw new BusinessException(403, "只有管理员可以删除卫生记录");
        }
        sanitaryMapper.deleteById(id);
    }
}
