package com.dorm.dto;

import lombok.Data;

/**
 * 修改密码
 */
@Data
public class PasswordDTO {

    private String oldPassword;

    private String newPassword;
}
