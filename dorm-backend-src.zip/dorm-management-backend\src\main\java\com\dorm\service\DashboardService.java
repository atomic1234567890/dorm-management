package com.dorm.service;

import com.dorm.common.LoginUser;
import com.dorm.common.UserContext;
import com.dorm.entity.Notice;
import com.dorm.mapper.AdjustRequestMapper;
import com.dorm.mapper.NoticeMapper;
import com.dorm.mapper.StatMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 首页数据看板
 */
@Service
@RequiredArgsConstructor
public class DashboardService {

    private final StatMapper statMapper;
    private final NoticeMapper noticeMapper;
    private final AdjustRequestMapper adjustRequestMapper;

    public Map<String, Object> stats() {
        LoginUser user = UserContext.require();
        Long managerId = user.isManager() ? user.getId() : null;

        int beds = statMapper.bedCount(managerId);
        int occupied = statMapper.occupiedCount(managerId);
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("dormCount", statMapper.dormCount(managerId));
        data.put("bedCount", beds);
        data.put("occupiedCount", occupied);
        data.put("occupancyRate", beds == 0 ? 0
                : BigDecimal.valueOf(occupied * 100.0 / beds).setScale(1, RoundingMode.HALF_UP));
        data.put("residentCount", statMapper.residentCount(managerId));
        data.put("pendingRepair", statMapper.pendingRepairCount(managerId));
        data.put("visiting", statMapper.visitingCount(managerId));
        data.put("unpaidCount", statMapper.unpaidCount(managerId));
        data.put("unpaidAmount", statMapper.unpaidAmount(managerId));
        data.put("adjustPending", user.isAdmin()
                ? adjustRequestMapper.countPending()
                : adjustRequestMapper.countPendingForManager(managerId));

        data.put("buildingStats", statMapper.buildingStats(managerId));
        data.put("repairTrend", fillTrend(statMapper.repairTrend(6, managerId)));
        data.put("repairTypeStats", statMapper.repairTypeStats(managerId));

        List<Notice> notices = noticeMapper.selectList(new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<Notice>()
                .eq(Notice::getStatus, 1)
                .orderByDesc(Notice::getCreateTime)
                .last("limit 5"));
        data.put("notices", notices);
        return data;
    }

    /** 补齐最近 7 天没有报修的日期，保证折线图连续 */
    private List<Map<String, Object>> fillTrend(List<Map<String, Object>> rows) {
        Map<String, Integer> counts = new HashMap<>();
        for (Map<String, Object> row : rows) {
            Object day = row.get("day");
            Object total = row.get("total");
            if (day != null && total != null) {
                counts.put(day.toString(), Integer.parseInt(total.toString()));
            }
        }
        List<Map<String, Object>> result = new ArrayList<>();
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("MM-dd");
        for (int i = 6; i >= 0; i--) {
            String day = LocalDate.now().minusDays(i).format(fmt);
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("day", day);
            item.put("total", counts.getOrDefault(day, 0));
            result.add(item);
        }
        return result;
    }
}
