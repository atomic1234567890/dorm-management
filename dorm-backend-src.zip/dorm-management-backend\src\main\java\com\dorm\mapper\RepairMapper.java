package com.dorm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.entity.Repair;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * 报修 Mapper
 */
public interface RepairMapper extends BaseMapper<Repair> {

    @Select("<script>" +
            "select r.*, s.name as student_name, s.student_no, s.phone, " +
            "       d.room_no, d.building_id, b.name as building_name, u.real_name as handler_name " +
            "from repair r " +
            "join student s on r.student_id = s.id " +
            "join dormitory d on r.dormitory_id = d.id " +
            "join building b on d.building_id = b.id " +
            "left join sys_user u on r.handler_id = u.id " +
            "where 1 = 1 " +
            "<if test='status != null'> and r.status = #{status} </if>" +
            "<if test='studentId != null'> and r.student_id = #{studentId} </if>" +
            "<if test='managerId != null'> and b.manager_id = #{managerId} </if>" +
            "<if test='buildingId != null'> and d.building_id = #{buildingId} </if>" +
            "<if test='keyword != null and keyword != \"\"'>" +
            "  and (s.name like concat('%', #{keyword}, '%') " +
            "       or d.room_no like concat('%', #{keyword}, '%') " +
            "       or r.description like concat('%', #{keyword}, '%'))" +
            "</if>" +
            "order by r.create_time desc" +
            "</script>")
    IPage<Repair> selectPageDetail(Page<Repair> page,
                                   @Param("status") Integer status,
                                   @Param("studentId") Long studentId,
                                   @Param("managerId") Long managerId,
                                   @Param("buildingId") Long buildingId,
                                   @Param("keyword") String keyword);

    @Select("select r.*, s.name as student_name, s.student_no, s.phone, " +
            "       d.room_no, d.building_id, b.name as building_name, u.real_name as handler_name " +
            "from repair r join student s on r.student_id = s.id " +
            "join dormitory d on r.dormitory_id = d.id " +
            "join building b on d.building_id = b.id " +
            "left join sys_user u on r.handler_id = u.id where r.id = #{id}")
    Repair selectDetail(Long id);
}
