package com.dorm.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.common.BusinessException;
import com.dorm.common.LoginUser;
import com.dorm.common.UserContext;
import com.dorm.entity.Building;
import com.dorm.entity.Dormitory;
import com.dorm.entity.Student;
import com.dorm.mapper.BuildingMapper;
import com.dorm.mapper.DormitoryMapper;
import com.dorm.mapper.StudentMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * 宿舍管理
 */
@Service
@RequiredArgsConstructor
public class DormitoryService {

    private final DormitoryMapper dormitoryMapper;
    private final BuildingMapper buildingMapper;
    private final StudentMapper studentMapper;

    public IPage<Dormitory> page(long page, long size, Long buildingId, Integer status, String keyword) {
        Long managerId = currentManagerId();
        return dormitoryMapper.selectPageWithBuilding(new Page<>(page, size), buildingId, managerId, status, keyword);
    }

    public Dormitory detail(Long id) {
        Dormitory dorm = dormitoryMapper.selectDetail(id);
        if (dorm == null) {
            throw new BusinessException(404, "宿舍不存在");
        }
        checkManagerScope(dorm);
        return dorm;
    }

    public List<Student> students(Long dormitoryId) {
        Dormitory dorm = detail(dormitoryId);
        return studentMapper.selectList(new LambdaQueryWrapper<Student>()
                .eq(Student::getDormitoryId, dorm.getId())
                .orderByAsc(Student::getBedNo));
    }

    /** 可分配宿舍：未满且非维修中 */
    public List<Dormitory> available(Long buildingId) {
        LambdaQueryWrapper<Dormitory> qw = new LambdaQueryWrapper<Dormitory>()
                .ne(Dormitory::getStatus, 2)
                .orderByAsc(Dormitory::getBuildingId)
                .orderByAsc(Dormitory::getRoomNo);
        if (buildingId != null) {
            qw.eq(Dormitory::getBuildingId, buildingId);
        }
        List<Dormitory> list = dormitoryMapper.selectList(qw);
        list.removeIf(d -> d.getOccupied() != null && d.getCapacity() != null && d.getOccupied() >= d.getCapacity());
        list.forEach(d -> {
            Building b = buildingMapper.selectById(d.getBuildingId());
            if (b != null) {
                d.setBuildingName(b.getName());
            }
        });
        return list;
    }

    public void create(Dormitory dorm) {
        checkFields(dorm, null);
        dorm.setId(null);
        if (dorm.getCapacity() == null || dorm.getCapacity() < 1) {
            dorm.setCapacity(6);
        }
        if (dorm.getFloor() == null) {
            throw new BusinessException(400, "请填写所在楼层");
        }
        dorm.setOccupied(0);
        dorm.setStatus(dorm.getStatus() == null ? 0 : dorm.getStatus());
        dormitoryMapper.insert(dorm);
    }

    public void update(Dormitory dorm) {
        Dormitory old = dormitoryMapper.selectById(dorm.getId());
        if (old == null) {
            throw new BusinessException(404, "宿舍不存在");
        }
        checkFields(dorm, dorm.getId());
        if (dorm.getCapacity() != null && dorm.getCapacity() < old.getOccupied()) {
            throw new BusinessException(400, "容量不能小于当前已住人数（" + old.getOccupied() + " 人）");
        }
        // 已住人数只能由入住/退宿流程维护，不允许直接修改
        dorm.setOccupied(null);
        dormitoryMapper.updateById(dorm);
    }

    public void delete(Long id) {
        Dormitory dorm = dormitoryMapper.selectById(id);
        if (dorm == null) {
            throw new BusinessException(404, "宿舍不存在");
        }
        if (dorm.getOccupied() != null && dorm.getOccupied() > 0) {
            throw new BusinessException(400, "宿舍还有学生入住，不能删除");
        }
        dormitoryMapper.deleteById(id);
    }

    /** 当前用户若为宿管，则只允许操作自己负责的楼栋 */
    private Long currentManagerId() {
        LoginUser user = UserContext.get();
        return user != null && user.isManager() ? user.getId() : null;
    }

    private void checkManagerScope(Dormitory dorm) {
        LoginUser user = UserContext.require();
        if (user.isManager() && dorm.getManagerId() != null && !dorm.getManagerId().equals(user.getId())) {
            throw new BusinessException(403, "只能查看自己负责的楼栋");
        }
    }

    private void checkFields(Dormitory dorm, Long excludeId) {
        if (dorm.getBuildingId() == null) {
            throw new BusinessException(400, "请选择所属楼栋");
        }
        Building building = buildingMapper.selectById(dorm.getBuildingId());
        if (building == null) {
            throw new BusinessException(400, "楼栋不存在");
        }
        if (!StringUtils.hasText(dorm.getRoomNo())) {
            throw new BusinessException(400, "宿舍号不能为空");
        }
        if (dorm.getFloor() != null && dorm.getFloor() > building.getFloors()) {
            throw new BusinessException(400, "楼层超出该楼栋总层数（" + building.getFloors() + " 层）");
        }
        LambdaQueryWrapper<Dormitory> qw = new LambdaQueryWrapper<Dormitory>()
                .eq(Dormitory::getBuildingId, dorm.getBuildingId())
                .eq(Dormitory::getRoomNo, dorm.getRoomNo().trim());
        if (excludeId != null) {
            qw.ne(Dormitory::getId, excludeId);
        }
        if (dormitoryMapper.selectCount(qw) > 0) {
            throw new BusinessException(400, "该楼栋下宿舍号已存在");
        }
        dorm.setRoomNo(dorm.getRoomNo().trim());
    }
}
