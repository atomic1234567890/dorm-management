package com.dorm.common;

import lombok.Data;

import java.io.Serializable;

/**
 * 统一响应结果。
 * 约定：HTTP 状态码始终为 200，业务结果由 body.code 表示。
 * 200 成功 / 400 参数错误 / 401 未登录或登录过期 / 403 无权限 / 500 业务或系统异常
 */
@Data
public class Result<T> implements Serializable {

    private int code;
    private String msg;
    private T data;

    public static <T> Result<T> ok(T data) {
        Result<T> r = new Result<>();
        r.setCode(200);
        r.setMsg("操作成功");
        r.setData(data);
        return r;
    }

    public static <T> Result<T> ok(String msg, T data) {
        Result<T> r = ok(data);
        r.setMsg(msg);
        return r;
    }

    public static Result<Void> ok() {
        return ok(null);
    }

    public static <T> Result<T> fail(int code, String msg) {
        Result<T> r = new Result<>();
        r.setCode(code);
        r.setMsg(msg);
        return r;
    }

    public static <T> Result<T> fail(String msg) {
        return fail(500, msg);
    }
}
