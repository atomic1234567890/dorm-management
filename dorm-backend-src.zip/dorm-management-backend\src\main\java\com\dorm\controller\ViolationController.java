package com.dorm.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.dorm.common.RequireRole;
import com.dorm.common.Result;
import com.dorm.entity.Violation;
import com.dorm.service.ViolationService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 违纪记录
 */
@RestController
@RequestMapping("/api/violations")
@RequiredArgsConstructor
public class ViolationController {

    private final ViolationService violationService;

    @GetMapping
    @RequireRole({"ADMIN", "MANAGER"})
    public Result<IPage<Violation>> page(@RequestParam(defaultValue = "1") long page,
                                         @RequestParam(defaultValue = "10") long size,
                                         @RequestParam(required = false) Long studentId,
                                         @RequestParam(required = false) String keyword) {
        return Result.ok(violationService.page(page, size, studentId, keyword));
    }

    @PostMapping
    @RequireRole({"ADMIN", "MANAGER"})
    public Result<Void> create(@RequestBody Violation violation) {
        violationService.create(violation);
        return Result.ok("违纪记录已保存", null);
    }

    @DeleteMapping("/{id}")
    @RequireRole("ADMIN")
    public Result<Void> delete(@PathVariable Long id) {
        violationService.delete(id);
        return Result.ok("删除成功", null);
    }
}
