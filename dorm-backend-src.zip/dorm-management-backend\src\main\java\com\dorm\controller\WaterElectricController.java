package com.dorm.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.dorm.common.RequireRole;
import com.dorm.common.Result;
import com.dorm.entity.WaterElectric;
import com.dorm.service.WaterElectricService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 水电费
 */
@RestController
@RequestMapping("/api/water-electric")
@RequiredArgsConstructor
public class WaterElectricController {

    private final WaterElectricService waterElectricService;

    @GetMapping
    public Result<IPage<WaterElectric>> page(@RequestParam(defaultValue = "1") long page,
                                             @RequestParam(defaultValue = "10") long size,
                                             @RequestParam(required = false) String billMonth,
                                             @RequestParam(required = false) Integer paid,
                                             @RequestParam(required = false) Long buildingId) {
        return Result.ok(waterElectricService.page(page, size, billMonth, paid, buildingId));
    }

    @GetMapping("/months")
    public Result<List<String>> months() {
        return Result.ok(waterElectricService.months());
    }

    @PostMapping
    @RequireRole("ADMIN")
    public Result<Void> create(@RequestBody WaterElectric bill) {
        waterElectricService.create(bill);
        return Result.ok("录入成功", null);
    }

    @PutMapping("/{id}")
    @RequireRole("ADMIN")
    public Result<Void> update(@PathVariable Long id, @RequestBody WaterElectric bill) {
        bill.setId(id);
        waterElectricService.update(bill);
        return Result.ok("保存成功", null);
    }

    @PutMapping("/{id}/pay")
    @RequireRole({"ADMIN", "MANAGER"})
    public Result<Void> pay(@PathVariable Long id) {
        waterElectricService.pay(id);
        return Result.ok("缴费成功", null);
    }
}
