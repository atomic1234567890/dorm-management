package com.dorm.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.dorm.common.RequireRole;
import com.dorm.common.Result;
import com.dorm.entity.Building;
import com.dorm.service.BuildingService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 楼栋管理（查询所有角色可用，增删改仅管理员）
 */
@RestController
@RequestMapping("/api/buildings")
@RequiredArgsConstructor
public class BuildingController {

    private final BuildingService buildingService;

    @GetMapping
    public Result<IPage<Building>> page(@RequestParam(defaultValue = "1") long page,
                                        @RequestParam(defaultValue = "10") long size,
                                        @RequestParam(required = false) String keyword) {
        return Result.ok(buildingService.page(page, size, keyword));
    }

    @GetMapping("/options")
    public Result<List<Building>> options() {
        return Result.ok(buildingService.options());
    }

    @PostMapping
    @RequireRole("ADMIN")
    public Result<Void> create(@RequestBody Building building) {
        buildingService.create(building);
        return Result.ok("新增成功", null);
    }

    @PutMapping("/{id}")
    @RequireRole("ADMIN")
    public Result<Void> update(@PathVariable Long id, @RequestBody Building building) {
        building.setId(id);
        buildingService.update(building);
        return Result.ok("保存成功", null);
    }

    @DeleteMapping("/{id}")
    @RequireRole("ADMIN")
    public Result<Void> delete(@PathVariable Long id) {
        buildingService.delete(id);
        return Result.ok("删除成功", null);
    }
}
