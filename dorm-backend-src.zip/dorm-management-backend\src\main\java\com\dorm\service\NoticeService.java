package com.dorm.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.common.BusinessException;
import com.dorm.common.LoginUser;
import com.dorm.common.UserContext;
import com.dorm.entity.Notice;
import com.dorm.mapper.NoticeMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 公告管理
 */
@Service
@RequiredArgsConstructor
public class NoticeService {

    private final NoticeMapper noticeMapper;

    public IPage<Notice> page(long page, long size, String keyword, Integer status) {
        LoginUser user = UserContext.require();
        Integer statusFilter = status;
        if (user.isStudent()) {
            statusFilter = 1; // 学生只能看到已发布公告
        }
        return noticeMapper.selectPageDetail(new Page<>(page, size), statusFilter, keyword);
    }

    public Notice detail(Long id) {
        Notice notice = noticeMapper.selectDetail(id);
        if (notice == null) {
            throw new BusinessException(404, "公告不存在");
        }
        return notice;
    }

    /** 首页最新公告 */
    public List<Notice> latest(int limit) {
        return noticeMapper.selectList(new LambdaQueryWrapper<Notice>()
                .eq(Notice::getStatus, 1)
                .orderByDesc(Notice::getCreateTime)
                .last("limit " + Math.max(1, Math.min(limit, 20))));
    }

    public void create(Notice notice) {
        if (!StringUtils.hasText(notice.getTitle()) || !StringUtils.hasText(notice.getContent())) {
            throw new BusinessException(400, "标题和内容不能为空");
        }
        notice.setId(null);
        notice.setPublisherId(UserContext.require().getId());
        notice.setStatus(notice.getStatus() == null ? 1 : notice.getStatus());
        notice.setCreateTime(LocalDateTime.now());
        noticeMapper.insert(notice);
    }

    public void update(Notice notice) {
        Notice old = noticeMapper.selectById(notice.getId());
        if (old == null) {
            throw new BusinessException(404, "公告不存在");
        }
        if (!StringUtils.hasText(notice.getTitle()) || !StringUtils.hasText(notice.getContent())) {
            throw new BusinessException(400, "标题和内容不能为空");
        }
        notice.setPublisherId(old.getPublisherId());
        noticeMapper.updateById(notice);
    }

    public void delete(Long id) {
        noticeMapper.deleteById(id);
    }
}
