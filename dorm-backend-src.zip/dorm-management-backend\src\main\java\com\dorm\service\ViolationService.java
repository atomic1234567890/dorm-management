package com.dorm.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.common.BusinessException;
import com.dorm.common.LoginUser;
import com.dorm.common.UserContext;
import com.dorm.entity.Student;
import com.dorm.entity.Violation;
import com.dorm.mapper.StudentMapper;
import com.dorm.mapper.ViolationMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

/**
 * 违纪记录
 */
@Service
@RequiredArgsConstructor
public class ViolationService {

    private final ViolationMapper violationMapper;
    private final StudentMapper studentMapper;

    public IPage<Violation> page(long page, long size, Long studentId, String keyword) {
        LoginUser user = UserContext.require();
        Long managerId = user.isManager() ? user.getId() : null;
        Long studentFilter = user.isStudent() ? null : studentId;
        return violationMapper.selectPageDetail(new Page<>(page, size), studentFilter, managerId, keyword);
    }

    public void create(Violation violation) {
        if (violation.getStudentId() == null) {
            throw new BusinessException(400, "请选择违纪学生");
        }
        if (violation.getType() == null || violation.getType().trim().isEmpty()) {
            throw new BusinessException(400, "请填写违纪类型");
        }
        Student student = studentMapper.selectById(violation.getStudentId());
        if (student == null) {
            throw new BusinessException(400, "学生不存在");
        }
        LoginUser user = UserContext.require();
        violation.setId(null);
        violation.setRecorderId(user.getId());
        if (violation.getRecordDate() == null) {
            violation.setRecordDate(LocalDate.now());
        }
        if (violation.getPoints() == null) {
            violation.setPoints(0);
        }
        violationMapper.insert(violation);
    }

    public void delete(Long id) {
        LoginUser user = UserContext.require();
        if (!user.isAdmin()) {
            throw new BusinessException(403, "只有管理员可以删除违纪记录");
        }
        violationMapper.deleteById(id);
    }
}
