package com.dorm.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 卫生检查记录
 */
@Data
public class Sanitary {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long dormitoryId;

    /** 0-100 */
    private Integer score;

    private LocalDate checkDate;

    private String remark;

    private Long checkerId;

    private LocalDateTime createTime;

    @TableField(exist = false)
    private String roomNo;

    @TableField(exist = false)
    private String buildingName;

    @TableField(exist = false)
    private String checkerName;

    @TableField(exist = false)
    private Long buildingId;
}
