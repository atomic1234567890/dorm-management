package com.dorm.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.common.BusinessException;
import com.dorm.common.LoginUser;
import com.dorm.common.UserContext;
import com.dorm.entity.Dormitory;
import com.dorm.entity.Student;
import com.dorm.entity.User;
import com.dorm.mapper.DormitoryMapper;
import com.dorm.mapper.StudentMapper;
import com.dorm.mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * 学生与入住管理：分配宿舍、调宿、退宿
 */
@Service
@RequiredArgsConstructor
public class StudentService {

    private static final String DEFAULT_PASSWORD = "123456";

    private final StudentMapper studentMapper;
    private final DormitoryMapper dormitoryMapper;
    private final UserMapper userMapper;
    private final BCryptPasswordEncoder passwordEncoder;

    public IPage<Student> page(long page, long size, Long buildingId, Integer status, String keyword) {
        Long managerId = currentManagerId();
        return studentMapper.selectPageWithDorm(new Page<>(page, size), buildingId, managerId, status, keyword);
    }

    public Student detail(Long id) {
        Student student = studentMapper.selectDetail(id);
        if (student == null) {
            throw new BusinessException(404, "学生不存在");
        }
        return student;
    }

    /** 学生端：查看自己的档案与宿舍 */
    public Student my() {
        LoginUser user = UserContext.require();
        Student student = studentMapper.selectByUserId(user.getId());
        if (student == null) {
            throw new BusinessException(404, "未找到与当前账号关联的学生档案");
        }
        return student;
    }

    @Transactional
    public void create(Student student) {
        if (!StringUtils.hasText(student.getStudentNo()) || !StringUtils.hasText(student.getName())) {
            throw new BusinessException(400, "学号和姓名不能为空");
        }
        String studentNo = student.getStudentNo().trim();
        if (studentMapper.selectCount(new LambdaQueryWrapper<Student>().eq(Student::getStudentNo, studentNo)) > 0) {
            throw new BusinessException(400, "学号已存在");
        }
        if (userMapper.selectCount(new LambdaQueryWrapper<User>().eq(User::getUsername, studentNo)) > 0) {
            throw new BusinessException(400, "该学号已被其他账号占用");
        }

        User account = new User();
        account.setUsername(studentNo);
        account.setPassword(passwordEncoder.encode(DEFAULT_PASSWORD));
        account.setRealName(student.getName());
        account.setRole("STUDENT");
        account.setPhone(student.getPhone());
        account.setStatus(1);
        userMapper.insert(account);

        student.setId(null);
        student.setStudentNo(studentNo);
        student.setUserId(account.getId());
        Long targetDorm = student.getDormitoryId();
        Integer targetBed = student.getBedNo();
        student.setDormitoryId(null);
        student.setBedNo(null);
        if (targetDorm != null) {
            assignInternal(student, targetDorm, targetBed);
        } else {
            student.setStatus(student.getStatus() == null ? 2 : student.getStatus());
            studentMapper.insert(student);
        }
    }

    public void update(Student student) {
        Student old = studentMapper.selectById(student.getId());
        if (old == null) {
            throw new BusinessException(404, "学生不存在");
        }
        if (StringUtils.hasText(student.getStudentNo()) && !student.getStudentNo().equals(old.getStudentNo())) {
            if (studentMapper.selectCount(new LambdaQueryWrapper<Student>()
                    .eq(Student::getStudentNo, student.getStudentNo().trim())
                    .ne(Student::getId, student.getId())) > 0) {
                throw new BusinessException(400, "学号已存在");
            }
            old.setStudentNo(student.getStudentNo().trim());
        }
        old.setName(student.getName());
        old.setGender(student.getGender());
        old.setClassName(student.getClassName());
        old.setPhone(student.getPhone());
        studentMapper.updateById(old);

        if (old.getUserId() != null) {
            User account = userMapper.selectById(old.getUserId());
            if (account != null) {
                account.setRealName(old.getName());
                account.setPhone(old.getPhone());
                userMapper.updateById(account);
            }
        }
    }

    /**
     * 分配 / 调整宿舍：校验容量与床位，维护新旧宿舍已住人数
     */
    @Transactional
    public void assign(Long studentId, Long dormitoryId, Integer bedNo) {
        Student student = studentMapper.selectById(studentId);
        if (student == null) {
            throw new BusinessException(404, "学生不存在");
        }
        assignInternal(student, dormitoryId, bedNo);
    }

    private void assignInternal(Student student, Long dormitoryId, Integer bedNo) {
        Dormitory dorm = dormitoryMapper.selectById(dormitoryId);
        if (dorm == null) {
            throw new BusinessException(400, "宿舍不存在");
        }
        Long oldDormId = student.getDormitoryId();
        boolean sameDorm = dormitoryId.equals(oldDormId);
        if (!sameDorm) {
            if (dorm.getStatus() != null && dorm.getStatus() == 2) {
                throw new BusinessException(400, "该宿舍正在维修，不能安排入住");
            }
            if (dorm.getOccupied() != null && dorm.getCapacity() != null && dorm.getOccupied() >= dorm.getCapacity()) {
                throw new BusinessException(400, "该宿舍已满员（" + dorm.getCapacity() + " 人）");
            }
        }
        int bed = bedNo == null ? nextBed(dorm) : bedNo;
        if (bed < 1 || bed > dorm.getCapacity()) {
            throw new BusinessException(400, "床位号应在 1 - " + dorm.getCapacity() + " 之间");
        }
        Long bedUsed = studentMapper.selectCount(new LambdaQueryWrapper<Student>()
                .eq(Student::getDormitoryId, dormitoryId)
                .eq(Student::getBedNo, bed)
                .ne(student.getId() != null, Student::getId, student.getId()));
        if (bedUsed > 0) {
            throw new BusinessException(400, "该床位已有人入住，请选择其他床位");
        }

        // 换宿舍时释放旧宿舍名额
        if (oldDormId != null && !sameDorm) {
            decreaseOccupied(oldDormId);
        }

        student.setDormitoryId(dormitoryId);
        student.setBedNo(bed);
        student.setStatus(1);
        if (student.getId() == null) {
            studentMapper.insert(student);
        } else {
            studentMapper.updateById(student);
        }

        if (!sameDorm) {
            increaseOccupied(dormitoryId);
        }
    }

    @Transactional
    public void checkout(Long studentId) {
        Student student = studentMapper.selectById(studentId);
        if (student == null) {
            throw new BusinessException(404, "学生不存在");
        }
        if (student.getDormitoryId() == null) {
            throw new BusinessException(400, "该学生当前未分配宿舍");
        }
        decreaseOccupied(student.getDormitoryId());
        student.setDormitoryId(null);
        student.setBedNo(null);
        student.setStatus(0);
        studentMapper.updateById(student);
    }

    @Transactional
    public void delete(Long id) {
        Student student = studentMapper.selectById(id);
        if (student == null) {
            throw new BusinessException(404, "学生不存在");
        }
        if (student.getDormitoryId() != null) {
            decreaseOccupied(student.getDormitoryId());
        }
        studentMapper.deleteById(id);
        if (student.getUserId() != null) {
            userMapper.deleteById(student.getUserId());
        }
    }

    private int nextBed(Dormitory dorm) {
        List<Student> list = studentMapper.selectList(new LambdaQueryWrapper<Student>()
                .eq(Student::getDormitoryId, dorm.getId()));
        boolean[] used = new boolean[dorm.getCapacity() + 1];
        for (Student s : list) {
            if (s.getBedNo() != null && s.getBedNo() <= dorm.getCapacity()) {
                used[s.getBedNo()] = true;
            }
        }
        for (int i = 1; i <= dorm.getCapacity(); i++) {
            if (!used[i]) {
                return i;
            }
        }
        throw new BusinessException(400, "该宿舍已无空闲床位");
    }

    private void increaseOccupied(Long dormitoryId) {
        Dormitory d = dormitoryMapper.selectById(dormitoryId);
        if (d == null) {
            return;
        }
        int occupied = (d.getOccupied() == null ? 0 : d.getOccupied()) + 1;
        d.setOccupied(occupied);
        d.setStatus(occupied >= d.getCapacity() ? 1 : 0);
        dormitoryMapper.updateById(d);
    }

    private void decreaseOccupied(Long dormitoryId) {
        Dormitory d = dormitoryMapper.selectById(dormitoryId);
        if (d == null) {
            return;
        }
        int occupied = Math.max(0, (d.getOccupied() == null ? 0 : d.getOccupied()) - 1);
        d.setOccupied(occupied);
        d.setStatus(occupied >= d.getCapacity() ? 1 : 0);
        dormitoryMapper.updateById(d);
    }

    private Long currentManagerId() {
        LoginUser user = UserContext.get();
        return user != null && user.isManager() ? user.getId() : null;
    }
}
