package com.dorm.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.dorm.common.RequireRole;
import com.dorm.common.Result;
import com.dorm.entity.Visitor;
import com.dorm.service.VisitorService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 访客管理
 */
@RestController
@RequestMapping("/api/visitors")
@RequiredArgsConstructor
@RequireRole({"ADMIN", "MANAGER"})
public class VisitorController {

    private final VisitorService visitorService;

    @GetMapping
    public Result<IPage<Visitor>> page(@RequestParam(defaultValue = "1") long page,
                                       @RequestParam(defaultValue = "10") long size,
                                       @RequestParam(required = false) Integer status,
                                       @RequestParam(required = false) String keyword) {
        return Result.ok(visitorService.page(page, size, status, keyword));
    }

    @PostMapping
    public Result<Void> create(@RequestBody Visitor visitor) {
        visitorService.create(visitor);
        return Result.ok("访客登记成功", null);
    }

    @PutMapping("/{id}/leave")
    public Result<Void> leave(@PathVariable Long id) {
        visitorService.leave(id);
        return Result.ok("已核销离开", null);
    }
}
