package com.dorm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.entity.WaterElectric;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 水电费 Mapper
 */
public interface WaterElectricMapper extends BaseMapper<WaterElectric> {

    @Select("<script>" +
            "select w.*, d.room_no, d.building_id, b.name as building_name " +
            "from water_electric w " +
            "join dormitory d on w.dormitory_id = d.id " +
            "join building b on d.building_id = b.id " +
            "where 1 = 1 " +
            "<if test='billMonth != null and billMonth != \"\"'> and w.bill_month = #{billMonth} </if>" +
            "<if test='paid != null'> and w.paid = #{paid} </if>" +
            "<if test='buildingId != null'> and d.building_id = #{buildingId} </if>" +
            "<if test='managerId != null'> and b.manager_id = #{managerId} </if>" +
            "<if test='dormitoryId != null'> and w.dormitory_id = #{dormitoryId} </if>" +
            "order by w.bill_month desc, b.code, d.room_no" +
            "</script>")
    IPage<WaterElectric> selectPageDetail(Page<WaterElectric> page,
                                          @Param("billMonth") String billMonth,
                                          @Param("paid") Integer paid,
                                          @Param("buildingId") Long buildingId,
                                          @Param("managerId") Long managerId,
                                          @Param("dormitoryId") Long dormitoryId);

    @Select("select distinct bill_month from water_electric order by bill_month desc")
    List<String> selectMonths();
}
