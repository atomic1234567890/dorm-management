package com.dorm.controller;

import com.dorm.common.RequireRole;
import com.dorm.common.Result;
import com.dorm.service.DashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * 首页看板
 */
@RestController
@RequestMapping("/api/dashboard")
@RequiredArgsConstructor
@RequireRole({"ADMIN", "MANAGER"})
public class DashboardController {

    private final DashboardService dashboardService;

    @GetMapping("/stats")
    public Result<Map<String, Object>> stats() {
        return Result.ok(dashboardService.stats());
    }
}
