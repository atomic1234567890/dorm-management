package com.dorm.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 访客登记
 */
@Data
public class Visitor {

    @TableId(type = IdType.AUTO)
    private Long id;

    private String name;

    private String idCard;

    private String phone;

    private Long dormitoryId;

    private Long studentId;

    private LocalDateTime visitTime;

    private LocalDateTime leaveTime;

    /** 0 在访 / 1 已离开 */
    private Integer status;

    private Long registrarId;

    private String remark;

    private LocalDateTime createTime;

    @TableField(exist = false)
    private String roomNo;

    @TableField(exist = false)
    private String buildingName;

    @TableField(exist = false)
    private String studentName;

    @TableField(exist = false)
    private String registrarName;
}
