package com.dorm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.entity.AdjustRequest;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 调宿申请 Mapper
 */
public interface AdjustRequestMapper extends BaseMapper<AdjustRequest> {

    @Select("<script>" +
            "select a.*, s.name as student_name, s.student_no, " +
            "       df.room_no as from_room, bf.name as from_building, " +
            "       dt.room_no as to_room, bt.name as to_building, u.real_name as approver_name " +
            "from adjust_request a " +
            "join student s on a.student_id = s.id " +
            "left join dormitory df on a.from_dormitory_id = df.id " +
            "left join building bf on df.building_id = bf.id " +
            "left join dormitory dt on a.to_dormitory_id = dt.id " +
            "left join building bt on dt.building_id = bt.id " +
            "left join sys_user u on a.approver_id = u.id " +
            "where 1 = 1 " +
            "<if test='status != null'> and a.status = #{status} </if>" +
            "<if test='studentId != null'> and a.student_id = #{studentId} </if>" +
            "<if test='managerId != null'> and (bf.manager_id = #{managerId} or bt.manager_id = #{managerId}) </if>" +
            "order by a.create_time desc" +
            "</script>")
    IPage<AdjustRequest> selectPageDetail(Page<AdjustRequest> page,
                                          @Param("status") Integer status,
                                          @Param("studentId") Long studentId,
                                          @Param("managerId") Long managerId);

    @Select("select a.*, s.name as student_name, s.student_no, u.real_name as approver_name " +
            "from adjust_request a join student s on a.student_id = s.id " +
            "left join sys_user u on a.approver_id = u.id where a.id = #{id}")
    AdjustRequest selectDetail(Long id);

    @Select("select count(*) from adjust_request where student_id = #{studentId} and status = 0")
    int countPendingByStudent(Long studentId);

    @Select("select count(*) from adjust_request where status = 0")
    int countPending();

    @Select("select count(*) from adjust_request where status = 0 and (#{managerId} is null or student_id in (select s.id from student s join dormitory d on s.dormitory_id = d.id join building b on d.building_id = b.id where b.manager_id = #{managerId}))")
    int countPendingForManager(@Param("managerId") Long managerId);

    @Select("select * from adjust_request where status = 0")
    List<AdjustRequest> selectPendingAll();
}
