package com.dorm.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.common.BusinessException;
import com.dorm.common.LoginUser;
import com.dorm.common.UserContext;
import com.dorm.entity.Repair;
import com.dorm.entity.Student;
import com.dorm.entity.User;
import com.dorm.mapper.RepairMapper;
import com.dorm.mapper.StudentMapper;
import com.dorm.mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;

/**
 * 报修流程：提交 → 派单 → 维修中 → 完成 / 取消
 */
@Service
@RequiredArgsConstructor
public class RepairService {

    private final RepairMapper repairMapper;
    private final StudentMapper studentMapper;
    private final UserMapper userMapper;

    public IPage<Repair> page(long page, long size, Integer status, String keyword) {
        LoginUser user = UserContext.require();
        Long studentId = null;
        Long managerId = null;
        if (user.isStudent()) {
            Student student = studentMapper.selectByUserId(user.getId());
            if (student == null) {
                throw new BusinessException(403, "当前账号未关联学生档案");
            }
            studentId = student.getId();
        } else if (user.isManager()) {
            managerId = user.getId();
        }
        return repairMapper.selectPageDetail(new Page<>(page, size), status, studentId, managerId, null, keyword);
    }

    public Repair detail(Long id) {
        Repair repair = repairMapper.selectDetail(id);
        if (repair == null) {
            throw new BusinessException(404, "报修单不存在");
        }
        checkVisible(repair);
        return repair;
    }

    @Transactional
    public void create(Repair repair) {
        LoginUser user = UserContext.require();
        if (!user.isStudent()) {
            throw new BusinessException(403, "只有学生可以提交报修");
        }
        Student student = studentMapper.selectByUserId(user.getId());
        if (student == null) {
            throw new BusinessException(403, "当前账号未关联学生档案");
        }
        if (student.getDormitoryId() == null) {
            throw new BusinessException(400, "你还没有分配宿舍，无法报修");
        }
        if (!StringUtils.hasText(repair.getType()) || !StringUtils.hasText(repair.getDescription())) {
            throw new BusinessException(400, "请选择报修类型并填写问题描述");
        }
        repair.setId(null);
        repair.setStudentId(student.getId());
        repair.setDormitoryId(student.getDormitoryId());
        repair.setStatus(0);
        repair.setHandlerId(null);
        repair.setResult(null);
        repair.setDispatchTime(null);
        repair.setFinishTime(null);
        repair.setCreateTime(LocalDateTime.now());
        repairMapper.insert(repair);
    }

    @Transactional
    public void dispatch(Long id, Long handlerId) {
        Repair repair = repairMapper.selectById(id);
        if (repair == null) {
            throw new BusinessException(404, "报修单不存在");
        }
        if (repair.getStatus() != 0) {
            throw new BusinessException(400, "只有待派单的报修才能派单");
        }
        if (handlerId == null) {
            throw new BusinessException(400, "请选择维修人");
        }
        User handler = userMapper.selectById(handlerId);
        if (handler == null || (!"MANAGER".equals(handler.getRole()) && !"ADMIN".equals(handler.getRole()))) {
            throw new BusinessException(400, "维修人必须是宿管或管理员");
        }
        repair.setHandlerId(handlerId);
        repair.setStatus(1);
        repair.setDispatchTime(LocalDateTime.now());
        repairMapper.updateById(repair);
    }

    @Transactional
    public void finish(Long id, String result) {
        Repair repair = repairMapper.selectById(id);
        if (repair == null) {
            throw new BusinessException(404, "报修单不存在");
        }
        if (repair.getStatus() != 1) {
            throw new BusinessException(400, "只有维修中的报修才能标记完成");
        }
        if (!StringUtils.hasText(result)) {
            throw new BusinessException(400, "请填写处理结果");
        }
        LoginUser user = UserContext.require();
        if (user.isManager() && repair.getHandlerId() != null && !repair.getHandlerId().equals(user.getId())) {
            throw new BusinessException(403, "该报修单不是派给你的");
        }
        repair.setStatus(2);
        repair.setResult(result);
        repair.setFinishTime(LocalDateTime.now());
        if (repair.getHandlerId() == null) {
            repair.setHandlerId(user.getId());
        }
        repairMapper.updateById(repair);
    }

    @Transactional
    public void cancel(Long id) {
        Repair repair = repairMapper.selectById(id);
        if (repair == null) {
            throw new BusinessException(404, "报修单不存在");
        }
        LoginUser user = UserContext.require();
        if (user.isStudent()) {
            Student student = studentMapper.selectByUserId(user.getId());
            if (student == null || !student.getId().equals(repair.getStudentId())) {
                throw new BusinessException(403, "只能取消自己的报修");
            }
        } else if (!user.isAdmin()) {
            throw new BusinessException(403, "无权限取消该报修");
        }
        if (repair.getStatus() == 2) {
            throw new BusinessException(400, "已完成的报修不能取消");
        }
        repair.setStatus(3);
        repairMapper.updateById(repair);
    }

    private void checkVisible(Repair repair) {
        LoginUser user = UserContext.require();
        if (user.isStudent()) {
            Student student = studentMapper.selectByUserId(user.getId());
            if (student == null || !student.getId().equals(repair.getStudentId())) {
                throw new BusinessException(403, "无权查看该报修单");
            }
        } else if (user.isManager() && !user.getId().equals(repair.getHandlerId())) {
            // 宿管可以查看本楼栋的报修（列表已按楼栋过滤），详情允许查看
            if (repair.getBuildingId() != null) {
                return;
            }
        }
    }
}
