package com.dorm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.entity.Violation;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * 违纪记录 Mapper
 */
public interface ViolationMapper extends BaseMapper<Violation> {

    @Select("<script>" +
            "select v.*, s.name as student_name, s.student_no, s.class_name, " +
            "       d.room_no, d.building_id, b.name as building_name, u.real_name as recorder_name " +
            "from violation v " +
            "join student s on v.student_id = s.id " +
            "left join dormitory d on s.dormitory_id = d.id " +
            "left join building b on d.building_id = b.id " +
            "left join sys_user u on v.recorder_id = u.id " +
            "where 1 = 1 " +
            "<if test='studentId != null'> and v.student_id = #{studentId} </if>" +
            "<if test='managerId != null'> and b.manager_id = #{managerId} </if>" +
            "<if test='keyword != null and keyword != \"\"'>" +
            "  and (s.name like concat('%', #{keyword}, '%') or v.type like concat('%', #{keyword}, '%'))" +
            "</if>" +
            "order by v.record_date desc, v.id desc" +
            "</script>")
    IPage<Violation> selectPageDetail(Page<Violation> page,
                                      @Param("studentId") Long studentId,
                                      @Param("managerId") Long managerId,
                                      @Param("keyword") String keyword);
}
