package com.dorm.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * 楼栋
 */
@Data
public class Building {

    @TableId(type = IdType.AUTO)
    private Long id;

    /** 楼栋编号，如 A */
    private String code;

    private String name;

    /** 负责宿管 sys_user.id */
    private Long managerId;

    private Integer floors;

    private String remark;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    @TableField(exist = false)
    private String managerName;

    @TableField(exist = false)
    private Integer dormCount;

    @TableField(exist = false)
    private Integer occupied;

    @TableField(exist = false)
    private Integer capacity;
}
