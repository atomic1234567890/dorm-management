package com.dorm.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.dorm.common.RequireRole;
import com.dorm.common.Result;
import com.dorm.dto.AssignDTO;
import com.dorm.entity.Student;
import com.dorm.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 学生与入住管理
 */
@RestController
@RequestMapping("/api/students")
@RequiredArgsConstructor
public class StudentController {

    private final StudentService studentService;

    @GetMapping
    @RequireRole({"ADMIN", "MANAGER"})
    public Result<IPage<Student>> page(@RequestParam(defaultValue = "1") long page,
                                       @RequestParam(defaultValue = "10") long size,
                                       @RequestParam(required = false) Long buildingId,
                                       @RequestParam(required = false) Integer status,
                                       @RequestParam(required = false) String keyword) {
        return Result.ok(studentService.page(page, size, buildingId, status, keyword));
    }

    /** 学生端：我的宿舍信息 */
    @GetMapping("/my")
    @RequireRole("STUDENT")
    public Result<Student> my() {
        return Result.ok(studentService.my());
    }

    @GetMapping("/{id}")
    @RequireRole({"ADMIN", "MANAGER"})
    public Result<Student> detail(@PathVariable Long id) {
        return Result.ok(studentService.detail(id));
    }

    @PostMapping
    @RequireRole({"ADMIN", "MANAGER"})
    public Result<Void> create(@RequestBody Student student) {
        studentService.create(student);
        return Result.ok("新增成功，学生登录账号为学号，初始密码 123456", null);
    }

    @PutMapping("/{id}")
    @RequireRole({"ADMIN", "MANAGER"})
    public Result<Void> update(@PathVariable Long id, @RequestBody Student student) {
        student.setId(id);
        studentService.update(student);
        return Result.ok("保存成功", null);
    }

    /** 分配 / 调整宿舍 */
    @PutMapping("/{id}/assign")
    @RequireRole({"ADMIN", "MANAGER"})
    public Result<Void> assign(@PathVariable Long id, @RequestBody AssignDTO dto) {
        studentService.assign(id, dto.getDormitoryId(), dto.getBedNo());
        return Result.ok("宿舍分配成功", null);
    }

    @PutMapping("/{id}/checkout")
    @RequireRole({"ADMIN", "MANAGER"})
    public Result<Void> checkout(@PathVariable Long id) {
        studentService.checkout(id);
        return Result.ok("退宿成功", null);
    }

    @DeleteMapping("/{id}")
    @RequireRole("ADMIN")
    public Result<Void> delete(@PathVariable Long id) {
        studentService.delete(id);
        return Result.ok("删除成功", null);
    }
}
