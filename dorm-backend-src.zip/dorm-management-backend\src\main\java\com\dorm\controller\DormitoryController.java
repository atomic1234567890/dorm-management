package com.dorm.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.dorm.common.RequireRole;
import com.dorm.common.Result;
import com.dorm.entity.Dormitory;
import com.dorm.entity.Student;
import com.dorm.service.DormitoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 宿舍管理
 */
@RestController
@RequestMapping("/api/dormitories")
@RequiredArgsConstructor
public class DormitoryController {

    private final DormitoryService dormitoryService;

    @GetMapping
    public Result<IPage<Dormitory>> page(@RequestParam(defaultValue = "1") long page,
                                         @RequestParam(defaultValue = "10") long size,
                                         @RequestParam(required = false) Long buildingId,
                                         @RequestParam(required = false) Integer status,
                                         @RequestParam(required = false) String keyword) {
        return Result.ok(dormitoryService.page(page, size, buildingId, status, keyword));
    }

    @GetMapping("/{id}")
    public Result<Dormitory> detail(@PathVariable Long id) {
        return Result.ok(dormitoryService.detail(id));
    }

    @GetMapping("/{id}/students")
    public Result<List<Student>> students(@PathVariable Long id) {
        return Result.ok(dormitoryService.students(id));
    }

    @GetMapping("/available")
    public Result<List<Dormitory>> available(@RequestParam(required = false) Long buildingId) {
        return Result.ok(dormitoryService.available(buildingId));
    }

    @PostMapping
    @RequireRole({"ADMIN", "MANAGER"})
    public Result<Void> create(@RequestBody Dormitory dormitory) {
        dormitoryService.create(dormitory);
        return Result.ok("新增成功", null);
    }

    @PutMapping("/{id}")
    @RequireRole({"ADMIN", "MANAGER"})
    public Result<Void> update(@PathVariable Long id, @RequestBody Dormitory dormitory) {
        dormitory.setId(id);
        dormitoryService.update(dormitory);
        return Result.ok("保存成功", null);
    }

    @DeleteMapping("/{id}")
    @RequireRole("ADMIN")
    public Result<Void> delete(@PathVariable Long id) {
        dormitoryService.delete(id);
        return Result.ok("删除成功", null);
    }
}
