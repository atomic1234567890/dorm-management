package com.dorm.dto;

import lombok.Data;

/**
 * 登录成功后返回给前端的信息
 */
@Data
public class LoginVO {

    private String token;
    private Long id;
    private String username;
    private String realName;
    private String role;
    private String phone;
    /** 学生登录时返回其学生档案 id */
    private Long studentId;
    /** 宿管登录时返回负责楼栋名称 */
    private String buildingName;
}
