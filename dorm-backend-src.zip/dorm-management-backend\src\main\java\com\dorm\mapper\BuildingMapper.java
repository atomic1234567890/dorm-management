package com.dorm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.entity.Building;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * 楼栋 Mapper
 */
public interface BuildingMapper extends BaseMapper<Building> {

    /**
     * 分页查询楼栋，并统计每栋楼的房间数、床位数、已住人数
     */
    @Select("<script>" +
            "select b.*, u.real_name as manager_name, " +
            "       count(d.id) as dorm_count, " +
            "       coalesce(sum(d.occupied), 0) as occupied, " +
            "       coalesce(sum(d.capacity), 0) as capacity " +
            "from building b " +
            "left join sys_user u on b.manager_id = u.id " +
            "left join dormitory d on d.building_id = b.id " +
            "where 1 = 1 " +
            "<if test='keyword != null and keyword != \"\"'>" +
            "  and (b.name like concat('%', #{keyword}, '%') or b.code like concat('%', #{keyword}, '%'))" +
            "</if>" +
            "group by b.id, u.real_name " +
            "order by b.code" +
            "</script>")
    IPage<Building> selectPageWithStats(Page<Building> page, @Param("keyword") String keyword);
}
