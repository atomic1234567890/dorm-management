package com.dorm.controller;

import com.dorm.common.Result;
import com.dorm.dto.LoginDTO;
import com.dorm.dto.LoginVO;
import com.dorm.dto.PasswordDTO;
import com.dorm.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 登录 / 当前用户 / 修改密码
 */
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;

    @PostMapping("/login")
    public Result<LoginVO> login(@RequestBody LoginDTO dto) {
        return Result.ok("登录成功", authService.login(dto));
    }

    @GetMapping("/me")
    public Result<LoginVO> me() {
        return Result.ok(authService.me());
    }

    @PostMapping("/password")
    public Result<Void> changePassword(@RequestBody PasswordDTO dto) {
        authService.changePassword(dto);
        return Result.ok("密码修改成功", null);
    }
}
