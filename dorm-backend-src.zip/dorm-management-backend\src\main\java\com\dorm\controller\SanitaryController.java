package com.dorm.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.dorm.common.RequireRole;
import com.dorm.common.Result;
import com.dorm.entity.Sanitary;
import com.dorm.service.SanitaryService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * 卫生检查
 */
@RestController
@RequestMapping("/api/sanitary")
@RequiredArgsConstructor
@RequireRole({"ADMIN", "MANAGER"})
public class SanitaryController {

    private final SanitaryService sanitaryService;

    @GetMapping
    public Result<IPage<Sanitary>> page(@RequestParam(defaultValue = "1") long page,
                                        @RequestParam(defaultValue = "10") long size,
                                        @RequestParam(required = false) Long dormitoryId) {
        return Result.ok(sanitaryService.page(page, size, dormitoryId));
    }

    @PostMapping
    public Result<Void> create(@RequestBody Sanitary sanitary) {
        sanitaryService.create(sanitary);
        return Result.ok("卫生记录已保存", null);
    }

    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        sanitaryService.delete(id);
        return Result.ok("删除成功", null);
    }
}
