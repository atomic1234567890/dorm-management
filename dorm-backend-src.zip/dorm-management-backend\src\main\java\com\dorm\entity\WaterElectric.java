package com.dorm.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 水电费（按宿舍 + 月份）
 */
@Data
public class WaterElectric {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long dormitoryId;

    /** yyyy-MM */
    private String billMonth;

    private BigDecimal waterUsage;

    private BigDecimal waterFee;

    private BigDecimal electricUsage;

    private BigDecimal electricFee;

    private BigDecimal totalFee;

    /** 0 未缴 / 1 已缴 */
    private Integer paid;

    private LocalDateTime payTime;

    private LocalDateTime createTime;

    private LocalDateTime updateTime;

    @TableField(exist = false)
    private String roomNo;

    @TableField(exist = false)
    private String buildingName;

    @TableField(exist = false)
    private Long buildingId;
}
