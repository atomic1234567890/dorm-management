package com.dorm.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.common.BusinessException;
import com.dorm.common.LoginUser;
import com.dorm.common.UserContext;
import com.dorm.entity.AdjustRequest;
import com.dorm.entity.Dormitory;
import com.dorm.entity.Student;
import com.dorm.mapper.AdjustRequestMapper;
import com.dorm.mapper.DormitoryMapper;
import com.dorm.mapper.StudentMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.List;

/**
 * 调宿申请与审批
 */
@Service
@RequiredArgsConstructor
public class AdjustService {

    private final AdjustRequestMapper adjustRequestMapper;
    private final StudentMapper studentMapper;
    private final DormitoryMapper dormitoryMapper;
    private final StudentService studentService;

    public IPage<AdjustRequest> page(long page, long size, Integer status) {
        LoginUser user = UserContext.require();
        Long studentId = null;
        Long managerId = null;
        if (user.isStudent()) {
            Student student = studentMapper.selectByUserId(user.getId());
            if (student != null) {
                studentId = student.getId();
            }
        } else if (user.isManager()) {
            managerId = user.getId();
        }
        return adjustRequestMapper.selectPageDetail(new Page<>(page, size), status, studentId, managerId);
    }

    public List<AdjustRequest> pendingForManager(Long managerId) {
        return adjustRequestMapper.selectPendingAll();
    }

    @Transactional
    public void apply(AdjustRequest request) {
        LoginUser user = UserContext.require();
        Student student = studentMapper.selectByUserId(user.getId());
        if (student == null) {
            throw new BusinessException(403, "当前账号未关联学生档案");
        }
        if (student.getDormitoryId() == null) {
            throw new BusinessException(400, "你还没有分配宿舍，无需申请调宿");
        }
        if (!StringUtils.hasText(request.getReason())) {
            throw new BusinessException(400, "请填写调宿理由");
        }
        if (request.getToDormitoryId() != null && request.getToDormitoryId().equals(student.getDormitoryId())) {
            throw new BusinessException(400, "目标宿舍与当前宿舍相同");
        }
        if (adjustRequestMapper.countPendingByStudent(student.getId()) > 0) {
            throw new BusinessException(400, "你有一条待审批的调宿申请，请勿重复提交");
        }
        request.setId(null);
        request.setStudentId(student.getId());
        request.setFromDormitoryId(student.getDormitoryId());
        request.setStatus(0);
        request.setApproverId(null);
        request.setApproveTime(null);
        request.setCreateTime(LocalDateTime.now());
        adjustRequestMapper.insert(request);
    }

    @Transactional
    public void approve(Long id, Boolean approve, String remark) {
        AdjustRequest request = adjustRequestMapper.selectById(id);
        if (request == null) {
            throw new BusinessException(404, "调宿申请不存在");
        }
        if (request.getStatus() != 0) {
            throw new BusinessException(400, "该申请已处理");
        }
        LoginUser user = UserContext.require();
        if (!user.isAdmin() && !user.isManager()) {
            throw new BusinessException(403, "无审批权限");
        }
        if (user.isManager()) {
            checkManagerScope(request, user.getId());
        }

        if (Boolean.TRUE.equals(approve)) {
            if (request.getToDormitoryId() == null) {
                throw new BusinessException(400, "申请未指定目标宿舍，无法通过，请驳回并让学生重新申请");
            }
            Dormitory target = dormitoryMapper.selectById(request.getToDormitoryId());
            if (target == null) {
                throw new BusinessException(400, "目标宿舍不存在");
            }
            if (target.getOccupied() >= target.getCapacity()) {
                throw new BusinessException(400, "目标宿舍已满员，无法通过该申请");
            }
            // 复用入住逻辑：校验床位、维护新旧宿舍人数
            studentService.assign(request.getStudentId(), request.getToDormitoryId(), null);
            request.setStatus(1);
        } else {
            request.setStatus(2);
        }
        request.setApproverId(user.getId());
        request.setApproveRemark(remark);
        request.setApproveTime(LocalDateTime.now());
        adjustRequestMapper.updateById(request);
    }

    private void checkManagerScope(AdjustRequest request, Long managerId) {
        Dormitory from = request.getFromDormitoryId() == null ? null
                : dormitoryMapper.selectDetail(request.getFromDormitoryId());
        Dormitory to = request.getToDormitoryId() == null ? null
                : dormitoryMapper.selectDetail(request.getToDormitoryId());
        boolean involved = (from != null && managerId.equals(from.getManagerId()))
                || (to != null && managerId.equals(to.getManagerId()));
        if (!involved) {
            throw new BusinessException(403, "只能审批自己负责楼栋的调宿申请");
        }
    }
}
