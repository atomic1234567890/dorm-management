package com.dorm.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.common.BusinessException;
import com.dorm.entity.Building;
import com.dorm.entity.Dormitory;
import com.dorm.entity.User;
import com.dorm.mapper.BuildingMapper;
import com.dorm.mapper.DormitoryMapper;
import com.dorm.mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;

/**
 * 楼栋管理
 */
@Service
@RequiredArgsConstructor
public class BuildingService {

    private final BuildingMapper buildingMapper;
    private final DormitoryMapper dormitoryMapper;
    private final UserMapper userMapper;

    public IPage<Building> page(long page, long size, String keyword) {
        return buildingMapper.selectPageWithStats(new Page<>(page, size), keyword);
    }

    public List<Building> options() {
        return buildingMapper.selectList(new LambdaQueryWrapper<Building>().orderByAsc(Building::getCode));
    }

    public void create(Building building) {
        check(building, null);
        building.setId(null);
        if (building.getFloors() == null || building.getFloors() < 1) {
            building.setFloors(6);
        }
        buildingMapper.insert(building);
    }

    public void update(Building building) {
        Building old = buildingMapper.selectById(building.getId());
        if (old == null) {
            throw new BusinessException(404, "楼栋不存在");
        }
        check(building, building.getId());
        buildingMapper.updateById(building);
    }

    public void delete(Long id) {
        Long dormCount = dormitoryMapper.selectCount(new LambdaQueryWrapper<Dormitory>()
                .eq(Dormitory::getBuildingId, id));
        if (dormCount > 0) {
            throw new BusinessException(400, "该楼栋下还有 " + dormCount + " 间宿舍，请先删除宿舍");
        }
        buildingMapper.deleteById(id);
    }

    private void check(Building building, Long excludeId) {
        if (!StringUtils.hasText(building.getCode()) || !StringUtils.hasText(building.getName())) {
            throw new BusinessException(400, "楼栋编号和名称不能为空");
        }
        LambdaQueryWrapper<Building> qw = new LambdaQueryWrapper<Building>()
                .eq(Building::getCode, building.getCode().trim());
        if (excludeId != null) {
            qw.ne(Building::getId, excludeId);
        }
        if (buildingMapper.selectCount(qw) > 0) {
            throw new BusinessException(400, "楼栋编号已存在");
        }
        if (building.getManagerId() != null) {
            User manager = userMapper.selectById(building.getManagerId());
            if (manager == null || !"MANAGER".equals(manager.getRole())) {
                throw new BusinessException(400, "所选负责人不是宿管账号");
            }
        }
        building.setCode(building.getCode().trim());
    }
}
