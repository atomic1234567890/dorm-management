package com.dorm.service;

import com.alibaba.excel.EasyExcel;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.common.LoginUser;
import com.dorm.common.UserContext;
import com.dorm.entity.Repair;
import com.dorm.entity.Student;
import com.dorm.mapper.RepairMapper;
import com.dorm.mapper.StudentMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Excel 导出（学生名单、报修记录）
 */
@Service
@RequiredArgsConstructor
public class ExportService {

    private final StudentMapper studentMapper;
    private final RepairMapper repairMapper;

    public void exportStudents(HttpServletResponse response, String keyword, Long buildingId) throws IOException {
        LoginUser user = UserContext.require();
        Long managerId = user.isManager() ? user.getId() : null;
        IPage<Student> page = studentMapper.selectPageWithDorm(
                new Page<>(1, 100000), buildingId, managerId, null, keyword);

        List<List<String>> head = head("学号", "姓名", "性别", "班级", "联系电话", "楼栋", "宿舍号", "床位号", "状态");
        List<List<Object>> rows = new ArrayList<>();
        for (Student s : page.getRecords()) {
            rows.add(Arrays.asList(
                    s.getStudentNo(),
                    s.getName(),
                    s.getGender() != null && s.getGender() == 1 ? "男" : "女",
                    s.getClassName(),
                    s.getPhone(),
                    s.getBuildingName(),
                    s.getRoomNo(),
                    s.getBedNo(),
                    statusText(s.getStatus())
            ));
        }
        write(response, "学生名单", head, rows);
    }

    public void exportRepairs(HttpServletResponse response, Integer status, String keyword) throws IOException {
        LoginUser user = UserContext.require();
        Long studentId = null;
        Long managerId = null;
        if (user.isStudent()) {
            Student student = studentMapper.selectByUserId(user.getId());
            studentId = student == null ? -1L : student.getId();
        } else if (user.isManager()) {
            managerId = user.getId();
        }
        IPage<Repair> page = repairMapper.selectPageDetail(
                new Page<>(1, 100000), status, studentId, managerId, null, keyword);

        List<List<String>> head = head("报修编号", "报修人", "学号", "楼栋", "宿舍号", "类型", "问题描述",
                "状态", "维修人", "报修时间", "完成时间", "处理结果");
        List<List<Object>> rows = new ArrayList<>();
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        for (Repair r : page.getRecords()) {
            rows.add(Arrays.asList(
                    r.getId(),
                    r.getStudentName(),
                    r.getStudentNo(),
                    r.getBuildingName(),
                    r.getRoomNo(),
                    r.getType(),
                    r.getDescription(),
                    repairStatusText(r.getStatus()),
                    r.getHandlerName(),
                    format(r.getCreateTime(), fmt),
                    format(r.getFinishTime(), fmt),
                    r.getResult()
            ));
        }
        write(response, "报修记录", head, rows);
    }

    private void write(HttpServletResponse response, String fileName,
                       List<List<String>> head, List<List<Object>> rows) throws IOException {
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setCharacterEncoding("UTF-8");
        String encoded = URLEncoder.encode(fileName + "_" +
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + ".xlsx",
                StandardCharsets.UTF_8.name()).replaceAll("\\+", "%20");
        response.setHeader("Content-Disposition", "attachment;filename*=UTF-8''" + encoded);
        EasyExcel.write(response.getOutputStream())
                .head(head)
                .sheet(fileName)
                .doWrite(rows);
    }

    private List<List<String>> head(String... titles) {
        List<List<String>> head = new ArrayList<>();
        for (String title : titles) {
            head.add(java.util.Collections.singletonList(title));
        }
        return head;
    }

    private String format(LocalDateTime time, DateTimeFormatter fmt) {
        return time == null ? "" : time.format(fmt);
    }

    private String statusText(Integer status) {
        if (status == null) {
            return "";
        }
        switch (status) {
            case 1:
                return "在住";
            case 0:
                return "退宿";
            default:
                return "待分配";
        }
    }

    private String repairStatusText(Integer status) {
        if (status == null) {
            return "";
        }
        switch (status) {
            case 0:
                return "待派单";
            case 1:
                return "维修中";
            case 2:
                return "已完成";
            default:
                return "已取消";
        }
    }
}
