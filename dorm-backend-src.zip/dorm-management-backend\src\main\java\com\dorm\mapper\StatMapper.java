package com.dorm.mapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * 首页看板统计 Mapper
 * managerId 为 null 表示全校范围，否则只统计该宿管负责的楼栋
 */
public interface StatMapper {

    @Select("select count(*) from dormitory d join building b on d.building_id = b.id " +
            "where (#{managerId} is null or b.manager_id = #{managerId})")
    int dormCount(@Param("managerId") Long managerId);

    @Select("select coalesce(sum(d.capacity), 0) from dormitory d join building b on d.building_id = b.id " +
            "where (#{managerId} is null or b.manager_id = #{managerId})")
    int bedCount(@Param("managerId") Long managerId);

    @Select("select coalesce(sum(d.occupied), 0) from dormitory d join building b on d.building_id = b.id " +
            "where (#{managerId} is null or b.manager_id = #{managerId})")
    int occupiedCount(@Param("managerId") Long managerId);

    @Select("select count(*) from student s left join dormitory d on s.dormitory_id = d.id " +
            "left join building b on d.building_id = b.id " +
            "where s.status = 1 and (#{managerId} is null or b.manager_id = #{managerId})")
    int residentCount(@Param("managerId") Long managerId);

    @Select("select count(*) from repair r join dormitory d on r.dormitory_id = d.id " +
            "join building b on d.building_id = b.id " +
            "where r.status in (0, 1) and (#{managerId} is null or b.manager_id = #{managerId})")
    int pendingRepairCount(@Param("managerId") Long managerId);

    @Select("select count(*) from visitor v join dormitory d on v.dormitory_id = d.id " +
            "join building b on d.building_id = b.id " +
            "where v.status = 0 and (#{managerId} is null or b.manager_id = #{managerId})")
    int visitingCount(@Param("managerId") Long managerId);

    @Select("select count(*) from water_electric w join dormitory d on w.dormitory_id = d.id " +
            "join building b on d.building_id = b.id " +
            "where w.paid = 0 and (#{managerId} is null or b.manager_id = #{managerId})")
    int unpaidCount(@Param("managerId") Long managerId);

    @Select("select coalesce(sum(w.total_fee), 0) from water_electric w join dormitory d on w.dormitory_id = d.id " +
            "join building b on d.building_id = b.id " +
            "where w.paid = 0 and (#{managerId} is null or b.manager_id = #{managerId})")
    BigDecimal unpaidAmount(@Param("managerId") Long managerId);

    @Select("select b.id as id, b.name as name, " +
            "       coalesce(sum(d.occupied), 0) as occupied, coalesce(sum(d.capacity), 0) as capacity " +
            "from building b left join dormitory d on d.building_id = b.id " +
            "where (#{managerId} is null or b.manager_id = #{managerId}) " +
            "group by b.id, b.name, b.code order by b.code")
    List<Map<String, Object>> buildingStats(@Param("managerId") Long managerId);

    /** 近 N 天报修量，日期格式 MM-dd */
    @Select("select date_format(r.create_time, '%m-%d') as day, count(*) as total " +
            "from repair r join dormitory d on r.dormitory_id = d.id join building b on d.building_id = b.id " +
            "where r.create_time >= date_sub(curdate(), interval #{days} day) " +
            "and (#{managerId} is null or b.manager_id = #{managerId}) " +
            "group by day order by day")
    List<Map<String, Object>> repairTrend(@Param("days") int days, @Param("managerId") Long managerId);

    /** 各报修类型数量 */
    @Select("select r.type as type, count(*) as total from repair r " +
            "join dormitory d on r.dormitory_id = d.id join building b on d.building_id = b.id " +
            "where (#{managerId} is null or b.manager_id = #{managerId}) group by r.type")
    List<Map<String, Object>> repairTypeStats(@Param("managerId") Long managerId);
}
