package com.dorm.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.common.BusinessException;
import com.dorm.common.LoginUser;
import com.dorm.common.UserContext;
import com.dorm.entity.Dormitory;
import com.dorm.entity.Visitor;
import com.dorm.mapper.DormitoryMapper;
import com.dorm.mapper.VisitorMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;

/**
 * 访客登记与离开核销
 */
@Service
@RequiredArgsConstructor
public class VisitorService {

    private final VisitorMapper visitorMapper;
    private final DormitoryMapper dormitoryMapper;

    public IPage<Visitor> page(long page, long size, Integer status, String keyword) {
        LoginUser user = UserContext.require();
        Long managerId = user.isManager() ? user.getId() : null;
        return visitorMapper.selectPageDetail(new Page<>(page, size), status, managerId, keyword);
    }

    @Transactional
    public void create(Visitor visitor) {
        if (!StringUtils.hasText(visitor.getName())) {
            throw new BusinessException(400, "访客姓名不能为空");
        }
        if (visitor.getDormitoryId() == null) {
            throw new BusinessException(400, "请选择来访宿舍");
        }
        Dormitory dorm = dormitoryMapper.selectById(visitor.getDormitoryId());
        if (dorm == null) {
            throw new BusinessException(400, "来访宿舍不存在");
        }
        LoginUser user = UserContext.require();
        if (user.isManager()) {
            Dormitory detail = dormitoryMapper.selectDetail(dorm.getId());
            if (detail != null && detail.getManagerId() != null && !detail.getManagerId().equals(user.getId())) {
                throw new BusinessException(403, "只能登记自己负责楼栋的访客");
            }
        }
        visitor.setId(null);
        visitor.setStatus(0);
        visitor.setLeaveTime(null);
        visitor.setRegistrarId(user.getId());
        if (visitor.getVisitTime() == null) {
            visitor.setVisitTime(LocalDateTime.now());
        }
        visitorMapper.insert(visitor);
    }

    @Transactional
    public void leave(Long id) {
        Visitor visitor = visitorMapper.selectById(id);
        if (visitor == null) {
            throw new BusinessException(404, "访客记录不存在");
        }
        if (visitor.getStatus() != null && visitor.getStatus() == 1) {
            throw new BusinessException(400, "该访客已离开");
        }
        visitor.setStatus(1);
        visitor.setLeaveTime(LocalDateTime.now());
        visitorMapper.updateById(visitor);
    }
}
