package com.dorm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.entity.Sanitary;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * 卫生检查 Mapper
 */
public interface SanitaryMapper extends BaseMapper<Sanitary> {

    @Select("<script>" +
            "select s.*, d.room_no, d.building_id, b.name as building_name, u.real_name as checker_name " +
            "from sanitary s " +
            "join dormitory d on s.dormitory_id = d.id " +
            "join building b on d.building_id = b.id " +
            "left join sys_user u on s.checker_id = u.id " +
            "where 1 = 1 " +
            "<if test='dormitoryId != null'> and s.dormitory_id = #{dormitoryId} </if>" +
            "<if test='managerId != null'> and b.manager_id = #{managerId} </if>" +
            "<if test='buildingId != null'> and d.building_id = #{buildingId} </if>" +
            "order by s.check_date desc, s.id desc" +
            "</script>")
    IPage<Sanitary> selectPageDetail(Page<Sanitary> page,
                                     @Param("dormitoryId") Long dormitoryId,
                                     @Param("managerId") Long managerId,
                                     @Param("buildingId") Long buildingId);
}
