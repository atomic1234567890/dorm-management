package com.dorm.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dorm.entity.Student;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * 学生 Mapper
 */
public interface StudentMapper extends BaseMapper<Student> {

    @Select("<script>" +
            "select s.*, d.room_no, d.building_id, b.name as building_name, b.code as building_code " +
            "from student s " +
            "left join dormitory d on s.dormitory_id = d.id " +
            "left join building b on d.building_id = b.id " +
            "where 1 = 1 " +
            "<if test='buildingId != null'> and d.building_id = #{buildingId} </if>" +
            "<if test='managerId != null'> and b.manager_id = #{managerId} </if>" +
            "<if test='status != null'> and s.status = #{status} </if>" +
            "<if test='keyword != null and keyword != \"\"'>" +
            "  and (s.name like concat('%', #{keyword}, '%') " +
            "       or s.student_no like concat('%', #{keyword}, '%') " +
            "       or s.class_name like concat('%', #{keyword}, '%'))" +
            "</if>" +
            "order by s.student_no" +
            "</script>")
    IPage<Student> selectPageWithDorm(Page<Student> page,
                                      @Param("buildingId") Long buildingId,
                                      @Param("managerId") Long managerId,
                                      @Param("status") Integer status,
                                      @Param("keyword") String keyword);

    @Select("select s.*, d.room_no, d.building_id, b.name as building_name, b.code as building_code " +
            "from student s left join dormitory d on s.dormitory_id = d.id " +
            "left join building b on d.building_id = b.id where s.user_id = #{userId}")
    Student selectByUserId(Long userId);

    @Select("select s.*, d.room_no, d.building_id, b.name as building_name, b.code as building_code " +
            "from student s left join dormitory d on s.dormitory_id = d.id " +
            "left join building b on d.building_id = b.id where s.id = #{id}")
    Student selectDetail(Long id);
}
