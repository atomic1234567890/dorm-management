<template>
  <div class="page-card">
    <h3 class="page-title">宿舍管理</h3>
    <div class="toolbar">
      <el-select v-model="query.buildingId" placeholder="全部楼栋" clearable style="width: 170px" @change="search">
        <el-option v-for="b in buildings" :key="b.id" :label="b.name" :value="b.id" />
      </el-select>
      <el-select v-model="query.status" placeholder="全部状态" clearable style="width: 140px" @change="search">
        <el-option label="正常" :value="0" />
        <el-option label="满员" :value="1" />
        <el-option label="维修中" :value="2" />
      </el-select>
      <el-input v-model="query.keyword" placeholder="搜索宿舍号" clearable style="width: 180px" @keyup.enter="search" />
      <el-button type="primary" @click="search">查询</el-button>
      <el-button @click="reset">重置</el-button>
      <div class="spacer"></div>
      <el-button type="primary" @click="openDialog()">
        <el-icon><Plus /></el-icon> 新增宿舍
      </el-button>
    </div>

    <el-table :data="list" v-loading="loading" stripe border>
      <el-table-column prop="buildingName" label="楼栋" min-width="140" />
      <el-table-column prop="roomNo" label="宿舍号" width="100" />
      <el-table-column prop="floor" label="楼层" width="80" />
      <el-table-column label="入住情况" width="150">
        <template #default="{ row }">
          <span>{{ row.occupied }} / {{ row.capacity }} 人</span>
          <el-progress :percentage="rate(row)" :stroke-width="6" :show-text="false" style="margin-top: 4px" />
        </template>
      </el-table-column>
      <el-table-column label="状态" width="100">
        <template #default="{ row }">
          <el-tag :type="statusType(row.status)" effect="light">{{ statusText(row.status) }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="remark" label="备注" min-width="140" show-overflow-tooltip />
      <el-table-column label="操作" width="200" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" @click="showStudents(row)">住宿学生</el-button>
          <el-button link type="primary" @click="openDialog(row)">编辑</el-button>
          <el-button link type="danger" v-if="store.isAdmin" @click="remove(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        v-model:current-page="query.page"
        v-model:page-size="query.size"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next"
        @current-change="load"
        @size-change="search"
      />
    </div>

    <el-dialog v-model="dialogVisible" :title="form.id ? '编辑宿舍' : '新增宿舍'" width="480px">
      <el-form :model="form" label-width="90px">
        <el-form-item label="所属楼栋" required>
          <el-select v-model="form.buildingId" placeholder="请选择楼栋" style="width: 100%">
            <el-option v-for="b in buildings" :key="b.id" :label="b.name" :value="b.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="宿舍号" required>
          <el-input v-model="form.roomNo" placeholder="如 101" maxlength="20" />
        </el-form-item>
        <el-form-item label="楼层" required>
          <el-input-number v-model="form.floor" :min="1" :max="30" />
        </el-form-item>
        <el-form-item label="最大人数">
          <el-input-number v-model="form.capacity" :min="1" :max="12" />
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="form.status" style="width: 100%">
            <el-option label="正常" :value="0" />
            <el-option label="满员" :value="1" />
            <el-option label="维修中" :value="2" />
          </el-select>
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="form.remark" type="textarea" :rows="2" maxlength="255" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="save">保存</el-button>
      </template>
    </el-dialog>

    <el-drawer v-model="drawerVisible" :title="`${currentRoom} 住宿学生`" size="460px">
      <el-table :data="students" stripe>
        <el-table-column prop="bedNo" label="床位" width="70" />
        <el-table-column prop="name" label="姓名" width="100" />
        <el-table-column prop="studentNo" label="学号" width="120" />
        <el-table-column prop="className" label="班级" />
        <el-table-column prop="phone" label="电话" width="130" />
      </el-table>
      <el-empty v-if="students.length === 0" description="该宿舍暂无学生入住" />
    </el-drawer>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { buildingApi, dormitoryApi } from '../../api'
import { useUserStore } from '../../stores/user'

const store = useUserStore()
const loading = ref(false)
const saving = ref(false)
const list = ref([])
const total = ref(0)
const buildings = ref([])
const dialogVisible = ref(false)
const drawerVisible = ref(false)
const students = ref([])
const currentRoom = ref('')

const query = reactive({ page: 1, size: 10, buildingId: null, status: null, keyword: '' })
const form = reactive({ id: null, buildingId: null, roomNo: '', floor: 1, capacity: 6, status: 0, remark: '' })

function rate (row) {
  if (!row.capacity) return 0
  return Math.round((row.occupied || 0) * 100 / row.capacity)
}

function statusText (s) {
  return { 0: '正常', 1: '满员', 2: '维修中' }[s] || '未知'
}

function statusType (s) {
  return { 0: 'success', 1: 'warning', 2: 'danger' }[s] || 'info'
}

async function load () {
  loading.value = true
  try {
    const res = await dormitoryApi.page(query)
    list.value = res.data.records
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

function search () {
  query.page = 1
  load()
}

function reset () {
  query.buildingId = null
  query.status = null
  query.keyword = ''
  search()
}

async function loadBuildings () {
  const res = await buildingApi.options()
  buildings.value = res.data
}

function openDialog (row) {
  Object.assign(form, { id: null, buildingId: null, roomNo: '', floor: 1, capacity: 6, status: 0, remark: '' })
  if (row) {
    Object.assign(form, row)
  }
  dialogVisible.value = true
}

async function save () {
  if (!form.buildingId || !form.roomNo || !form.floor) {
    ElMessage.warning('请填写楼栋、宿舍号和楼层')
    return
  }
  saving.value = true
  try {
    if (form.id) {
      await dormitoryApi.update(form.id, form)
      ElMessage.success('保存成功')
    } else {
      await dormitoryApi.create(form)
      ElMessage.success('新增成功')
    }
    dialogVisible.value = false
    load()
  } finally {
    saving.value = false
  }
}

function remove (row) {
  ElMessageBox.confirm(`确定删除宿舍「${row.buildingName} ${row.roomNo}」吗？`, '提示', { type: 'warning' })
    .then(async () => {
      await dormitoryApi.remove(row.id)
      ElMessage.success('删除成功')
      load()
    })
    .catch(() => {})
}

async function showStudents (row) {
  currentRoom.value = `${row.buildingName} ${row.roomNo}`
  const res = await dormitoryApi.students(row.id)
  students.value = res.data
  drawerVisible.value = true
}

onMounted(() => {
  load()
  loadBuildings()
})
</script>
