import { createRouter, createWebHistory } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useUserStore } from '../stores/user'
import Layout from '../layout/index.vue'

const routes = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/login/index.vue'),
    meta: { public: true, title: '登录' }
  },
  {
    path: '/',
    component: Layout,
    redirect: '/dashboard',
    children: [
      {
        path: 'dashboard',
        component: () => import('../views/dashboard/index.vue'),
        meta: { title: '数据看板', roles: ['ADMIN', 'MANAGER'] }
      },
      {
        path: 'my-dorm',
        component: () => import('../views/my-dorm/index.vue'),
        meta: { title: '我的宿舍', roles: ['STUDENT'] }
      },
      {
        path: 'buildings',
        component: () => import('../views/building/index.vue'),
        meta: { title: '楼栋管理', roles: ['ADMIN'] }
      },
      {
        path: 'dormitories',
        component: () => import('../views/dormitory/index.vue'),
        meta: { title: '宿舍管理', roles: ['ADMIN', 'MANAGER'] }
      },
      {
        path: 'students',
        component: () => import('../views/student/index.vue'),
        meta: { title: '学生入住', roles: ['ADMIN', 'MANAGER'] }
      },
      {
        path: 'repairs',
        component: () => import('../views/repair/index.vue'),
        meta: { title: '报修管理', roles: ['ADMIN', 'MANAGER', 'STUDENT'] }
      },
      {
        path: 'visitors',
        component: () => import('../views/visitor/index.vue'),
        meta: { title: '访客登记', roles: ['ADMIN', 'MANAGER'] }
      },
      {
        path: 'sanitary',
        component: () => import('../views/sanitary/index.vue'),
        meta: { title: '卫生检查', roles: ['ADMIN', 'MANAGER'] }
      },
      {
        path: 'violations',
        component: () => import('../views/violation/index.vue'),
        meta: { title: '违纪记录', roles: ['ADMIN', 'MANAGER'] }
      },
      {
        path: 'water',
        component: () => import('../views/water/index.vue'),
        meta: { title: '水电费', roles: ['ADMIN', 'MANAGER', 'STUDENT'] }
      },
      {
        path: 'adjust',
        component: () => import('../views/adjust/index.vue'),
        meta: { title: '调宿申请', roles: ['ADMIN', 'MANAGER', 'STUDENT'] }
      },
      {
        path: 'notices',
        component: () => import('../views/notice/index.vue'),
        meta: { title: '公告通知', roles: ['ADMIN', 'MANAGER', 'STUDENT'] }
      },
      {
        path: 'users',
        component: () => import('../views/user/index.vue'),
        meta: { title: '账号管理', roles: ['ADMIN'] }
      }
    ]
  },
  { path: '/:pathMatch(.*)*', redirect: '/' }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to) => {
  const store = useUserStore()
  if (to.meta.public) {
    return true
  }
  if (!store.token) {
    return { path: '/login', query: { redirect: to.fullPath } }
  }
  if (to.path === '/') {
    return { path: store.homePath }
  }
  const roles = to.meta.roles
  if (roles && roles.length && !roles.includes(store.role)) {
    ElMessage.warning('没有访问该页面的权限')
    return { path: store.homePath }
  }
  document.title = `${to.meta.title || '宿舍管理系统'} - 宿舍管理系统`
  return true
})

export default router
