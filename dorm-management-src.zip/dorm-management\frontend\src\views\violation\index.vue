<template>
  <div class="page-card">
    <h3 class="page-title">违纪记录</h3>
    <div class="toolbar">
      <el-input v-model="query.keyword" placeholder="学生姓名 / 违纪类型" clearable style="width: 220px" @keyup.enter="search" />
      <el-button type="primary" @click="search">查询</el-button>
      <el-button @click="reset">重置</el-button>
      <div class="spacer"></div>
      <el-button type="primary" @click="openDialog">
        <el-icon><Plus /></el-icon> 记录违纪
      </el-button>
    </div>

    <el-table :data="list" v-loading="loading" stripe border>
      <el-table-column prop="studentName" label="学生" width="100" />
      <el-table-column prop="studentNo" label="学号" width="110" />
      <el-table-column prop="className" label="班级" width="120" />
      <el-table-column label="宿舍" min-width="150">
        <template #default="{ row }">
          <span v-if="row.roomNo">{{ row.buildingName }} {{ row.roomNo }}</span>
          <span v-else class="text-muted">—</span>
        </template>
      </el-table-column>
      <el-table-column prop="type" label="违纪类型" width="120" />
      <el-table-column prop="description" label="情况说明" min-width="200" show-overflow-tooltip />
      <el-table-column label="扣分" width="80">
        <template #default="{ row }">
          <span style="color: #f56c6c; font-weight: 600">-{{ row.points }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="recordDate" label="记录日期" width="120" />
      <el-table-column prop="recorderName" label="记录人" width="110" />
      <el-table-column label="操作" width="90" fixed="right">
        <template #default="{ row }">
          <el-button link type="danger" @click="remove(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        v-model:current-page="query.page"
        v-model:page-size="query.size"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next"
        @current-change="load"
        @size-change="search"
      />
    </div>

    <el-dialog v-model="dialogVisible" title="记录违纪" width="520px">
      <el-form :model="form" label-width="90px">
        <el-form-item label="学生" required>
          <el-select v-model="form.studentId" placeholder="按姓名 / 学号搜索" filterable style="width: 100%">
            <el-option
              v-for="s in students"
              :key="s.id"
              :label="`${s.name}（${s.studentNo}）`"
              :value="s.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="违纪类型" required>
          <el-select v-model="form.type" style="width: 100%">
            <el-option v-for="t in types" :key="t" :label="t" :value="t" />
          </el-select>
        </el-form-item>
        <el-form-item label="情况说明">
          <el-input v-model="form.description" type="textarea" :rows="3" maxlength="500" />
        </el-form-item>
        <el-form-item label="扣分">
          <el-input-number v-model="form.points" :min="0" :max="100" />
        </el-form-item>
        <el-form-item label="记录日期">
          <el-date-picker v-model="form.recordDate" type="date" value-format="YYYY-MM-DD" style="width: 100%" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="save">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { studentApi, violationApi } from '../../api'

const types = ['违规电器', '晚归', '夜不归宿', '吸烟', '卫生', '其他']
const loading = ref(false)
const saving = ref(false)
const list = ref([])
const total = ref(0)
const students = ref([])
const dialogVisible = ref(false)

const query = reactive({ page: 1, size: 10, keyword: '' })
const form = reactive({ studentId: null, type: '违规电器', description: '', points: 5, recordDate: null })

async function load () {
  loading.value = true
  try {
    const res = await violationApi.page(query)
    list.value = res.data.records
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

function search () {
  query.page = 1
  load()
}

function reset () {
  query.keyword = ''
  search()
}

async function loadStudents () {
  const res = await studentApi.page({ page: 1, size: 1000, status: 1 })
  students.value = res.data.records
}

function openDialog () {
  Object.assign(form, { studentId: null, type: '违规电器', description: '', points: 5, recordDate: null })
  dialogVisible.value = true
}

async function save () {
  if (!form.studentId) {
    ElMessage.warning('请选择学生')
    return
  }
  saving.value = true
  try {
    await violationApi.create(form)
    ElMessage.success('保存成功')
    dialogVisible.value = false
    load()
  } finally {
    saving.value = false
  }
}

function remove (row) {
  ElMessageBox.confirm('确定删除这条违纪记录吗？', '提示', { type: 'warning' })
    .then(async () => {
      await violationApi.remove(row.id)
      ElMessage.success('删除成功')
      load()
    })
    .catch(() => {})
}

onMounted(() => {
  load()
  loadStudents()
})
</script>
