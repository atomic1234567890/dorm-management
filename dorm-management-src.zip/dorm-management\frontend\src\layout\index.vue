<template>
  <el-container class="layout">
    <el-aside width="216px" class="aside">
      <div class="brand">
        <el-icon :size="22"><HomeFilled /></el-icon>
        <span>宿舍管理系统</span>
      </div>
      <el-menu
        :default-active="activeMenu"
        router
        background-color="#1f2a44"
        text-color="#c3cbdc"
        active-text-color="#ffffff"
        class="menu"
      >
        <el-menu-item v-for="item in menus" :key="item.path" :index="item.path">
          <el-icon><component :is="item.icon" /></el-icon>
          <span>{{ item.title }}</span>
        </el-menu-item>
      </el-menu>
    </el-aside>

    <el-container>
      <el-header class="header">
        <div class="header-left">
          <span class="page-name">{{ currentTitle }}</span>
        </div>
        <div class="header-right">
          <el-tag size="small" effect="plain" type="info">{{ roleText }}</el-tag>
          <el-dropdown @command="handleCommand">
            <span class="user-box">
              <el-avatar :size="28" class="avatar">{{ avatarText }}</el-avatar>
              <span class="user-name">{{ store.realName }}</span>
              <el-icon><ArrowDown /></el-icon>
            </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="password">修改密码</el-dropdown-item>
                <el-dropdown-item command="logout" divided>退出登录</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </el-header>

      <el-main class="main">
        <router-view />
      </el-main>
    </el-container>

    <el-dialog v-model="pwdVisible" title="修改密码" width="420px">
      <el-form :model="pwdForm" label-width="90px">
        <el-form-item label="原密码">
          <el-input v-model="pwdForm.oldPassword" type="password" show-password />
        </el-form-item>
        <el-form-item label="新密码">
          <el-input v-model="pwdForm.newPassword" type="password" show-password placeholder="至少 6 位" />
        </el-form-item>
        <el-form-item label="确认新密码">
          <el-input v-model="pwdForm.confirm" type="password" show-password />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="pwdVisible = false">取消</el-button>
        <el-button type="primary" :loading="pwdLoading" @click="submitPassword">确定</el-button>
      </template>
    </el-dialog>
  </el-container>
</template>

<script setup>
import { computed, reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useUserStore } from '../stores/user'
import { authApi } from '../api'

const store = useUserStore()
const route = useRoute()
const router = useRouter()

const menus = computed(() => {
  const role = store.role
  const all = [
    { path: '/dashboard', title: '数据看板', icon: 'DataBoard', roles: ['ADMIN', 'MANAGER'] },
    { path: '/my-dorm', title: '我的宿舍', icon: 'House', roles: ['STUDENT'] },
    { path: '/buildings', title: '楼栋管理', icon: 'OfficeBuilding', roles: ['ADMIN'] },
    { path: '/dormitories', title: '宿舍管理', icon: 'School', roles: ['ADMIN', 'MANAGER'] },
    { path: '/students', title: '学生入住', icon: 'User', roles: ['ADMIN', 'MANAGER'] },
    { path: '/repairs', title: '报修管理', icon: 'Tools', roles: ['ADMIN', 'MANAGER', 'STUDENT'] },
    { path: '/visitors', title: '访客登记', icon: 'Postcard', roles: ['ADMIN', 'MANAGER'] },
    { path: '/sanitary', title: '卫生检查', icon: 'Brush', roles: ['ADMIN', 'MANAGER'] },
    { path: '/violations', title: '违纪记录', icon: 'Warning', roles: ['ADMIN', 'MANAGER'] },
    { path: '/water', title: '水电费', icon: 'Coin', roles: ['ADMIN', 'MANAGER', 'STUDENT'] },
    { path: '/adjust', title: '调宿申请', icon: 'Switch', roles: ['ADMIN', 'MANAGER', 'STUDENT'] },
    { path: '/notices', title: '公告通知', icon: 'Bell', roles: ['ADMIN', 'MANAGER', 'STUDENT'] },
    { path: '/users', title: '账号管理', icon: 'Setting', roles: ['ADMIN'] }
  ]
  return all.filter((m) => m.roles.includes(role))
})

const activeMenu = computed(() => route.path)
const currentTitle = computed(() => route.meta.title || '宿舍管理系统')
const roleText = computed(() => {
  const map = { ADMIN: '管理员', MANAGER: '宿管', STUDENT: '学生' }
  return map[store.role] || '未知角色'
})
const avatarText = computed(() => (store.realName || '用户').slice(0, 1))

const pwdVisible = ref(false)
const pwdLoading = ref(false)
const pwdForm = reactive({ oldPassword: '', newPassword: '', confirm: '' })

function handleCommand (command) {
  if (command === 'logout') {
    ElMessageBox.confirm('确定退出登录吗？', '提示', { type: 'warning' }).then(() => {
      store.logout()
      router.push('/login')
    }).catch(() => {})
  } else if (command === 'password') {
    pwdForm.oldPassword = ''
    pwdForm.newPassword = ''
    pwdForm.confirm = ''
    pwdVisible.value = true
  }
}

async function submitPassword () {
  if (!pwdForm.oldPassword || !pwdForm.newPassword) {
    ElMessage.warning('请填写原密码和新密码')
    return
  }
  if (pwdForm.newPassword.length < 6) {
    ElMessage.warning('新密码不能少于 6 位')
    return
  }
  if (pwdForm.newPassword !== pwdForm.confirm) {
    ElMessage.warning('两次输入的新密码不一致')
    return
  }
  pwdLoading.value = true
  try {
    await authApi.changePassword({ oldPassword: pwdForm.oldPassword, newPassword: pwdForm.newPassword })
    ElMessage.success('密码修改成功，请重新登录')
    pwdVisible.value = false
    store.logout()
    router.push('/login')
  } finally {
    pwdLoading.value = false
  }
}
</script>

<style scoped>
.layout {
  height: 100%;
}

.aside {
  background: #1f2a44;
  color: #fff;
  display: flex;
  flex-direction: column;
}

.brand {
  height: 60px;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 0 18px;
  font-size: 16px;
  font-weight: 600;
  letter-spacing: 1px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}

.menu {
  border-right: none;
  flex: 1;
  padding-top: 6px;
}

.menu :deep(.el-menu-item) {
  height: 46px;
  line-height: 46px;
  margin: 2px 8px;
  border-radius: 6px;
}

.menu :deep(.el-menu-item.is-active) {
  background: #2f6fed !important;
}

.header {
  height: 60px;
  background: #fff;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 22px;
  box-shadow: 0 1px 4px rgba(31, 42, 68, 0.08);
  z-index: 10;
}

.page-name {
  font-size: 16px;
  font-weight: 600;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 12px;
}

.user-box {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  outline: none;
}

.avatar {
  background: #2f6fed;
  color: #fff;
}

.user-name {
  font-size: 14px;
}

.main {
  background: #f4f6fa;
  padding: 18px;
  overflow-y: auto;
}
</style>
