<template>
  <div class="page-card">
    <h3 class="page-title">公告通知</h3>
    <div class="toolbar">
      <el-input v-model="query.keyword" placeholder="搜索公告标题" clearable style="width: 240px" @keyup.enter="search" />
      <el-button type="primary" @click="search">查询</el-button>
      <el-button @click="reset">重置</el-button>
      <div class="spacer"></div>
      <el-button type="primary" v-if="store.isAdmin" @click="openDialog()">
        <el-icon><Plus /></el-icon> 发布公告
      </el-button>
    </div>

    <el-table :data="list" v-loading="loading" stripe border>
      <el-table-column label="标题" min-width="300">
        <template #default="{ row }">
          <el-link type="primary" :underline="false" @click="showDetail(row)">{{ row.title }}</el-link>
        </template>
      </el-table-column>
      <el-table-column prop="publisherName" label="发布人" width="120" />
      <el-table-column label="发布时间" width="170">
        <template #default="{ row }">{{ formatTime(row.createTime) }}</template>
      </el-table-column>
      <el-table-column label="状态" width="100" v-if="!store.isStudent">
        <template #default="{ row }">
          <el-tag :type="row.status === 1 ? 'success' : 'info'">{{ row.status === 1 ? '已发布' : '草稿' }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="160" fixed="right" v-if="store.isAdmin">
        <template #default="{ row }">
          <el-button link type="primary" @click="openDialog(row)">编辑</el-button>
          <el-button link type="danger" @click="remove(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        v-model:current-page="query.page"
        v-model:page-size="query.size"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next"
        @current-change="load"
        @size-change="search"
      />
    </div>

    <el-dialog v-model="detailVisible" :title="detail.title" width="640px">
      <div class="notice-meta">
        {{ detail.publisherName }} · {{ formatTime(detail.createTime) }}
      </div>
      <div class="notice-content">{{ detail.content }}</div>
    </el-dialog>

    <el-dialog v-model="dialogVisible" :title="form.id ? '编辑公告' : '发布公告'" width="640px">
      <el-form :model="form" label-width="70px">
        <el-form-item label="标题" required>
          <el-input v-model="form.title" maxlength="100" show-word-limit />
        </el-form-item>
        <el-form-item label="内容" required>
          <el-input v-model="form.content" type="textarea" :rows="10" maxlength="5000" show-word-limit />
        </el-form-item>
        <el-form-item label="状态">
          <el-radio-group v-model="form.status">
            <el-radio :label="1">立即发布</el-radio>
            <el-radio :label="0">存为草稿</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="save">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { noticeApi } from '../../api'
import { useUserStore } from '../../stores/user'

const store = useUserStore()
const loading = ref(false)
const saving = ref(false)
const list = ref([])
const total = ref(0)
const dialogVisible = ref(false)
const detailVisible = ref(false)
const detail = ref({})

const query = reactive({ page: 1, size: 10, keyword: '' })
const form = reactive({ id: null, title: '', content: '', status: 1 })

function formatTime (t) {
  return t ? String(t).replace('T', ' ').slice(0, 16) : ''
}

async function load () {
  loading.value = true
  try {
    const res = await noticeApi.page(query)
    list.value = res.data.records
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

function search () {
  query.page = 1
  load()
}

function reset () {
  query.keyword = ''
  search()
}

async function showDetail (row) {
  const res = await noticeApi.detail(row.id)
  detail.value = res.data
  detailVisible.value = true
}

function openDialog (row) {
  Object.assign(form, { id: null, title: '', content: '', status: 1 })
  if (row) {
    Object.assign(form, row)
  }
  dialogVisible.value = true
}

async function save () {
  if (!form.title || !form.content) {
    ElMessage.warning('请填写标题和内容')
    return
  }
  saving.value = true
  try {
    if (form.id) {
      await noticeApi.update(form.id, form)
      ElMessage.success('保存成功')
    } else {
      await noticeApi.create(form)
      ElMessage.success('发布成功')
    }
    dialogVisible.value = false
    load()
  } finally {
    saving.value = false
  }
}

function remove (row) {
  ElMessageBox.confirm(`确定删除公告「${row.title}」吗？`, '提示', { type: 'warning' })
    .then(async () => {
      await noticeApi.remove(row.id)
      ElMessage.success('删除成功')
      load()
    })
    .catch(() => {})
}

onMounted(load)
</script>

<style scoped>
.notice-meta {
  color: #8a94a6;
  font-size: 13px;
  margin-bottom: 14px;
  padding-bottom: 10px;
  border-bottom: 1px solid #eef1f6;
}

.notice-content {
  white-space: pre-wrap;
  line-height: 1.9;
  font-size: 14px;
  color: #333;
}
</style>
