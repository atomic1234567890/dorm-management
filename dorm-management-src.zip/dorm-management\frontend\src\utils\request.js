import axios from 'axios'
import { ElMessage } from 'element-plus'

const service = axios.create({
  baseURL: '/api',
  timeout: 20000
})

service.interceptors.request.use((config) => {
  const token = localStorage.getItem('dorm_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

function toLogin () {
  localStorage.removeItem('dorm_token')
  localStorage.removeItem('dorm_user')
  if (!window.location.pathname.startsWith('/login')) {
    window.location.href = '/login'
  }
}

service.interceptors.response.use(
  (response) => {
    const res = response.data
    if (res && res.code === 200) {
      return res
    }
    if (res && res.code === 401) {
      ElMessage.error(res.msg || '登录已过期，请重新登录')
      toLogin()
      return Promise.reject(new Error(res.msg || '未登录'))
    }
    ElMessage.error((res && res.msg) || '操作失败')
    return Promise.reject(new Error((res && res.msg) || '操作失败'))
  },
  (error) => {
    if (error.response && error.response.status === 401) {
      toLogin()
    }
    const msg = error.response && error.response.data && error.response.data.msg
      ? error.response.data.msg
      : (error.message || '网络异常，请稍后再试')
    ElMessage.error(msg)
    return Promise.reject(error)
  }
)

/**
 * 文件下载（Excel 导出）
 */
export async function downloadFile (url, params) {
  const token = localStorage.getItem('dorm_token')
  const response = await axios.get(`/api${url}`, {
    params,
    responseType: 'blob',
    headers: { Authorization: `Bearer ${token}` }
  })
  let filename = '导出数据.xlsx'
  const disposition = response.headers['content-disposition'] || ''
  const match = /filename\*=UTF-8''([^;]+)/i.exec(disposition)
  if (match) {
    filename = decodeURIComponent(match[1])
  }
  const blob = new Blob([response.data], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = filename
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(link.href)
}

export default service
