<template>
  <div class="page-card">
    <h3 class="page-title">报修管理</h3>
    <div class="toolbar">
      <el-select v-model="query.status" placeholder="全部状态" clearable style="width: 140px" @change="search">
        <el-option label="待派单" :value="0" />
        <el-option label="维修中" :value="1" />
        <el-option label="已完成" :value="2" />
        <el-option label="已取消" :value="3" />
      </el-select>
      <el-input v-model="query.keyword" placeholder="搜索学生 / 宿舍号 / 描述" clearable style="width: 230px" @keyup.enter="search" />
      <el-button type="primary" @click="search">查询</el-button>
      <el-button @click="reset">重置</el-button>
      <div class="spacer"></div>
      <el-button @click="exportExcel">
        <el-icon><Download /></el-icon> 导出 Excel
      </el-button>
      <el-button type="primary" v-if="store.isStudent" @click="openCreate">
        <el-icon><Plus /></el-icon> 提交报修
      </el-button>
    </div>

    <el-table :data="list" v-loading="loading" stripe border>
      <el-table-column prop="id" label="编号" width="70" />
      <el-table-column label="报修人" width="150">
        <template #default="{ row }">
          {{ row.studentName }}
          <div class="text-muted">{{ row.buildingName }} {{ row.roomNo }}</div>
        </template>
      </el-table-column>
      <el-table-column prop="type" label="类型" width="90" />
      <el-table-column prop="description" label="问题描述" min-width="220" show-overflow-tooltip />
      <el-table-column label="状态" width="100">
        <template #default="{ row }">
          <el-tag :type="statusType(row.status)">{{ statusText(row.status) }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="handlerName" label="维修人" width="100">
        <template #default="{ row }">{{ row.handlerName || '—' }}</template>
      </el-table-column>
      <el-table-column label="报修时间" width="160">
        <template #default="{ row }">{{ formatTime(row.createTime) }}</template>
      </el-table-column>
      <el-table-column label="操作" width="200" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" @click="showDetail(row)">详情</el-button>
          <el-button link type="primary" v-if="!store.isStudent && row.status === 0" @click="openDispatch(row)">派单</el-button>
          <el-button link type="success" v-if="!store.isStudent && row.status === 1" @click="openFinish(row)">完成</el-button>
          <el-button link type="danger" v-if="row.status !== 2" @click="cancel(row)">取消</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        v-model:current-page="query.page"
        v-model:page-size="query.size"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next"
        @current-change="load"
        @size-change="search"
      />
    </div>

    <!-- 学生提交报修 -->
    <el-dialog v-model="createVisible" title="提交报修" width="520px">
      <el-form :model="createForm" label-width="90px">
        <el-form-item label="报修类型" required>
          <el-select v-model="createForm.type" style="width: 100%">
            <el-option v-for="t in types" :key="t" :label="t" :value="t" />
          </el-select>
        </el-form-item>
        <el-form-item label="问题描述" required>
          <el-input v-model="createForm.description" type="textarea" :rows="4" maxlength="500" show-word-limit
                    placeholder="请描述具体问题、位置，便于维修师傅上门处理" />
        </el-form-item>
        <el-form-item label="图片链接">
          <el-input v-model="createForm.images" placeholder="可选，多个链接用英文逗号分隔" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="createVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="submitCreate">提交</el-button>
      </template>
    </el-dialog>

    <!-- 派单 -->
    <el-dialog v-model="dispatchVisible" title="派单" width="420px">
      <el-form label-width="80px">
        <el-form-item label="维修人" required>
          <el-select v-model="dispatchHandler" placeholder="请选择维修人" style="width: 100%">
            <el-option v-for="m in managers" :key="m.id" :label="`${m.realName}（${m.username}）`" :value="m.id" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dispatchVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="submitDispatch">确定</el-button>
      </template>
    </el-dialog>

    <!-- 完成 -->
    <el-dialog v-model="finishVisible" title="填写处理结果" width="480px">
      <el-input v-model="finishResult" type="textarea" :rows="4" maxlength="500" show-word-limit
                placeholder="请填写维修处理结果" />
      <template #footer>
        <el-button @click="finishVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="submitFinish">完成</el-button>
      </template>
    </el-dialog>

    <!-- 详情 -->
    <el-drawer v-model="detailVisible" title="报修详情" size="480px">
      <el-descriptions :column="1" border v-if="detail">
        <el-descriptions-item label="报修编号">{{ detail.id }}</el-descriptions-item>
        <el-descriptions-item label="报修人">{{ detail.studentName }}（{{ detail.studentNo }}）</el-descriptions-item>
        <el-descriptions-item label="联系电话">{{ detail.phone || '—' }}</el-descriptions-item>
        <el-descriptions-item label="报修宿舍">{{ detail.buildingName }} {{ detail.roomNo }}</el-descriptions-item>
        <el-descriptions-item label="报修类型">{{ detail.type }}</el-descriptions-item>
        <el-descriptions-item label="问题描述">{{ detail.description }}</el-descriptions-item>
        <el-descriptions-item label="当前状态">
          <el-tag :type="statusType(detail.status)">{{ statusText(detail.status) }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="维修人">{{ detail.handlerName || '—' }}</el-descriptions-item>
        <el-descriptions-item label="报修时间">{{ formatTime(detail.createTime) }}</el-descriptions-item>
        <el-descriptions-item label="派单时间">{{ formatTime(detail.dispatchTime) }}</el-descriptions-item>
        <el-descriptions-item label="完成时间">{{ formatTime(detail.finishTime) }}</el-descriptions-item>
        <el-descriptions-item label="处理结果">{{ detail.result || '—' }}</el-descriptions-item>
      </el-descriptions>
      <div v-if="detail && detail.images" style="margin-top: 16px">
        <div class="text-muted" style="margin-bottom: 6px">现场图片</div>
        <div class="img-list">
          <el-image v-for="(img, i) in detail.images.split(',')" :key="i" :src="img" fit="cover"
                    style="width: 100px; height: 100px; border-radius: 6px" :preview-src-list="detail.images.split(',')" />
        </div>
      </div>
    </el-drawer>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { repairApi, userApi } from '../../api'
import { downloadFile } from '../../utils/request'
import { useUserStore } from '../../stores/user'

const store = useUserStore()
const types = ['水电', '门窗', '家具', '网络', '其他']
const loading = ref(false)
const saving = ref(false)
const list = ref([])
const total = ref(0)
const managers = ref([])
const detail = ref(null)
const detailVisible = ref(false)
const createVisible = ref(false)
const dispatchVisible = ref(false)
const finishVisible = ref(false)
const dispatchHandler = ref(null)
const finishResult = ref('')
const currentRow = ref(null)

const query = reactive({ page: 1, size: 10, status: null, keyword: '' })
const createForm = reactive({ type: '水电', description: '', images: '' })

function statusText (s) {
  return { 0: '待派单', 1: '维修中', 2: '已完成', 3: '已取消' }[s] || '未知'
}

function statusType (s) {
  return { 0: 'warning', 1: 'primary', 2: 'success', 3: 'info' }[s] || 'info'
}

function formatTime (t) {
  return t ? String(t).replace('T', ' ').slice(0, 16) : '—'
}

async function load () {
  loading.value = true
  try {
    const res = await repairApi.page(query)
    list.value = res.data.records
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

function search () {
  query.page = 1
  load()
}

function reset () {
  query.status = null
  query.keyword = ''
  search()
}

function openCreate () {
  createForm.type = '水电'
  createForm.description = ''
  createForm.images = ''
  createVisible.value = true
}

async function submitCreate () {
  if (!createForm.description) {
    ElMessage.warning('请填写问题描述')
    return
  }
  saving.value = true
  try {
    await repairApi.create(createForm)
    ElMessage.success('提交成功')
    createVisible.value = false
    load()
  } finally {
    saving.value = false
  }
}

async function openDispatch (row) {
  currentRow.value = row
  dispatchHandler.value = null
  if (managers.value.length === 0) {
    const res = await userApi.managers()
    managers.value = res.data
  }
  dispatchVisible.value = true
}

async function submitDispatch () {
  if (!dispatchHandler.value) {
    ElMessage.warning('请选择维修人')
    return
  }
  saving.value = true
  try {
    await repairApi.dispatch(currentRow.value.id, { handlerId: dispatchHandler.value })
    ElMessage.success('派单成功')
    dispatchVisible.value = false
    load()
  } finally {
    saving.value = false
  }
}

function openFinish (row) {
  currentRow.value = row
  finishResult.value = ''
  finishVisible.value = true
}

async function submitFinish () {
  if (!finishResult.value) {
    ElMessage.warning('请填写处理结果')
    return
  }
  saving.value = true
  try {
    await repairApi.finish(currentRow.value.id, { result: finishResult.value })
    ElMessage.success('已完成')
    finishVisible.value = false
    load()
  } finally {
    saving.value = false
  }
}

async function showDetail (row) {
  const res = await repairApi.detail(row.id)
  detail.value = res.data
  detailVisible.value = true
}

function cancel (row) {
  ElMessageBox.confirm('确定取消该报修吗？', '提示', { type: 'warning' })
    .then(async () => {
      await repairApi.cancel(row.id)
      ElMessage.success('已取消')
      load()
    })
    .catch(() => {})
}

function exportExcel () {
  downloadFile('/export/repairs', { status: query.status, keyword: query.keyword })
}

onMounted(load)
</script>

<style scoped>
.img-list {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}
</style>
