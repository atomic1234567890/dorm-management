import { defineStore } from 'pinia'
import { authApi } from '../api'

export const useUserStore = defineStore('user', {
  state: () => ({
    token: localStorage.getItem('dorm_token') || '',
    userInfo: JSON.parse(localStorage.getItem('dorm_user') || 'null')
  }),
  getters: {
    role: (state) => (state.userInfo ? state.userInfo.role : ''),
    realName: (state) => (state.userInfo ? state.userInfo.realName : ''),
    isAdmin: (state) => state.userInfo && state.userInfo.role === 'ADMIN',
    isManager: (state) => state.userInfo && state.userInfo.role === 'MANAGER',
    isStudent: (state) => state.userInfo && state.userInfo.role === 'STUDENT',
    homePath: (state) => (state.userInfo && state.userInfo.role === 'STUDENT' ? '/my-dorm' : '/dashboard')
  },
  actions: {
    async login (form) {
      const res = await authApi.login(form)
      const data = res.data
      this.token = data.token
      this.userInfo = data
      localStorage.setItem('dorm_token', data.token)
      localStorage.setItem('dorm_user', JSON.stringify(data))
      return data
    },
    async refreshMe () {
      const res = await authApi.me()
      this.userInfo = { ...(this.userInfo || {}), ...res.data }
      localStorage.setItem('dorm_user', JSON.stringify(this.userInfo))
      return this.userInfo
    },
    logout () {
      this.token = ''
      this.userInfo = null
      localStorage.removeItem('dorm_token')
      localStorage.removeItem('dorm_user')
    }
  }
})
