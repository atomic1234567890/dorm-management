<template>
  <div class="page-card">
    <h3 class="page-title">访客登记</h3>
    <div class="toolbar">
      <el-select v-model="query.status" placeholder="全部状态" clearable style="width: 140px" @change="search">
        <el-option label="在访" :value="0" />
        <el-option label="已离开" :value="1" />
      </el-select>
      <el-input v-model="query.keyword" placeholder="访客姓名 / 宿舍号" clearable style="width: 200px" @keyup.enter="search" />
      <el-button type="primary" @click="search">查询</el-button>
      <el-button @click="reset">重置</el-button>
      <div class="spacer"></div>
      <el-button type="primary" @click="openDialog">
        <el-icon><Plus /></el-icon> 访客登记
      </el-button>
    </div>

    <el-table :data="list" v-loading="loading" stripe border>
      <el-table-column prop="name" label="访客姓名" width="110" />
      <el-table-column label="身份证号" width="180">
        <template #default="{ row }">{{ maskId(row.idCard) }}</template>
      </el-table-column>
      <el-table-column prop="phone" label="联系电话" width="130" />
      <el-table-column label="来访宿舍" min-width="160">
        <template #default="{ row }">{{ row.buildingName }} {{ row.roomNo }}</template>
      </el-table-column>
      <el-table-column prop="studentName" label="被访学生" width="100">
        <template #default="{ row }">{{ row.studentName || '—' }}</template>
      </el-table-column>
      <el-table-column label="来访时间" width="160">
        <template #default="{ row }">{{ formatTime(row.visitTime) }}</template>
      </el-table-column>
      <el-table-column label="离开时间" width="160">
        <template #default="{ row }">{{ formatTime(row.leaveTime) }}</template>
      </el-table-column>
      <el-table-column label="状态" width="90">
        <template #default="{ row }">
          <el-tag :type="row.status === 0 ? 'warning' : 'info'">{{ row.status === 0 ? '在访' : '已离开' }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="110" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" v-if="row.status === 0" @click="leave(row)">离开核销</el-button>
          <span v-else class="text-muted">已完成</span>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        v-model:current-page="query.page"
        v-model:page-size="query.size"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next"
        @current-change="load"
        @size-change="search"
      />
    </div>

    <el-dialog v-model="dialogVisible" title="访客登记" width="520px">
      <el-form :model="form" label-width="90px">
        <el-form-item label="访客姓名" required>
          <el-input v-model="form.name" maxlength="50" />
        </el-form-item>
        <el-form-item label="身份证号">
          <el-input v-model="form.idCard" maxlength="20" />
        </el-form-item>
        <el-form-item label="联系电话">
          <el-input v-model="form.phone" maxlength="20" />
        </el-form-item>
        <el-form-item label="来访宿舍" required>
          <el-select v-model="form.dormitoryId" placeholder="请选择宿舍" filterable style="width: 100%">
            <el-option
              v-for="d in dorms"
              :key="d.id"
              :label="`${d.buildingName} ${d.roomNo}`"
              :value="d.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="来访时间">
          <el-date-picker v-model="form.visitTime" type="datetime" placeholder="默认当前时间"
                          value-format="YYYY-MM-DDTHH:mm:ss" style="width: 100%" />
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="form.remark" type="textarea" :rows="2" maxlength="255" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="save">登记</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { dormitoryApi, visitorApi } from '../../api'

const loading = ref(false)
const saving = ref(false)
const list = ref([])
const total = ref(0)
const dorms = ref([])
const dialogVisible = ref(false)

const query = reactive({ page: 1, size: 10, status: null, keyword: '' })
const form = reactive({ name: '', idCard: '', phone: '', dormitoryId: null, visitTime: null, remark: '' })

function formatTime (t) {
  return t ? String(t).replace('T', ' ').slice(0, 16) : '—'
}

function maskId (id) {
  if (!id) return '—'
  return id.length > 10 ? `${id.slice(0, 6)}********${id.slice(-4)}` : id
}

async function load () {
  loading.value = true
  try {
    const res = await visitorApi.page(query)
    list.value = res.data.records
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

function search () {
  query.page = 1
  load()
}

function reset () {
  query.status = null
  query.keyword = ''
  search()
}

async function loadDorms () {
  const res = await dormitoryApi.page({ page: 1, size: 500 })
  dorms.value = res.data.records
}

function openDialog () {
  Object.assign(form, { name: '', idCard: '', phone: '', dormitoryId: null, visitTime: null, remark: '' })
  dialogVisible.value = true
}

async function save () {
  if (!form.name || !form.dormitoryId) {
    ElMessage.warning('请填写访客姓名并选择来访宿舍')
    return
  }
  saving.value = true
  try {
    await visitorApi.create(form)
    ElMessage.success('登记成功')
    dialogVisible.value = false
    load()
  } finally {
    saving.value = false
  }
}

async function leave (row) {
  await visitorApi.leave(row.id)
  ElMessage.success('已核销离开')
  load()
}

onMounted(() => {
  load()
  loadDorms()
})
</script>
