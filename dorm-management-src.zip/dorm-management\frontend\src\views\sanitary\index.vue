<template>
  <div class="page-card">
    <h3 class="page-title">卫生检查</h3>
    <div class="toolbar">
      <el-select v-model="query.dormitoryId" placeholder="全部宿舍" clearable filterable style="width: 240px" @change="search">
        <el-option v-for="d in dorms" :key="d.id" :label="`${d.buildingName} ${d.roomNo}`" :value="d.id" />
      </el-select>
      <el-button type="primary" @click="search">查询</el-button>
      <el-button @click="reset">重置</el-button>
      <div class="spacer"></div>
      <el-button type="primary" @click="openDialog">
        <el-icon><Plus /></el-icon> 录入检查结果
      </el-button>
    </div>

    <el-table :data="list" v-loading="loading" stripe border>
      <el-table-column label="宿舍" min-width="170">
        <template #default="{ row }">{{ row.buildingName }} {{ row.roomNo }}</template>
      </el-table-column>
      <el-table-column label="卫生得分" width="150">
        <template #default="{ row }">
          <span :style="{ color: scoreColor(row.score), fontWeight: 600 }">{{ row.score }}</span>
          <el-progress :percentage="row.score" :stroke-width="6" :show-text="false"
                       :color="scoreColor(row.score)" style="margin-top: 4px" />
        </template>
      </el-table-column>
      <el-table-column prop="checkDate" label="检查日期" width="120" />
      <el-table-column prop="remark" label="评语" min-width="200" show-overflow-tooltip />
      <el-table-column prop="checkerName" label="检查人" width="110" />
      <el-table-column label="操作" width="90" fixed="right">
        <template #default="{ row }">
          <el-button link type="danger" @click="remove(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        v-model:current-page="query.page"
        v-model:page-size="query.size"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next"
        @current-change="load"
        @size-change="search"
      />
    </div>

    <el-dialog v-model="dialogVisible" title="录入卫生检查" width="480px">
      <el-form :model="form" label-width="90px">
        <el-form-item label="宿舍" required>
          <el-select v-model="form.dormitoryId" placeholder="请选择宿舍" filterable style="width: 100%">
            <el-option v-for="d in dorms" :key="d.id" :label="`${d.buildingName} ${d.roomNo}`" :value="d.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="卫生得分" required>
          <el-input-number v-model="form.score" :min="0" :max="100" />
          <span class="text-muted" style="margin-left: 8px">0 - 100 分</span>
        </el-form-item>
        <el-form-item label="检查日期">
          <el-date-picker v-model="form.checkDate" type="date" value-format="YYYY-MM-DD" style="width: 100%" />
        </el-form-item>
        <el-form-item label="评语">
          <el-input v-model="form.remark" type="textarea" :rows="3" maxlength="255" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="save">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { dormitoryApi, sanitaryApi } from '../../api'

const loading = ref(false)
const saving = ref(false)
const list = ref([])
const total = ref(0)
const dorms = ref([])
const dialogVisible = ref(false)

const query = reactive({ page: 1, size: 10, dormitoryId: null })
const form = reactive({ dormitoryId: null, score: 90, checkDate: null, remark: '' })

function scoreColor (score) {
  if (score >= 90) return '#67c23a'
  if (score >= 75) return '#e6a23c'
  return '#f56c6c'
}

async function load () {
  loading.value = true
  try {
    const res = await sanitaryApi.page(query)
    list.value = res.data.records
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

function search () {
  query.page = 1
  load()
}

function reset () {
  query.dormitoryId = null
  search()
}

async function loadDorms () {
  const res = await dormitoryApi.page({ page: 1, size: 500 })
  dorms.value = res.data.records
}

function openDialog () {
  Object.assign(form, { dormitoryId: null, score: 90, checkDate: null, remark: '' })
  dialogVisible.value = true
}

async function save () {
  if (!form.dormitoryId) {
    ElMessage.warning('请选择宿舍')
    return
  }
  saving.value = true
  try {
    await sanitaryApi.create(form)
    ElMessage.success('保存成功')
    dialogVisible.value = false
    load()
  } finally {
    saving.value = false
  }
}

function remove (row) {
  ElMessageBox.confirm('确定删除这条卫生记录吗？', '提示', { type: 'warning' })
    .then(async () => {
      await sanitaryApi.remove(row.id)
      ElMessage.success('删除成功')
      load()
    })
    .catch(() => {})
}

onMounted(() => {
  load()
  loadDorms()
})
</script>
