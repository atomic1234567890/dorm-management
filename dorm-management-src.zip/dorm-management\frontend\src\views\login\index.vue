<template>
  <div class="login-page">
    <div class="login-left">
      <div class="brand">
        <el-icon :size="30"><HomeFilled /></el-icon>
        <span>智慧宿舍管理系统</span>
      </div>
      <h1>让宿舍管理<br />更简单、更高效</h1>
      <p class="desc">
        楼栋宿舍、学生入住、报修派单、访客登记、卫生违纪、水电费与公告，
        一套系统覆盖宿管日常工作。
      </p>
      <ul class="feature-list">
        <li><el-icon><Check /></el-icon> 三种角色权限隔离，数据各看各的</li>
        <li><el-icon><Check /></el-icon> 入住 / 调宿 / 退宿全流程闭环</li>
        <li><el-icon><Check /></el-icon> 报修进度可追踪，支持 Excel 导出</li>
      </ul>
      <div class="copyright">© 2026 软件工程课程设计 · 宿舍管理系统</div>
    </div>

    <div class="login-right">
      <div class="login-card">
        <h2>账号登录</h2>
        <p class="sub">请使用学校分配的账号登录</p>
        <el-form :model="form" @keyup.enter="submit">
          <el-form-item>
            <el-input v-model="form.username" size="large" placeholder="账号 / 学号" clearable>
              <template #prefix><el-icon><User /></el-icon></template>
            </el-input>
          </el-form-item>
          <el-form-item>
            <el-input v-model="form.password" size="large" type="password" placeholder="密码" show-password>
              <template #prefix><el-icon><Lock /></el-icon></template>
            </el-input>
          </el-form-item>
          <el-button type="primary" size="large" class="login-btn" :loading="loading" @click="submit">
            登 录
          </el-button>
        </el-form>

        <div class="demo">
          <div class="demo-title">演示账号（密码均为 123456）</div>
          <div class="demo-list">
            <span class="chip" @click="fill('admin')">管理员 admin</span>
            <span class="chip" @click="fill('manager01')">宿管 manager01</span>
            <span class="chip" @click="fill('20230001')">学生 20230001</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { useUserStore } from '../../stores/user'

const store = useUserStore()
const router = useRouter()
const route = useRoute()

const form = reactive({ username: '', password: '' })
const loading = ref(false)

function fill (username) {
  form.username = username
  form.password = '123456'
}

async function submit () {
  if (!form.username || !form.password) {
    ElMessage.warning('请输入账号和密码')
    return
  }
  loading.value = true
  try {
    const data = await store.login({ username: form.username, password: form.password })
    ElMessage.success(`欢迎回来，${data.realName}`)
    const redirect = route.query.redirect
    router.push(redirect || (data.role === 'STUDENT' ? '/my-dorm' : '/dashboard'))
  } catch (e) {
    // 错误提示已由 axios 拦截器统一处理
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.login-page {
  height: 100%;
  display: flex;
  background: #fff;
}

.login-left {
  flex: 1.15;
  background: linear-gradient(140deg, #1f2a44 0%, #2f4f9e 55%, #2f6fed 100%);
  color: #fff;
  padding: 54px 64px;
  display: flex;
  flex-direction: column;
  position: relative;
  overflow: hidden;
}

.login-left::after {
  content: '';
  position: absolute;
  width: 460px;
  height: 460px;
  right: -160px;
  bottom: -180px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.07);
}

.brand {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 20px;
  font-weight: 600;
  letter-spacing: 1px;
}

.login-left h1 {
  font-size: 38px;
  line-height: 1.35;
  margin: 64px 0 18px;
  font-weight: 700;
}

.desc {
  font-size: 15px;
  line-height: 1.8;
  color: rgba(255, 255, 255, 0.82);
  max-width: 460px;
}

.feature-list {
  list-style: none;
  padding: 0;
  margin: 34px 0 0;
}

.feature-list li {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 14px;
  font-size: 14px;
  color: rgba(255, 255, 255, 0.9);
}

.copyright {
  margin-top: auto;
  font-size: 12px;
  color: rgba(255, 255, 255, 0.55);
}

.login-right {
  flex: 0.85;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px;
}

.login-card {
  width: 100%;
  max-width: 360px;
}

.login-card h2 {
  margin: 0 0 6px;
  font-size: 26px;
}

.sub {
  color: #8a94a6;
  font-size: 13px;
  margin: 0 0 28px;
}

.login-btn {
  width: 100%;
  letter-spacing: 4px;
  height: 42px;
  font-size: 15px;
}

.demo {
  margin-top: 28px;
  border-top: 1px dashed #e4e8f0;
  padding-top: 18px;
}

.demo-title {
  font-size: 12px;
  color: #8a94a6;
  margin-bottom: 10px;
}

.demo-list {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.chip {
  font-size: 12px;
  padding: 4px 10px;
  border-radius: 20px;
  background: #f0f4ff;
  color: #2f6fed;
  cursor: pointer;
  border: 1px solid #dbe5ff;
  transition: all 0.2s;
}

.chip:hover {
  background: #2f6fed;
  color: #fff;
}

@media (max-width: 900px) {
  .login-left {
    display: none;
  }
}
</style>
