<template>
  <div>
    <div class="stat-grid">
      <div class="stat-card">
        <div class="label">床位总数</div>
        <div class="value">{{ stats.bedCount || 0 }}</div>
        <el-icon class="icon"><OfficeBuilding /></el-icon>
      </div>
      <div class="stat-card">
        <div class="label">已住人数</div>
        <div class="value">{{ stats.occupiedCount || 0 }}</div>
        <el-icon class="icon"><UserFilled /></el-icon>
      </div>
      <div class="stat-card">
        <div class="label">入住率</div>
        <div class="value">{{ stats.occupancyRate || 0 }}%</div>
        <el-icon class="icon"><PieChart /></el-icon>
      </div>
      <div class="stat-card">
        <div class="label">待处理报修</div>
        <div class="value" style="color: #e6a23c">{{ stats.pendingRepair || 0 }}</div>
        <el-icon class="icon"><Tools /></el-icon>
      </div>
      <div class="stat-card">
        <div class="label">当前在访</div>
        <div class="value" style="color: #67c23a">{{ stats.visiting || 0 }}</div>
        <el-icon class="icon"><Postcard /></el-icon>
      </div>
      <div class="stat-card">
        <div class="label">未缴水电费</div>
        <div class="value" style="color: #f56c6c">{{ stats.unpaidCount || 0 }}</div>
        <el-icon class="icon"><Coin /></el-icon>
      </div>
    </div>

    <div class="chart-grid">
      <div class="chart-box">
        <h4>各楼栋入住情况</h4>
        <div ref="buildingChartRef" class="chart"></div>
      </div>
      <div class="chart-box">
        <h4>近 7 天报修数量</h4>
        <div ref="trendChartRef" class="chart"></div>
      </div>
    </div>

    <div class="chart-grid" style="grid-template-columns: 1fr 1.2fr">
      <div class="chart-box">
        <h4>报修类型分布</h4>
        <div ref="typeChartRef" class="chart"></div>
      </div>
      <div class="chart-box">
        <h4>最新公告</h4>
        <div class="notice-list">
          <div v-for="n in stats.notices || []" :key="n.id" class="notice-item">
            <div class="notice-title">
              <el-icon color="#2f6fed"><Bell /></el-icon>
              <span>{{ n.title }}</span>
            </div>
            <span class="text-muted">{{ (n.createTime || '').replace('T', ' ').slice(0, 16) }}</span>
          </div>
          <el-empty v-if="!stats.notices || stats.notices.length === 0" description="暂无公告" :image-size="60" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { nextTick, onBeforeUnmount, onMounted, ref } from 'vue'
import * as echarts from 'echarts'
import { dashboardApi } from '../../api'

const stats = ref({})
const buildingChartRef = ref(null)
const trendChartRef = ref(null)
const typeChartRef = ref(null)
let charts = []

function initChart (el, option) {
  if (!el) return
  const chart = echarts.init(el)
  chart.setOption(option)
  charts.push(chart)
}

async function load () {
  const res = await dashboardApi.stats()
  stats.value = res.data
  await nextTick()
  renderCharts()
}

function renderCharts () {
  const buildings = stats.value.buildingStats || []
  const names = buildings.map((b) => b.name.replace(/（.*?）/g, ''))
  const occupied = buildings.map((b) => Number(b.occupied) || 0)
  const free = buildings.map((b) => (Number(b.capacity) || 0) - (Number(b.occupied) || 0))

  initChart(buildingChartRef.value, {
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    legend: { data: ['已住', '空余'], right: 10, top: 0 },
    grid: { left: 10, right: 16, top: 40, bottom: 6, containLabel: true },
    xAxis: { type: 'category', data: names },
    yAxis: { type: 'value', name: '床位' },
    series: [
      { name: '已住', type: 'bar', stack: 'total', barWidth: 28, itemStyle: { color: '#2f6fed' }, data: occupied },
      { name: '空余', type: 'bar', stack: 'total', barWidth: 28, itemStyle: { color: '#dfe6f5' }, data: free }
    ]
  })

  const trend = stats.value.repairTrend || []
  initChart(trendChartRef.value, {
    tooltip: { trigger: 'axis' },
    grid: { left: 10, right: 16, top: 24, bottom: 6, containLabel: true },
    xAxis: { type: 'category', boundaryGap: false, data: trend.map((t) => t.day) },
    yAxis: { type: 'value', minInterval: 1 },
    series: [{
      type: 'line',
      smooth: true,
      symbolSize: 6,
      data: trend.map((t) => t.total),
      itemStyle: { color: '#2f6fed' },
      areaStyle: { color: 'rgba(47,111,237,0.12)' }
    }]
  })

  const types = stats.value.repairTypeStats || []
  initChart(typeChartRef.value, {
    tooltip: { trigger: 'item' },
    legend: { bottom: 0 },
    series: [{
      type: 'pie',
      radius: ['42%', '66%'],
      center: ['50%', '44%'],
      data: types.map((t) => ({ name: t.type, value: t.total })),
      label: { formatter: '{b} {c}' }
    }]
  })
}

function resize () {
  charts.forEach((c) => c.resize())
}

onMounted(() => {
  load()
  window.addEventListener('resize', resize)
})

onBeforeUnmount(() => {
  window.removeEventListener('resize', resize)
  charts.forEach((c) => c.dispose())
  charts = []
})
</script>

<style scoped>
.chart {
  height: 260px;
}

.notice-list {
  height: 260px;
  overflow-y: auto;
  padding-right: 4px;
}

.notice-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
  padding: 10px 4px;
  border-bottom: 1px dashed #eef1f6;
  font-size: 13px;
}

.notice-title {
  display: flex;
  align-items: center;
  gap: 6px;
  overflow: hidden;
}

.notice-title span {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
