<template>
  <div class="page-card">
    <h3 class="page-title">学生入住管理</h3>
    <div class="toolbar">
      <el-select v-model="query.buildingId" placeholder="全部楼栋" clearable style="width: 170px" @change="search">
        <el-option v-for="b in buildings" :key="b.id" :label="b.name" :value="b.id" />
      </el-select>
      <el-select v-model="query.status" placeholder="全部状态" clearable style="width: 140px" @change="search">
        <el-option label="在住" :value="1" />
        <el-option label="退宿" :value="0" />
        <el-option label="待分配" :value="2" />
      </el-select>
      <el-input v-model="query.keyword" placeholder="姓名 / 学号 / 班级" clearable style="width: 200px" @keyup.enter="search" />
      <el-button type="primary" @click="search">查询</el-button>
      <el-button @click="reset">重置</el-button>
      <div class="spacer"></div>
      <el-button @click="exportExcel">
        <el-icon><Download /></el-icon> 导出 Excel
      </el-button>
      <el-button type="primary" @click="openDialog()">
        <el-icon><Plus /></el-icon> 新增学生
      </el-button>
    </div>

    <el-table :data="list" v-loading="loading" stripe border>
      <el-table-column prop="studentNo" label="学号" width="110" />
      <el-table-column prop="name" label="姓名" width="90" />
      <el-table-column label="性别" width="70">
        <template #default="{ row }">{{ row.gender === 1 ? '男' : '女' }}</template>
      </el-table-column>
      <el-table-column prop="className" label="班级" width="120" />
      <el-table-column prop="phone" label="联系电话" width="130" />
      <el-table-column label="宿舍" min-width="150">
        <template #default="{ row }">
          <span v-if="row.roomNo">{{ row.buildingName }} {{ row.roomNo }} · {{ row.bedNo }} 号床</span>
          <span v-else class="text-muted">未分配</span>
        </template>
      </el-table-column>
      <el-table-column label="状态" width="90">
        <template #default="{ row }">
          <el-tag :type="statusType(row.status)">{{ statusText(row.status) }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="230" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" @click="openAssign(row)">
            {{ row.dormitoryId ? '调宿' : '分配' }}
          </el-button>
          <el-button link type="primary" @click="openDialog(row)">编辑</el-button>
          <el-button link type="warning" v-if="row.dormitoryId" @click="checkout(row)">退宿</el-button>
          <el-button link type="danger" v-if="store.isAdmin" @click="remove(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        v-model:current-page="query.page"
        v-model:page-size="query.size"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next"
        @current-change="load"
        @size-change="search"
      />
    </div>

    <!-- 新增 / 编辑 -->
    <el-dialog v-model="dialogVisible" :title="form.id ? '编辑学生' : '新增学生'" width="520px">
      <el-form :model="form" label-width="90px">
        <el-form-item label="学号" required>
          <el-input v-model="form.studentNo" :disabled="!!form.id" placeholder="登录账号即为学号" maxlength="30" />
        </el-form-item>
        <el-form-item label="姓名" required>
          <el-input v-model="form.name" maxlength="50" />
        </el-form-item>
        <el-form-item label="性别">
          <el-radio-group v-model="form.gender">
            <el-radio :label="1">男</el-radio>
            <el-radio :label="0">女</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="班级">
          <el-input v-model="form.className" maxlength="50" />
        </el-form-item>
        <el-form-item label="联系电话">
          <el-input v-model="form.phone" maxlength="20" />
        </el-form-item>
        <el-alert
          v-if="!form.id"
          type="info"
          :closable="false"
          show-icon
          title="新增后系统会自动创建学生登录账号，账号为学号，初始密码 123456"
          style="margin-left: 10px"
        />
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="save">保存</el-button>
      </template>
    </el-dialog>

    <!-- 分配宿舍 -->
    <el-dialog v-model="assignVisible" :title="`为 ${assignRow.name || ''} 分配宿舍`" width="480px">
      <el-form label-width="90px">
        <el-form-item label="楼栋">
          <el-select v-model="assign.buildingId" placeholder="请选择楼栋" style="width: 100%" @change="onBuildingChange">
            <el-option v-for="b in buildings" :key="b.id" :label="b.name" :value="b.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="宿舍">
          <el-select v-model="assign.dormitoryId" placeholder="请选择宿舍" style="width: 100%">
            <el-option
              v-for="d in availableDorms"
              :key="d.id"
              :label="`${d.roomNo}（${d.occupied}/${d.capacity} 人）`"
              :value="d.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="床位号">
          <el-input-number v-model="assign.bedNo" :min="1" :max="12" placeholder="留空自动分配" />
          <span class="text-muted" style="margin-left: 8px">留空则自动分配空床位</span>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="assignVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="saveAssign">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { buildingApi, dormitoryApi, studentApi } from '../../api'
import { downloadFile } from '../../utils/request'
import { useUserStore } from '../../stores/user'

const store = useUserStore()
const loading = ref(false)
const saving = ref(false)
const list = ref([])
const total = ref(0)
const buildings = ref([])
const dialogVisible = ref(false)
const assignVisible = ref(false)
const availableDorms = ref([])
const assignRow = ref({})

const query = reactive({ page: 1, size: 10, buildingId: null, status: null, keyword: '' })
const form = reactive({ id: null, studentNo: '', name: '', gender: 1, className: '', phone: '', dormitoryId: null, bedNo: null })
const assign = reactive({ buildingId: null, dormitoryId: null, bedNo: null })

function statusText (s) {
  return { 1: '在住', 0: '退宿', 2: '待分配' }[s] || '未知'
}

function statusType (s) {
  return { 1: 'success', 0: 'info', 2: 'warning' }[s] || 'info'
}

async function load () {
  loading.value = true
  try {
    const res = await studentApi.page(query)
    list.value = res.data.records
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

function search () {
  query.page = 1
  load()
}

function reset () {
  query.buildingId = null
  query.status = null
  query.keyword = ''
  search()
}

async function loadBuildings () {
  const res = await buildingApi.options()
  buildings.value = res.data
}

function openDialog (row) {
  Object.assign(form, { id: null, studentNo: '', name: '', gender: 1, className: '', phone: '', dormitoryId: null, bedNo: null })
  if (row) {
    Object.assign(form, row)
  }
  dialogVisible.value = true
}

async function save () {
  if (!form.studentNo || !form.name) {
    ElMessage.warning('请填写学号和姓名')
    return
  }
  saving.value = true
  try {
    if (form.id) {
      await studentApi.update(form.id, form)
      ElMessage.success('保存成功')
    } else {
      await studentApi.create(form)
      ElMessage.success('新增成功')
    }
    dialogVisible.value = false
    load()
  } finally {
    saving.value = false
  }
}

async function openAssign (row) {
  assignRow.value = row
  assign.buildingId = row.buildingId || null
  assign.dormitoryId = null
  assign.bedNo = null
  const res = await dormitoryApi.available({})
  availableDorms.value = res.data
  if (assign.buildingId) {
    availableDorms.value = res.data.filter((d) => d.buildingId === assign.buildingId)
  }
  assignVisible.value = true
}

function onBuildingChange (val) {
  assign.dormitoryId = null
  dormitoryApi.available({ buildingId: val }).then((res) => {
    availableDorms.value = res.data
  })
}

async function saveAssign () {
  if (!assign.dormitoryId) {
    ElMessage.warning('请选择宿舍')
    return
  }
  saving.value = true
  try {
    await studentApi.assign(assignRow.value.id, { dormitoryId: assign.dormitoryId, bedNo: assign.bedNo })
    ElMessage.success('操作成功')
    assignVisible.value = false
    load()
  } finally {
    saving.value = false
  }
}

function checkout (row) {
  ElMessageBox.confirm(`确定为 ${row.name} 办理退宿吗？`, '提示', { type: 'warning' })
    .then(async () => {
      await studentApi.checkout(row.id)
      ElMessage.success('退宿成功')
      load()
    })
    .catch(() => {})
}

function remove (row) {
  ElMessageBox.confirm(`确定删除学生「${row.name}」吗？其登录账号与报修记录会一并删除。`, '提示', { type: 'warning' })
    .then(async () => {
      await studentApi.remove(row.id)
      ElMessage.success('删除成功')
      load()
    })
    .catch(() => {})
}

function exportExcel () {
  downloadFile('/export/students', { keyword: query.keyword, buildingId: query.buildingId })
}

onMounted(() => {
  load()
  loadBuildings()
})
</script>
