<template>
  <div class="page-card">
    <h3 class="page-title">{{ store.isStudent ? '我的水电费' : '水电费管理' }}</h3>
    <div class="toolbar">
      <el-select v-model="query.billMonth" placeholder="全部账期" clearable style="width: 150px" @change="search">
        <el-option v-for="m in months" :key="m" :label="m" :value="m" />
      </el-select>
      <el-select v-model="query.paid" placeholder="缴费状态" clearable style="width: 130px" @change="search">
        <el-option label="未缴" :value="0" />
        <el-option label="已缴" :value="1" />
      </el-select>
      <el-button type="primary" @click="search">查询</el-button>
      <el-button @click="reset">重置</el-button>
      <div class="spacer"></div>
      <span class="text-muted" v-if="!store.isStudent">合计 {{ total }} 条记录</span>
      <el-button type="primary" v-if="store.isAdmin" @click="openDialog">
        <el-icon><Plus /></el-icon> 录入水电费
      </el-button>
    </div>

    <el-table :data="list" v-loading="loading" stripe border>
      <el-table-column label="宿舍" min-width="170">
        <template #default="{ row }">{{ row.buildingName }} {{ row.roomNo }}</template>
      </el-table-column>
      <el-table-column prop="billMonth" label="账期" width="100" />
      <el-table-column label="用水" width="130">
        <template #default="{ row }">{{ row.waterUsage }} 吨 / {{ row.waterFee }} 元</template>
      </el-table-column>
      <el-table-column label="用电" width="140">
        <template #default="{ row }">{{ row.electricUsage }} 度 / {{ row.electricFee }} 元</template>
      </el-table-column>
      <el-table-column label="合计" width="110">
        <template #default="{ row }">
          <span style="font-weight: 600; color: #e6a23c">{{ row.totalFee }} 元</span>
        </template>
      </el-table-column>
      <el-table-column label="状态" width="100">
        <template #default="{ row }">
          <el-tag :type="row.paid === 1 ? 'success' : 'danger'">{{ row.paid === 1 ? '已缴' : '未缴' }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="缴费时间" width="160">
        <template #default="{ row }">{{ row.payTime ? String(row.payTime).replace('T', ' ').slice(0, 16) : '—' }}</template>
      </el-table-column>
      <el-table-column label="操作" width="140" fixed="right" v-if="!store.isStudent">
        <template #default="{ row }">
          <el-button link type="primary" v-if="row.paid === 0" @click="pay(row)">标记已缴</el-button>
          <span v-else class="text-muted">已完成</span>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        v-model:current-page="query.page"
        v-model:page-size="query.size"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next"
        @current-change="load"
        @size-change="search"
      />
    </div>

    <el-dialog v-model="dialogVisible" title="录入水电费" width="500px">
      <el-form :model="form" label-width="90px">
        <el-form-item label="宿舍" required>
          <el-select v-model="form.dormitoryId" placeholder="请选择宿舍" filterable style="width: 100%">
            <el-option v-for="d in dorms" :key="d.id" :label="`${d.buildingName} ${d.roomNo}`" :value="d.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="账期" required>
          <el-date-picker v-model="form.billMonth" type="month" value-format="YYYY-MM" placeholder="选择月份" style="width: 100%" />
        </el-form-item>
        <el-form-item label="用水量(吨)">
          <el-input-number v-model="form.waterUsage" :min="0" :precision="1" />
        </el-form-item>
        <el-form-item label="水费(元)">
          <el-input-number v-model="form.waterFee" :min="0" :precision="2" />
        </el-form-item>
        <el-form-item label="用电量(度)">
          <el-input-number v-model="form.electricUsage" :min="0" :precision="1" />
        </el-form-item>
        <el-form-item label="电费(元)">
          <el-input-number v-model="form.electricFee" :min="0" :precision="2" />
        </el-form-item>
        <el-form-item label="合计">
          <span style="font-weight: 600; color: #e6a23c">{{ (Number(form.waterFee || 0) + Number(form.electricFee || 0)).toFixed(2) }} 元</span>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="save">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { dormitoryApi, waterApi } from '../../api'
import { useUserStore } from '../../stores/user'

const store = useUserStore()
const loading = ref(false)
const saving = ref(false)
const list = ref([])
const total = ref(0)
const months = ref([])
const dorms = ref([])
const dialogVisible = ref(false)

const query = reactive({ page: 1, size: 10, billMonth: null, paid: null })
const form = reactive({ dormitoryId: null, billMonth: '', waterUsage: 0, waterFee: 0, electricUsage: 0, electricFee: 0 })

async function load () {
  loading.value = true
  try {
    const res = await waterApi.page(query)
    list.value = res.data.records
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

function search () {
  query.page = 1
  load()
}

function reset () {
  query.billMonth = null
  query.paid = null
  search()
}

async function loadRefs () {
  const m = await waterApi.months()
  months.value = m.data
  if (store.isAdmin) {
    const d = await dormitoryApi.page({ page: 1, size: 500 })
    dorms.value = d.data.records
  }
}

function openDialog () {
  Object.assign(form, { dormitoryId: null, billMonth: '', waterUsage: 0, waterFee: 0, electricUsage: 0, electricFee: 0 })
  dialogVisible.value = true
}

async function save () {
  if (!form.dormitoryId || !form.billMonth) {
    ElMessage.warning('请选择宿舍和账期')
    return
  }
  saving.value = true
  try {
    await waterApi.create(form)
    ElMessage.success('录入成功')
    dialogVisible.value = false
    load()
    loadRefs()
  } finally {
    saving.value = false
  }
}

function pay (row) {
  ElMessageBox.confirm(`确认 ${row.buildingName} ${row.roomNo} ${row.billMonth} 已缴费 ${row.totalFee} 元？`, '缴费确认', { type: 'warning' })
    .then(async () => {
      await waterApi.pay(row.id)
      ElMessage.success('已标记为已缴')
      load()
    })
    .catch(() => {})
}

onMounted(() => {
  load()
  loadRefs()
})
</script>
