<template>
  <div class="page-card">
    <h3 class="page-title">楼栋管理</h3>
    <div class="toolbar">
      <el-input v-model="query.keyword" placeholder="搜索楼栋编号 / 名称" clearable style="width: 240px" @keyup.enter="search" />
      <el-button type="primary" @click="search">查询</el-button>
      <el-button @click="reset">重置</el-button>
      <div class="spacer"></div>
      <el-button type="primary" v-if="store.isAdmin" @click="openDialog()">
        <el-icon><Plus /></el-icon> 新增楼栋
      </el-button>
    </div>

    <el-table :data="list" v-loading="loading" stripe border>
      <el-table-column prop="code" label="楼栋编号" width="100" />
      <el-table-column prop="name" label="楼栋名称" min-width="150" />
      <el-table-column prop="managerName" label="负责宿管" width="120">
        <template #default="{ row }">{{ row.managerName || '未分配' }}</template>
      </el-table-column>
      <el-table-column prop="floors" label="楼层数" width="90" />
      <el-table-column prop="dormCount" label="宿舍数" width="90" />
      <el-table-column label="床位 / 已住" width="130">
        <template #default="{ row }">{{ row.occupied || 0 }} / {{ row.capacity || 0 }}</template>
      </el-table-column>
      <el-table-column label="入住率" width="170">
        <template #default="{ row }">
          <el-progress :percentage="rate(row)" :stroke-width="10" />
        </template>
      </el-table-column>
      <el-table-column prop="remark" label="备注" min-width="160" show-overflow-tooltip />
      <el-table-column label="操作" width="150" fixed="right" v-if="store.isAdmin">
        <template #default="{ row }">
          <el-button link type="primary" @click="openDialog(row)">编辑</el-button>
          <el-button link type="danger" @click="remove(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        v-model:current-page="query.page"
        v-model:page-size="query.size"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next"
        @current-change="load"
        @size-change="search"
      />
    </div>

    <el-dialog v-model="dialogVisible" :title="form.id ? '编辑楼栋' : '新增楼栋'" width="480px">
      <el-form :model="form" label-width="90px">
        <el-form-item label="楼栋编号" required>
          <el-input v-model="form.code" placeholder="如 A" maxlength="20" />
        </el-form-item>
        <el-form-item label="楼栋名称" required>
          <el-input v-model="form.name" placeholder="如 听雨楼（A栋）" maxlength="50" />
        </el-form-item>
        <el-form-item label="负责宿管">
          <el-select v-model="form.managerId" placeholder="请选择宿管" clearable style="width: 100%">
            <el-option v-for="m in managers" :key="m.id" :label="`${m.realName}（${m.username}）`" :value="m.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="楼层数">
          <el-input-number v-model="form.floors" :min="1" :max="30" />
        </el-form-item>
        <el-form-item label="备注">
          <el-input v-model="form.remark" type="textarea" :rows="2" maxlength="255" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="save">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { buildingApi, userApi } from '../../api'
import { useUserStore } from '../../stores/user'

const store = useUserStore()
const loading = ref(false)
const saving = ref(false)
const list = ref([])
const total = ref(0)
const managers = ref([])
const dialogVisible = ref(false)

const query = reactive({ page: 1, size: 10, keyword: '' })
const form = reactive({ id: null, code: '', name: '', managerId: null, floors: 6, remark: '' })

function rate (row) {
  if (!row.capacity) return 0
  return Math.round((row.occupied || 0) * 100 / row.capacity)
}

async function load () {
  loading.value = true
  try {
    const res = await buildingApi.page(query)
    list.value = res.data.records
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

function search () {
  query.page = 1
  load()
}

function reset () {
  query.keyword = ''
  query.page = 1
  load()
}

async function loadManagers () {
  if (!store.isAdmin) return
  const res = await userApi.managers()
  managers.value = res.data
}

function openDialog (row) {
  Object.assign(form, { id: null, code: '', name: '', managerId: null, floors: 6, remark: '' })
  if (row) {
    Object.assign(form, row)
    form.managerId = row.managerId || null
  }
  dialogVisible.value = true
}

async function save () {
  if (!form.code || !form.name) {
    ElMessage.warning('请填写楼栋编号和名称')
    return
  }
  saving.value = true
  try {
    if (form.id) {
      await buildingApi.update(form.id, form)
      ElMessage.success('保存成功')
    } else {
      await buildingApi.create(form)
      ElMessage.success('新增成功')
    }
    dialogVisible.value = false
    load()
  } finally {
    saving.value = false
  }
}

function remove (row) {
  ElMessageBox.confirm(`确定删除楼栋「${row.name}」吗？`, '提示', { type: 'warning' })
    .then(async () => {
      await buildingApi.remove(row.id)
      ElMessage.success('删除成功')
      load()
    })
    .catch(() => {})
}

onMounted(() => {
  load()
  loadManagers()
})
</script>
