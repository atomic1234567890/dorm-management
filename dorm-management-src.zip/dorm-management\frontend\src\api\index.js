import request from '../utils/request'

export const authApi = {
  login: (data) => request.post('/auth/login', data),
  me: () => request.get('/auth/me'),
  changePassword: (data) => request.post('/auth/password', data)
}

export const dashboardApi = {
  stats: () => request.get('/dashboard/stats')
}

export const buildingApi = {
  page: (params) => request.get('/buildings', { params }),
  options: () => request.get('/buildings/options'),
  create: (data) => request.post('/buildings', data),
  update: (id, data) => request.put(`/buildings/${id}`, data),
  remove: (id) => request.delete(`/buildings/${id}`)
}

export const dormitoryApi = {
  page: (params) => request.get('/dormitories', { params }),
  detail: (id) => request.get(`/dormitories/${id}`),
  students: (id) => request.get(`/dormitories/${id}/students`),
  available: (params) => request.get('/dormitories/available', { params }),
  create: (data) => request.post('/dormitories', data),
  update: (id, data) => request.put(`/dormitories/${id}`, data),
  remove: (id) => request.delete(`/dormitories/${id}`)
}

export const studentApi = {
  page: (params) => request.get('/students', { params }),
  detail: (id) => request.get(`/students/${id}`),
  my: () => request.get('/students/my'),
  create: (data) => request.post('/students', data),
  update: (id, data) => request.put(`/students/${id}`, data),
  assign: (id, data) => request.put(`/students/${id}/assign`, data),
  checkout: (id) => request.put(`/students/${id}/checkout`),
  remove: (id) => request.delete(`/students/${id}`)
}

export const repairApi = {
  page: (params) => request.get('/repairs', { params }),
  detail: (id) => request.get(`/repairs/${id}`),
  create: (data) => request.post('/repairs', data),
  dispatch: (id, data) => request.put(`/repairs/${id}/dispatch`, data),
  finish: (id, data) => request.put(`/repairs/${id}/finish`, data),
  cancel: (id) => request.put(`/repairs/${id}/cancel`)
}

export const visitorApi = {
  page: (params) => request.get('/visitors', { params }),
  create: (data) => request.post('/visitors', data),
  leave: (id) => request.put(`/visitors/${id}/leave`)
}

export const noticeApi = {
  page: (params) => request.get('/notices', { params }),
  latest: (limit = 5) => request.get('/notices/latest', { params: { limit } }),
  detail: (id) => request.get(`/notices/${id}`),
  create: (data) => request.post('/notices', data),
  update: (id, data) => request.put(`/notices/${id}`, data),
  remove: (id) => request.delete(`/notices/${id}`)
}

export const sanitaryApi = {
  page: (params) => request.get('/sanitary', { params }),
  create: (data) => request.post('/sanitary', data),
  remove: (id) => request.delete(`/sanitary/${id}`)
}

export const violationApi = {
  page: (params) => request.get('/violations', { params }),
  create: (data) => request.post('/violations', data),
  remove: (id) => request.delete(`/violations/${id}`)
}

export const waterApi = {
  page: (params) => request.get('/water-electric', { params }),
  months: () => request.get('/water-electric/months'),
  create: (data) => request.post('/water-electric', data),
  update: (id, data) => request.put(`/water-electric/${id}`, data),
  pay: (id) => request.put(`/water-electric/${id}/pay`)
}

export const adjustApi = {
  page: (params) => request.get('/adjust-requests', { params }),
  apply: (data) => request.post('/adjust-requests', data),
  approve: (id, data) => request.put(`/adjust-requests/${id}/approve`, data)
}

export const userApi = {
  page: (params) => request.get('/users', { params }),
  managers: () => request.get('/users/managers'),
  create: (data) => request.post('/users', data),
  update: (id, data) => request.put(`/users/${id}`, data),
  resetPassword: (id) => request.put(`/users/${id}/reset-password`),
  toggleStatus: (id) => request.put(`/users/${id}/status`),
  remove: (id) => request.delete(`/users/${id}`)
}
