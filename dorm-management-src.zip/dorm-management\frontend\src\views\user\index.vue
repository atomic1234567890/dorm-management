<template>
  <div class="page-card">
    <h3 class="page-title">账号管理</h3>
    <div class="toolbar">
      <el-select v-model="query.role" placeholder="全部角色" clearable style="width: 140px" @change="search">
        <el-option label="管理员" value="ADMIN" />
        <el-option label="宿管" value="MANAGER" />
        <el-option label="学生" value="STUDENT" />
      </el-select>
      <el-input v-model="query.keyword" placeholder="账号 / 姓名 / 手机号" clearable style="width: 220px" @keyup.enter="search" />
      <el-button type="primary" @click="search">查询</el-button>
      <el-button @click="reset">重置</el-button>
      <div class="spacer"></div>
      <el-button type="primary" @click="openDialog()">
        <el-icon><Plus /></el-icon> 新增账号
      </el-button>
    </div>

    <el-table :data="list" v-loading="loading" stripe border>
      <el-table-column prop="username" label="账号" width="130" />
      <el-table-column prop="realName" label="姓名" width="110" />
      <el-table-column label="角色" width="100">
        <template #default="{ row }">
          <el-tag :type="roleType(row.role)">{{ roleText(row.role) }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="phone" label="手机号" width="140" />
      <el-table-column prop="buildingName" label="负责楼栋" min-width="140">
        <template #default="{ row }">{{ row.buildingName || '—' }}</template>
      </el-table-column>
      <el-table-column label="状态" width="100">
        <template #default="{ row }">
          <el-switch :model-value="row.status === 1" @change="toggle(row)" />
        </template>
      </el-table-column>
      <el-table-column label="创建时间" width="170">
        <template #default="{ row }">{{ formatTime(row.createTime) }}</template>
      </el-table-column>
      <el-table-column label="操作" width="210" fixed="right">
        <template #default="{ row }">
          <el-button link type="primary" @click="openDialog(row)">编辑</el-button>
          <el-button link type="warning" @click="resetPwd(row)">重置密码</el-button>
          <el-button link type="danger" @click="remove(row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        v-model:current-page="query.page"
        v-model:page-size="query.size"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next"
        @current-change="load"
        @size-change="search"
      />
    </div>

    <el-dialog v-model="dialogVisible" :title="form.id ? '编辑账号' : '新增账号'" width="480px">
      <el-form :model="form" label-width="80px">
        <el-form-item label="账号" required>
          <el-input v-model="form.username" maxlength="50" :disabled="!!form.id" />
        </el-form-item>
        <el-form-item label="姓名" required>
          <el-input v-model="form.realName" maxlength="50" />
        </el-form-item>
        <el-form-item label="角色">
          <el-select v-model="form.role" style="width: 100%">
            <el-option label="管理员" value="ADMIN" />
            <el-option label="宿管" value="MANAGER" />
            <el-option label="学生" value="STUDENT" />
          </el-select>
        </el-form-item>
        <el-form-item label="手机号">
          <el-input v-model="form.phone" maxlength="20" />
        </el-form-item>
        <el-alert v-if="!form.id" type="info" :closable="false" show-icon
                  title="新增账号初始密码为 123456，请提醒用户首次登录后修改" />
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="save">保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { userApi } from '../../api'

const loading = ref(false)
const saving = ref(false)
const list = ref([])
const total = ref(0)
const dialogVisible = ref(false)

const query = reactive({ page: 1, size: 10, role: null, keyword: '' })
const form = reactive({ id: null, username: '', realName: '', role: 'MANAGER', phone: '' })

function roleText (r) {
  return { ADMIN: '管理员', MANAGER: '宿管', STUDENT: '学生' }[r] || r
}

function roleType (r) {
  return { ADMIN: 'danger', MANAGER: 'warning', STUDENT: 'success' }[r] || 'info'
}

function formatTime (t) {
  return t ? String(t).replace('T', ' ').slice(0, 16) : ''
}

async function load () {
  loading.value = true
  try {
    const res = await userApi.page(query)
    list.value = res.data.records
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

function search () {
  query.page = 1
  load()
}

function reset () {
  query.role = null
  query.keyword = ''
  search()
}

function openDialog (row) {
  Object.assign(form, { id: null, username: '', realName: '', role: 'MANAGER', phone: '' })
  if (row) {
    Object.assign(form, row)
  }
  dialogVisible.value = true
}

async function save () {
  if (!form.username || !form.realName) {
    ElMessage.warning('请填写账号和姓名')
    return
  }
  saving.value = true
  try {
    if (form.id) {
      await userApi.update(form.id, form)
      ElMessage.success('保存成功')
    } else {
      await userApi.create(form)
      ElMessage.success('新增成功')
    }
    dialogVisible.value = false
    load()
  } finally {
    saving.value = false
  }
}

function resetPwd (row) {
  ElMessageBox.confirm(`确定将「${row.realName}」的密码重置为 123456 吗？`, '提示', { type: 'warning' })
    .then(async () => {
      await userApi.resetPassword(row.id)
      ElMessage.success('密码已重置')
    })
    .catch(() => {})
}

function toggle (row) {
  userApi.toggleStatus(row.id).then(() => {
    ElMessage.success('状态已更新')
    load()
  })
}

function remove (row) {
  ElMessageBox.confirm(`确定删除账号「${row.username}」吗？`, '提示', { type: 'warning' })
    .then(async () => {
      await userApi.remove(row.id)
      ElMessage.success('删除成功')
      load()
    })
    .catch(() => {})
}

onMounted(load)
</script>
