<template>
  <div class="my-dorm">
    <div class="hero" v-if="student">
      <div class="hero-left">
        <div class="hello">你好，{{ student.name }}</div>
        <div class="sub">{{ student.className }} · 学号 {{ student.studentNo }}</div>
      </div>
      <div class="hero-right">
        <div class="room" v-if="student.roomNo">
          <div class="room-label">我的宿舍</div>
          <div class="room-value">{{ student.buildingName }} {{ student.roomNo }}</div>
          <div class="room-bed">{{ student.bedNo }} 号床</div>
        </div>
        <div class="room" v-else>
          <div class="room-label">我的宿舍</div>
          <div class="room-value">暂未分配</div>
          <div class="room-bed">请联系宿管办理入住</div>
        </div>
      </div>
    </div>

    <div class="grid">
      <div class="card">
        <div class="card-title">
          <el-icon><UserFilled /></el-icon> 室友
          <span class="text-muted">（{{ roommates.length }} 人）</span>
        </div>
        <div v-if="roommates.length" class="roommates">
          <div v-for="r in roommates" :key="r.id" class="mate">
            <el-avatar :size="34">{{ r.name.slice(0, 1) }}</el-avatar>
            <div>
              <div class="mate-name">{{ r.name }}</div>
              <div class="text-muted">{{ r.bedNo }} 号床 · {{ r.className }}</div>
            </div>
          </div>
        </div>
        <el-empty v-else description="暂无室友信息" :image-size="60" />
      </div>

      <div class="card">
        <div class="card-title">
          <el-icon><Tools /></el-icon> 我的报修
          <el-link type="primary" :underline="false" style="margin-left: auto" @click="$router.push('/repairs')">全部</el-link>
        </div>
        <div v-for="r in repairs" :key="r.id" class="line">
          <span class="line-main">{{ r.type }}：{{ r.description }}</span>
          <el-tag size="small" :type="repairType(r.status)">{{ repairText(r.status) }}</el-tag>
        </div>
        <el-empty v-if="repairs.length === 0" description="还没有报修记录" :image-size="60" />
      </div>

      <div class="card">
        <div class="card-title">
          <el-icon><Coin /></el-icon> 待缴水电费
          <el-link type="primary" :underline="false" style="margin-left: auto" @click="$router.push('/water')">明细</el-link>
        </div>
        <div v-for="w in bills" :key="w.id" class="line">
          <span class="line-main">{{ w.billMonth }} 账期</span>
          <span style="color: #f56c6c; font-weight: 600">{{ w.totalFee }} 元</span>
        </div>
        <el-empty v-if="bills.length === 0" description="暂无欠费，感谢配合" :image-size="60" />
      </div>

      <div class="card">
        <div class="card-title">
          <el-icon><Bell /></el-icon> 最新公告
          <el-link type="primary" :underline="false" style="margin-left: auto" @click="$router.push('/notices')">全部</el-link>
        </div>
        <div v-for="n in notices" :key="n.id" class="line">
          <span class="line-main">{{ n.title }}</span>
          <span class="text-muted" style="white-space: nowrap">{{ (n.createTime || '').slice(5, 10) }}</span>
        </div>
        <el-empty v-if="notices.length === 0" description="暂无公告" :image-size="60" />
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import { dormitoryApi, noticeApi, repairApi, studentApi, waterApi } from '../../api'

const student = ref(null)
const roommates = ref([])
const repairs = ref([])
const bills = ref([])
const notices = ref([])

function repairText (s) {
  return { 0: '待派单', 1: '维修中', 2: '已完成', 3: '已取消' }[s] || ''
}

function repairType (s) {
  return { 0: 'warning', 1: 'primary', 2: 'success', 3: 'info' }[s] || 'info'
}

async function load () {
  const res = await studentApi.my()
  student.value = res.data
  if (student.value && student.value.dormitoryId) {
    const mates = await dormitoryApi.students(student.value.dormitoryId)
    roommates.value = mates.data
  }
  const r = await repairApi.page({ page: 1, size: 5 })
  repairs.value = r.data.records
  const w = await waterApi.page({ page: 1, size: 5, paid: 0 })
  bills.value = w.data.records
  const n = await noticeApi.latest(5)
  notices.value = n.data
}

onMounted(load)
</script>

<style scoped>
.hero {
  background: linear-gradient(120deg, #2f6fed, #4d8bff);
  border-radius: 12px;
  color: #fff;
  padding: 24px 28px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.hello {
  font-size: 24px;
  font-weight: 700;
}

.sub {
  margin-top: 8px;
  font-size: 13px;
  opacity: 0.85;
}

.hero-right {
  text-align: right;
}

.room-label {
  font-size: 12px;
  opacity: 0.8;
}

.room-value {
  font-size: 22px;
  font-weight: 700;
  margin-top: 4px;
}

.room-bed {
  font-size: 13px;
  opacity: 0.85;
  margin-top: 2px;
}

.grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 14px;
}

.card {
  background: #fff;
  border-radius: 10px;
  padding: 16px 18px;
  box-shadow: 0 1px 4px rgba(31, 42, 68, 0.06);
  min-height: 200px;
}

.card-title {
  display: flex;
  align-items: center;
  gap: 6px;
  font-weight: 600;
  margin-bottom: 12px;
}

.roommates {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.mate {
  display: flex;
  align-items: center;
  gap: 10px;
}

.mate-name {
  font-size: 14px;
  font-weight: 500;
}

.line {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
  padding: 9px 0;
  border-bottom: 1px dashed #eef1f6;
  font-size: 13px;
}

.line-main {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
</style>
