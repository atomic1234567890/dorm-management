<template>
  <div class="page-card">
    <h3 class="page-title">调宿申请</h3>
    <div class="toolbar">
      <el-select v-model="query.status" placeholder="全部状态" clearable style="width: 140px" @change="search">
        <el-option label="待审批" :value="0" />
        <el-option label="已通过" :value="1" />
        <el-option label="已驳回" :value="2" />
      </el-select>
      <el-button type="primary" @click="search">查询</el-button>
      <el-button @click="reset">重置</el-button>
      <div class="spacer"></div>
      <el-button type="primary" v-if="store.isStudent" @click="openApply">
        <el-icon><Plus /></el-icon> 申请调宿
      </el-button>
    </div>

    <el-table :data="list" v-loading="loading" stripe border>
      <el-table-column prop="studentName" label="学生" width="100" />
      <el-table-column prop="studentNo" label="学号" width="110" />
      <el-table-column label="原宿舍" min-width="140">
        <template #default="{ row }">{{ row.fromBuilding || '' }} {{ row.fromRoom || '—' }}</template>
      </el-table-column>
      <el-table-column label="目标宿舍" min-width="140">
        <template #default="{ row }">{{ row.toBuilding || '' }} {{ row.toRoom || '未指定' }}</template>
      </el-table-column>
      <el-table-column prop="reason" label="调宿理由" min-width="220" show-overflow-tooltip />
      <el-table-column label="状态" width="100">
        <template #default="{ row }">
          <el-tag :type="statusType(row.status)">{{ statusText(row.status) }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="approverName" label="审批人" width="100">
        <template #default="{ row }">{{ row.approverName || '—' }}</template>
      </el-table-column>
      <el-table-column label="申请时间" width="160">
        <template #default="{ row }">{{ formatTime(row.createTime) }}</template>
      </el-table-column>
      <el-table-column label="操作" width="160" fixed="right" v-if="!store.isStudent">
        <template #default="{ row }">
          <template v-if="row.status === 0">
            <el-button link type="success" @click="approve(row, true)">通过</el-button>
            <el-button link type="danger" @click="approve(row, false)">驳回</el-button>
          </template>
          <span v-else class="text-muted">{{ row.approveRemark || '已处理' }}</span>
        </template>
      </el-table-column>
    </el-table>

    <div class="pager">
      <el-pagination
        v-model:current-page="query.page"
        v-model:page-size="query.size"
        :total="total"
        :page-sizes="[10, 20, 50]"
        layout="total, sizes, prev, pager, next"
        @current-change="load"
        @size-change="search"
      />
    </div>

    <el-dialog v-model="applyVisible" title="申请调宿" width="500px">
      <el-form :model="applyForm" label-width="90px">
        <el-form-item label="目标宿舍">
          <el-select v-model="applyForm.toDormitoryId" placeholder="请选择想调往的宿舍" filterable style="width: 100%">
            <el-option
              v-for="d in availableDorms"
              :key="d.id"
              :label="`${d.buildingName} ${d.roomNo}（${d.occupied}/${d.capacity} 人）`"
              :value="d.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="调宿理由" required>
          <el-input v-model="applyForm.reason" type="textarea" :rows="4" maxlength="500" show-word-limit
                    placeholder="请说明调宿原因，方便宿管审批" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="applyVisible = false">取消</el-button>
        <el-button type="primary" :loading="saving" @click="submitApply">提交申请</el-button>
      </template>
    </el-dialog>

    <el-dialog v-model="approveVisible" :title="approveForm.approve ? '通过调宿申请' : '驳回调宿申请'" width="460px">
      <el-form label-width="90px">
        <el-form-item label="审批意见">
          <el-input v-model="approveForm.remark" type="textarea" :rows="3" maxlength="255"
                    :placeholder="approveForm.approve ? '可选，如：同意调宿，已安排床位' : '请填写驳回原因'" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="approveVisible = false">取消</el-button>
        <el-button :type="approveForm.approve ? 'primary' : 'danger'" :loading="saving" @click="submitApprove">
          确定
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { adjustApi, dormitoryApi } from '../../api'
import { useUserStore } from '../../stores/user'

const store = useUserStore()
const loading = ref(false)
const saving = ref(false)
const list = ref([])
const total = ref(0)
const availableDorms = ref([])
const applyVisible = ref(false)
const approveVisible = ref(false)
const currentRow = ref(null)

const query = reactive({ page: 1, size: 10, status: null })
const applyForm = reactive({ toDormitoryId: null, reason: '' })
const approveForm = reactive({ approve: true, remark: '' })

function statusText (s) {
  return { 0: '待审批', 1: '已通过', 2: '已驳回' }[s] || '未知'
}

function statusType (s) {
  return { 0: 'warning', 1: 'success', 2: 'danger' }[s] || 'info'
}

function formatTime (t) {
  return t ? String(t).replace('T', ' ').slice(0, 16) : '—'
}

async function load () {
  loading.value = true
  try {
    const res = await adjustApi.page(query)
    list.value = res.data.records
    total.value = res.data.total
  } finally {
    loading.value = false
  }
}

function search () {
  query.page = 1
  load()
}

function reset () {
  query.status = null
  search()
}

async function openApply () {
  applyForm.toDormitoryId = null
  applyForm.reason = ''
  const res = await dormitoryApi.available({})
  availableDorms.value = res.data
  applyVisible.value = true
}

async function submitApply () {
  if (!applyForm.reason) {
    ElMessage.warning('请填写调宿理由')
    return
  }
  saving.value = true
  try {
    await adjustApi.apply(applyForm)
    ElMessage.success('申请已提交')
    applyVisible.value = false
    load()
  } finally {
    saving.value = false
  }
}

function approve (row, pass) {
  currentRow.value = row
  approveForm.approve = pass
  approveForm.remark = ''
  approveVisible.value = true
}

async function submitApprove () {
  if (!approveForm.approve && !approveForm.remark) {
    ElMessage.warning('驳回时请填写原因')
    return
  }
  saving.value = true
  try {
    await adjustApi.approve(currentRow.value.id, { approve: approveForm.approve, remark: approveForm.remark })
    ElMessage.success('审批完成')
    approveVisible.value = false
    load()
  } finally {
    saving.value = false
  }
}

onMounted(load)
</script>
