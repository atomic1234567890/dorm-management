# -*- coding: utf-8 -*-
"""把课程设计报告的 Markdown 转成排版好的 Word 文档。

用法：
    python scripts/md2docx.py docs/06-课程设计报告.md docs/宿舍管理系统-课程设计报告.docx
"""
import re
import sys
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

BODY_EAST = "宋体"
HEAD_EAST = "黑体"
LATIN = "Times New Roman"
MONO = "Consolas"

INLINE_RE = re.compile(r"(\*\*.+?\*\*|`[^`]+?`)")
IMAGE_RE = re.compile(r"^!\[[^\]]*\]\(([^)]+)\)$")


def set_run_font(run, size, *, east=BODY_EAST, latin=LATIN, bold=False, italic=False, color=None):
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.name = latin
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.append(rfonts)
    rfonts.set(qn("w:ascii"), latin)
    rfonts.set(qn("w:hAnsi"), latin)
    rfonts.set(qn("w:eastAsia"), east)
    if color is not None:
        run.font.color.rgb = RGBColor(*color)


def shade(element, fill):
    """给段落或单元格加底色。"""
    if hasattr(element, "_tc"):
        pr = element._tc.get_or_add_tcPr()
    else:
        pr = element._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill)
    pr.append(shd)


def add_inline(paragraph, text, size, *, east=BODY_EAST, bold=False, color=None):
    """处理 **加粗**、`代码` 两种行内标记。"""
    for token in INLINE_RE.split(text):
        if not token:
            continue
        if token.startswith("**") and token.endswith("**") and len(token) > 4:
            run = paragraph.add_run(token[2:-2])
            set_run_font(run, size, east=east, bold=True, color=color)
        elif token.startswith("`") and token.endswith("`") and len(token) > 2:
            run = paragraph.add_run(token[1:-1])
            set_run_font(run, size - 0.5, east=east, latin=MONO, bold=bold, color=(0x44, 0x44, 0x44))
        else:
            run = paragraph.add_run(token)
            set_run_font(run, size, east=east, bold=bold, color=color)


def add_body(doc, text, size=12, indent=True):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.line_spacing = 1.5
    pf.space_before = Pt(0)
    pf.space_after = Pt(4)
    if indent:
        pf.first_line_indent = Cm(0.74)
    add_inline(p, text, size)
    return p


def add_heading(doc, text, level):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.space_before = Pt(14 if level <= 2 else 10)
    pf.space_after = Pt(6 if level <= 2 else 4)
    pf.keep_with_next = True
    sizes = {1: 22, 2: 16, 3: 14, 4: 12}
    p.style = doc.styles["Heading %d" % min(level, 4)]
    run = p.add_run(text)
    set_run_font(run, sizes.get(level, 12), east=HEAD_EAST, bold=True, color=(0, 0, 0))
    if level == 1:
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    return p


def add_code(doc, lines):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.line_spacing = 1.0
    pf.left_indent = Cm(0.5)
    pf.space_before = Pt(4)
    pf.space_after = Pt(6)
    run = p.add_run("\n".join(lines))
    set_run_font(run, 9, east="宋体", latin=MONO, color=(0x33, 0x33, 0x33))
    shade(p, "F4F6F8")


def add_image(doc, path, width_cm=14):
    if not path.exists():
        return
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(6)
    p.add_run().add_picture(str(path), width=Cm(width_cm))


def fill_cell(cell, text, size=9, *, bold=False, center=False, base_dir=None):
    paragraph = cell.paragraphs[0]
    paragraph.paragraph_format.space_before = Pt(2)
    paragraph.paragraph_format.space_after = Pt(2)
    paragraph.paragraph_format.line_spacing = 1.15
    if center:
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    m = IMAGE_RE.match(text.strip())
    if m and base_dir is not None:
        img = (base_dir / m.group(1)).resolve()
        if img.exists():
            paragraph.add_run().add_picture(str(img), width=Cm(7.2))
            return
    add_inline(paragraph, text, size, bold=bold)


def add_table(doc, rows, base_dir):
    if not rows:
        return
    cols = max(len(r) for r in rows)
    table = doc.add_table(rows=len(rows), cols=cols)
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    for r_idx, row in enumerate(rows):
        for c_idx in range(cols):
            text = row[c_idx] if c_idx < len(row) else ""
            cell = table.cell(r_idx, c_idx)
            is_header = r_idx == 0
            fill_cell(cell, text, size=9, bold=is_header, center=is_header, base_dir=base_dir)
            if is_header:
                shade(cell, "E8EEF7")
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def split_row(line):
    line = line.strip()
    if line.startswith("|"):
        line = line[1:]
    if line.endswith("|"):
        line = line[:-1]
    return [c.strip() for c in line.split("|")]


def is_separator(line):
    return bool(re.match(r"^\|?[\s:|-]+\|[\s:|-]*$", line.strip())) and "-" in line


def convert(md_path, out_path):
    base_dir = md_path.parent
    lines = md_path.read_text(encoding="utf-8").splitlines()

    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = LATIN
    normal.font.size = Pt(12)
    normal.element.rPr.rFonts.set(qn("w:eastAsia"), BODY_EAST)

    section = doc.sections[0]
    section.page_width = Cm(21)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(2.54)
    section.bottom_margin = Cm(2.54)
    section.left_margin = Cm(2.8)
    section.right_margin = Cm(2.6)

    i = 0
    table_count = 0
    first_h1_done = False
    n = len(lines)
    while i < n:
        line = lines[i]
        stripped = line.strip()

        if not stripped:
            i += 1
            continue

        # 代码块
        if stripped.startswith("```"):
            i += 1
            block = []
            while i < n and not lines[i].strip().startswith("```"):
                block.append(lines[i])
                i += 1
            i += 1
            add_code(doc, block)
            continue

        # 表格
        if stripped.startswith("|") and i + 1 < n and is_separator(lines[i + 1]):
            rows = [split_row(stripped)]
            i += 2
            while i < n and lines[i].strip().startswith("|"):
                rows.append(split_row(lines[i]))
                i += 1
            add_table(doc, rows, base_dir)
            table_count += 1
            if table_count == 1 and rows[0][:2] == ["项目", "内容"]:
                doc.add_page_break()
            continue

        # 分隔线
        if re.match(r"^-{3,}$", stripped):
            i += 1
            continue

        # 图片
        m = IMAGE_RE.match(stripped)
        if m:
            add_image(doc, (base_dir / m.group(1)).resolve())
            i += 1
            continue

        # 标题
        hm = re.match(r"^(#{1,4})\s+(.*)$", stripped)
        if hm:
            level = len(hm.group(1))
            add_heading(doc, hm.group(2).strip(), level)
            if level == 1:
                first_h1_done = True
            i += 1
            continue

        # 引用
        if stripped.startswith(">"):
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.6)
            p.paragraph_format.line_spacing = 1.4
            add_inline(p, stripped.lstrip("> ").strip(), 10.5, color=(0x66, 0x66, 0x66))
            i += 1
            continue

        # 列表
        lm = re.match(r"^[-*]\s+(.*)$", stripped)
        if lm:
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.9)
            p.paragraph_format.line_spacing = 1.5
            p.paragraph_format.space_after = Pt(2)
            run = p.add_run("· ")
            set_run_font(run, 12)
            add_inline(p, lm.group(1), 12)
            i += 1
            continue

        nm = re.match(r"^(\d+[.、])\s+(.*)$", stripped)
        if nm:
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.9)
            p.paragraph_format.line_spacing = 1.5
            p.paragraph_format.space_after = Pt(2)
            add_inline(p, stripped, 12)
            i += 1
            continue

        # 普通段落
        add_body(doc, stripped, 12, indent=first_h1_done)
        i += 1

    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out_path))
    print("saved:", out_path)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    src = Path(sys.argv[1] if len(sys.argv) > 1 else "docs/06-课程设计报告.md")
    dst = Path(sys.argv[2] if len(sys.argv) > 2 else "docs/宿舍管理系统-课程设计报告.docx")
    convert(src, dst)
