-- =====================================================================
-- 宿舍管理系统 初始化数据（在 schema.sql 之后执行）
-- 所有账号初始密码均为 123456（BCrypt 加密存储）
-- =====================================================================
USE dorm_db;

SET @pwd = '$2a$10$nAvTcvA3/f//ClvM4VOv8OBA4Jm3REeDaNpvC8eQkZTVy2l7VZTsO';

-- ---------------------------------------------------------------------
-- 1. 管理员与宿管账号
-- ---------------------------------------------------------------------
INSERT INTO sys_user (username, password, real_name, role, phone, status) VALUES
('admin',     @pwd, '系统管理员', 'ADMIN',   '13900000000', 1),
('manager01', @pwd, '王建国',     'MANAGER', '13900000001', 1),
('manager02', @pwd, '李秀兰',     'MANAGER', '13900000002', 1),
('manager03', @pwd, '张强',       'MANAGER', '13900000003', 1);

-- ---------------------------------------------------------------------
-- 2. 楼栋
-- ---------------------------------------------------------------------
INSERT INTO building (code, name, manager_id, floors, remark) VALUES
('A', '听雨楼（A栋）', 2, 6, '男生宿舍，靠近东门'),
('B', '疏影楼（B栋）', 3, 6, '女生宿舍，靠近日湖'),
('C', '凌云楼（C栋）', 4, 6, '混合宿舍，含研究生床位');

-- ---------------------------------------------------------------------
-- 3. 宿舍：每栋 6 层，每层 6 间，共 108 间，每间 6 人
-- ---------------------------------------------------------------------
INSERT INTO dormitory (building_id, room_no, floor, capacity, occupied, status)
WITH RECURSIVE f AS (SELECT 1 AS n UNION ALL SELECT n + 1 FROM f WHERE n < 6),
               r AS (SELECT 1 AS n UNION ALL SELECT n + 1 FROM r WHERE n < 6)
SELECT b.id, CONCAT(f.n, LPAD(r.n, 2, '0')), f.n, 6, 0, 0
FROM building b CROSS JOIN f CROSS JOIN r
ORDER BY b.id, f.n, r.n;

-- ---------------------------------------------------------------------
-- 4. 学生：180 人，前 30 间宿舍住满（每间 6 人）
-- ---------------------------------------------------------------------
INSERT INTO student (student_no, name, gender, class_name, phone, status)
WITH RECURSIVE s AS (SELECT 1 AS n UNION ALL SELECT n + 1 FROM s WHERE n < 180)
SELECT CONCAT('2023', LPAD(n, 4, '0')),
       CONCAT(ELT(1 + (n % 20), '张','王','李','赵','刘','陈','杨','黄','周','吴',
                                 '徐','孙','马','朱','胡','郭','何','高','林','罗'),
              ELT(1 + ((n * 7) % 20), '伟','芳','娜','敏','静','丽','强','磊','军','洋',
                                       '勇','艳','杰','娟','涛','明','超','秀英','霞','平')),
       IF(n % 2 = 1, 1, 0),
       CONCAT('计算机', 2301 + ((n - 1) % 4)),
       CONCAT('138', LPAD(n, 8, '0')),
       2
FROM s ORDER BY n;

-- 为学生生成登录账号（账号=学号，密码 123456）
INSERT INTO sys_user (username, password, real_name, role, phone, status)
SELECT student_no, @pwd, name, 'STUDENT', phone, 1 FROM student;

UPDATE student s JOIN sys_user u ON u.username = s.student_no
SET s.user_id = u.id;

-- 分配宿舍：学生 id 连续，每 6 人一间；按间隔挑选宿舍，使三栋楼都有入住数据
UPDATE student s
JOIN (SELECT id, ROW_NUMBER() OVER (ORDER BY id) AS rn FROM dormitory) d
  ON d.rn = 1 + FLOOR((s.id - 1) / 6) * 3
SET s.dormitory_id = d.id,
    s.bed_no      = ((s.id - 1) % 6) + 1,
    s.status      = 1;

-- 回填宿舍已住人数
UPDATE dormitory d
JOIN (SELECT dormitory_id, COUNT(*) AS c FROM student
      WHERE dormitory_id IS NOT NULL AND status = 1 GROUP BY dormitory_id) t
  ON t.dormitory_id = d.id
SET d.occupied = t.c,
    d.status   = IF(t.c >= d.capacity, 1, 0);

-- ---------------------------------------------------------------------
-- 5. 报修数据
-- ---------------------------------------------------------------------
INSERT INTO repair (student_id, dormitory_id, type, description, status, handler_id, result, create_time, dispatch_time, finish_time) VALUES
( 1, 1, '水电', '卫生间水龙头关不紧，一直滴水，夜里声音很大', 2, 2, '已更换水龙头阀芯，测试无渗漏', NOW() - INTERVAL 12 DAY, NOW() - INTERVAL 12 DAY, NOW() - INTERVAL 11 DAY),
( 3, 1, '门窗', '阳台推拉门滑轨损坏，门推不动', 2, 2, '更换滑轨并加润滑油', NOW() - INTERVAL 10 DAY, NOW() - INTERVAL 10 DAY, NOW() - INTERVAL 9 DAY),
( 7, 2, '网络', '宿舍网口不通，换了网线也不行', 1, 2, NULL, NOW() - INTERVAL 3 DAY, NOW() - INTERVAL 3 DAY, NULL),
( 8, 2, '家具', '书桌抽屉滑轨断裂，抽屉无法使用', 0, NULL, NULL, NOW() - INTERVAL 2 DAY, NULL, NULL),
(13, 3, '水电', '空调不制冷，出风口有异味', 1, 3, NULL, NOW() - INTERVAL 5 DAY, NOW() - INTERVAL 4 DAY, NULL),
(14, 3, '其他', '门锁反锁后从外面打不开，需要帮忙处理', 2, 3, '更换锁芯，已交付两把新钥匙', NOW() - INTERVAL 8 DAY, NOW() - INTERVAL 8 DAY, NOW() - INTERVAL 8 DAY),
(19, 4, '水电', '洗手池下水道堵塞，排水很慢', 0, NULL, NULL, NOW() - INTERVAL 1 DAY, NULL, NULL),
(21, 4, '家具', '衣柜门合页松动，柜门关不上', 2, 2, '重新固定合页并加固螺丝', NOW() - INTERVAL 15 DAY, NOW() - INTERVAL 15 DAY, NOW() - INTERVAL 14 DAY),
(25, 5, '网络', '宿舍 WiFi 信号弱，靠阳台一侧几乎断网', 1, 4, NULL, NOW() - INTERVAL 6 DAY, NOW() - INTERVAL 5 DAY, NULL),
(31, 6, '门窗', '窗户把手坏了，关窗不严', 0, NULL, NULL, NOW() - INTERVAL 4 HOUR, NULL, NULL),
(37, 7, '水电', '热水器指示灯不亮，怀疑跳闸', 2, 3, '更换漏电保护插头', NOW() - INTERVAL 20 DAY, NOW() - INTERVAL 20 DAY, NOW() - INTERVAL 19 DAY),
(43, 8, '其他', '床板有异响，翻身时声音很大', 3, NULL, '学生自行垫平，取消报修', NOW() - INTERVAL 7 DAY, NULL, NULL),
(49, 9, '家具', '椅子腿断裂，存在安全隐患', 1, 4, NULL, NOW() - INTERVAL 5 HOUR, NOW() - INTERVAL 4 HOUR, NULL),
(55, 10,'水电', '走廊公共照明灯不亮（本层西侧）', 2, 2, '更换 LED 灯管两支', NOW() - INTERVAL 9 DAY, NOW() - INTERVAL 9 DAY, NOW() - INTERVAL 9 DAY),
(61, 11,'网络', '路由器频繁掉线，重启后恢复几分钟', 0, NULL, NULL, NOW() - INTERVAL 30 MINUTE, NULL, NULL);

-- ---------------------------------------------------------------------
-- 6. 访客登记
-- ---------------------------------------------------------------------
INSERT INTO visitor (name, id_card, phone, dormitory_id, student_id, visit_time, leave_time, status, registrar_id, remark) VALUES
('刘洋',   '320102199801011234', '13701234567', 1,  1,  NOW() - INTERVAL 2 DAY, NOW() - INTERVAL 2 DAY + INTERVAL 2 HOUR, 1, 2, '学生表哥，送生活用品'),
('陈静',   '320102199905052345', '13701234568', 7,  7,  NOW() - INTERVAL 1 DAY, NOW() - INTERVAL 1 DAY + INTERVAL 90 MINUTE, 1, 2, '家长来访'),
('王芳',   '320102197503033456', '13701234569', 13, 13, NOW() - INTERVAL 3 HOUR, NULL, 0, 3, '母亲，送冬衣'),
('赵敏',   '320102200001014567', '13701234570', 19, 19, NOW() - INTERVAL 1 HOUR, NULL, 0, 2, '同学借书'),
('孙浩',   '320102199707075678', '13701234571', 25, 25, NOW() - INTERVAL 5 DAY, NOW() - INTERVAL 5 DAY + INTERVAL 3 HOUR, 1, 4, '高中同学'),
('周琳',   '320102199808086789', '13701234572', 31, 31, NOW() - INTERVAL 45 MINUTE, NULL, 0, 3, '送快递（大件）'),
('吴磊',   '320102199610107890', '13701234573', 37, 37, NOW() - INTERVAL 4 DAY, NOW() - INTERVAL 4 DAY + INTERVAL 1 HOUR, 1, 2, '维修师傅（已登记）'),
('郑爽',   '320102200202028901', '13701234574', 43, 43, NOW() - INTERVAL 20 MINUTE, NULL, 0, 4, '社团同学');

-- ---------------------------------------------------------------------
-- 7. 公告
-- ---------------------------------------------------------------------
INSERT INTO notice (title, content, publisher_id, status, create_time) VALUES
('关于开展 2026 年冬季宿舍安全大检查的通知',
 '各位同学：\n为消除宿舍安全隐患，学校定于 11 月 15 日至 11 月 20 日开展冬季宿舍安全大检查，重点检查违规电器、私拉电线、消防通道堵塞等问题。请各宿舍提前自查并配合检查。\n特此通知。',
 1, 1, NOW() - INTERVAL 2 DAY),
('宿舍水电费缴纳提醒（11 月账期）',
 '11 月水电费已生成，请各宿舍于 11 月 25 日前完成缴纳。逾期未缴将暂停宿舍用电充值服务。\n缴费方式：企业微信 — 生活服务 — 宿舍缴费。',
 1, 1, NOW() - INTERVAL 4 DAY),
('关于宿舍楼门禁时间调整的通知',
 '自 11 月 10 日起，各宿舍楼门禁时间调整为 23:30，晚归学生须在宿管处登记。请同学们合理安排作息。',
 1, 1, NOW() - INTERVAL 7 DAY),
('A 栋 3 层停水通知',
 '因管道检修，A 栋 3 层将于 11 月 12 日 09:00—17:00 停水，请提前储水。',
 2, 1, NOW() - INTERVAL 1 DAY),
('失物招领：图书馆拾到校园卡一张',
 '有同学在图书馆三楼拾到校园卡一张（姓名：李*），请失主到 A 栋宿管室认领。',
 2, 1, NOW() - INTERVAL 3 DAY),
('宿舍文化节活动报名开始',
 '第十届宿舍文化节开始报名，活动包括寝室美化大赛、宿舍风采展示、趣味运动会，报名截止 11 月 20 日。',
 1, 1, NOW() - INTERVAL 6 DAY);

-- ---------------------------------------------------------------------
-- 8. 卫生检查记录
-- ---------------------------------------------------------------------
INSERT INTO sanitary (dormitory_id, score, check_date, remark, checker_id)
WITH RECURSIVE s AS (SELECT 1 AS n UNION ALL SELECT n + 1 FROM s WHERE n < 30)
SELECT n,
       70 + (n * 7) % 30,
       CURDATE() - INTERVAL ((n * 3) % 20) DAY,
       ELT(1 + (n % 5), '地面整洁，物品摆放规范', '阳台有杂物，已提醒整理', '卫生间有待加强', '整体良好', '床铺不整齐'),
       2
FROM s;

-- ---------------------------------------------------------------------
-- 9. 违纪记录
-- ---------------------------------------------------------------------
INSERT INTO violation (student_id, type, description, points, record_date, recorder_id) VALUES
( 5, '违规电器', '使用大功率电吹风（1800W）', 5, CURDATE() - INTERVAL 12 DAY, 2),
(11, '晚归',     '23:50 后返回宿舍，未提前报备', 2, CURDATE() - INTERVAL 9 DAY, 2),
(17, '卫生',     '宿舍卫生检查不合格，限期整改', 3, CURDATE() - INTERVAL 8 DAY, 3),
(23, '吸烟',     '在宿舍楼道吸烟', 5, CURDATE() - INTERVAL 6 DAY, 2),
(29, '违规电器', '使用电煮锅', 5, CURDATE() - INTERVAL 5 DAY, 3),
(35, '夜不归宿', '未请假夜不归宿', 8, CURDATE() - INTERVAL 4 DAY, 4),
(41, '卫生',     '垃圾长期堆放门口', 3, CURDATE() - INTERVAL 3 DAY, 2),
(47, '晚归',     '门禁后翻越围栏进入', 10, CURDATE() - INTERVAL 2 DAY, 4),
(53, '其他',     '在宿舍饲养宠物', 5, CURDATE() - INTERVAL 1 DAY, 3);

-- ---------------------------------------------------------------------
-- 10. 水电费（前 24 间宿舍，近 3 个月）
-- ---------------------------------------------------------------------
INSERT INTO water_electric (dormitory_id, bill_month, water_usage, water_fee, electric_usage, electric_fee, total_fee, paid, pay_time)
WITH RECURSIVE s AS (SELECT 1 AS n UNION ALL SELECT n + 1 FROM s WHERE n < 24),
               m AS (SELECT 0 AS k UNION ALL SELECT k + 1 FROM m WHERE k < 2)
SELECT s.n,
       DATE_FORMAT(CURDATE() - INTERVAL m.k MONTH, '%Y-%m'),
       ROUND(6 + (s.n * 3 + m.k * 5) % 15, 1),
       ROUND((6 + (s.n * 3 + m.k * 5) % 15) * 3.5, 2),
       ROUND(80 + (s.n * 17 + m.k * 23) % 120, 1),
       ROUND((80 + (s.n * 17 + m.k * 23) % 120) * 0.55, 2),
       ROUND((6 + (s.n * 3 + m.k * 5) % 15) * 3.5 + (80 + (s.n * 17 + m.k * 23) % 120) * 0.55, 2),
       IF(m.k = 0, IF(s.n % 3 = 0, 1, 0), 1),
       IF(m.k = 0, IF(s.n % 3 = 0, NOW() - INTERVAL 2 DAY, NULL), NOW() - INTERVAL (m.k * 30 + 2) DAY)
FROM s CROSS JOIN m
ORDER BY s.n, m.k;

-- ---------------------------------------------------------------------
-- 11. 调宿申请
-- ---------------------------------------------------------------------
INSERT INTO adjust_request (student_id, from_dormitory_id, to_dormitory_id, reason, status, approver_id, approve_remark, create_time, approve_time) VALUES
(2,  1,  31, '与原宿舍同学生活习惯差异较大，申请调至同班同学宿舍', 1, 1, '同意调宿，已安排 31 栋床位', NOW() - INTERVAL 10 DAY, NOW() - INTERVAL 9 DAY),
(20, 4,  45, '因身体原因需要下铺，申请调整', 0, NULL, NULL, NOW() - INTERVAL 1 DAY, NULL),
(38, 7,  50, '宿舍靠近楼梯口噪音较大，影响休息', 2, 1, '目标宿舍已满员，建议下学期再申请', NOW() - INTERVAL 6 DAY, NOW() - INTERVAL 5 DAY),
(56, 10, 60, '参加实验室项目，需要调至同项目同学宿舍', 0, NULL, NULL, NOW() - INTERVAL 3 HOUR, NULL);

-- 注意：第 2 条调宿申请为演示数据，未真正改动学生宿舍，保持数据自洽
