﻿# -*- coding: utf-8 -*-
<#
把项目打成若干个小于 25MB 的文件，方便通过 GitHub 网页上传。

用法（在项目根目录）：
    powershell -ExecutionPolicy Bypass -File scripts\package-github.ps1

产物在 dist-packages\ 下：
    dorm-management-src.zip     完整源码（推荐上传这个）
    dorm-backend-src.zip        只含后端源码
    dorm-frontend-src.zip       只含前端源码
    dorm-docs-sql.zip           文档 + SQL + 脚本
    runnable\                   可运行版本（jar 分卷 + 合并脚本，每卷 < 25MB）

所有包都会排除 node_modules、target、dist、.git、.idea、日志等大目录/文件。
#>
$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$out = Join-Path $root 'dist-packages'
$stage = Join-Path $out '.stage'

if (Test-Path $out) { Remove-Item $out -Recurse -Force }
New-Item -ItemType Directory -Path $out -Force | Out-Null
New-Item -ItemType Directory -Path $stage -Force | Out-Null

$excludeDirs = @('node_modules', 'target', 'dist', '.git', '.idea', 'dist-packages', 'logs')
$excludeFiles = @('*.log', '*.tmp')

function Invoke-Robocopy {
    param([string]$Source, [string]$Target)
    $rcArgs = @($Source, $Target, '/E', '/NFL', '/NDL', '/NJH', '/NJS', '/NP', '/R:1', '/W:1')
    $rcArgs += '/XD'; $rcArgs += $excludeDirs
    $rcArgs += '/XF'; $rcArgs += $excludeFiles
    robocopy @rcArgs | Out-Null
    if ($LASTEXITCODE -ge 8) { throw "robocopy failed: $Source -> $Target (exit $LASTEXITCODE)" }
}

function New-Package {
    param([string]$Name, [string]$SourceDir)
    $zip = Join-Path $out $Name
    Compress-Archive -Path $SourceDir -DestinationPath $zip -CompressionLevel Optimal -Force
    $size = (Get-Item $zip).Length / 1MB
    if ($size -ge 25) { throw "package too large: $Name = $([math]::Round($size,2)) MB" }
}

Write-Host 'Staging files (excluding node_modules / target / dist / .idea) ...'

$full = Join-Path $stage 'dorm-management'
Invoke-Robocopy -Source $root -Target $full

$be = Join-Path $stage 'dorm-management-backend'
Invoke-Robocopy -Source (Join-Path $root 'backend') -Target $be

$fe = Join-Path $stage 'dorm-management-frontend'
Invoke-Robocopy -Source (Join-Path $root 'frontend') -Target $fe

$ds = Join-Path $stage 'dorm-management-docs'
New-Item -ItemType Directory -Path $ds -Force | Out-Null
Invoke-Robocopy -Source (Join-Path $root 'docs') -Target (Join-Path $ds 'docs')
Invoke-Robocopy -Source (Join-Path $root 'sql') -Target (Join-Path $ds 'sql')
Invoke-Robocopy -Source (Join-Path $root 'scripts') -Target (Join-Path $ds 'scripts')
Copy-Item (Join-Path $root 'README.md') $ds -Force
Copy-Item (Join-Path $root '.gitignore') $ds -Force

Write-Host 'Packing source archives ...'
New-Package -Name 'dorm-management-src.zip' -SourceDir $full
New-Package -Name 'dorm-backend-src.zip' -SourceDir $be
New-Package -Name 'dorm-frontend-src.zip' -SourceDir $fe
New-Package -Name 'dorm-docs-sql.zip' -SourceDir $ds

# ---------- 可运行版本：jar 分卷，每卷 16MB ----------
$jar = Join-Path $root 'backend\target\dorm-management.jar'
$runDir = Join-Path $out 'runnable'
if (Test-Path $jar) {
    Write-Host 'Splitting runnable jar into 16 MB parts ...'
    New-Item -ItemType Directory -Path $runDir -Force | Out-Null
    $bytes = [IO.File]::ReadAllBytes($jar)
    $chunk = 16MB
    $parts = [math]::Ceiling($bytes.Length / $chunk)
    $names = @()
    for ($i = 0; $i -lt $parts; $i++) {
        $start = $i * $chunk
        $len = [math]::Min($chunk, $bytes.Length - $start)
        $buf = New-Object byte[] $len
        [Array]::Copy($bytes, $start, $buf, 0, $len)
        $name = 'dorm-management.jar.part{0:D2}' -f ($i + 1)
        [IO.File]::WriteAllBytes((Join-Path $runDir $name), $buf)
        $names += $name
    }

    $copyLine = 'copy /b ' + ($names -join ' + ') + ' dorm-management.jar >nul'
    $bat = @"
@echo off
chcp 65001 >nul
title Dorm Management - runnable
cd /d "%~dp0"
echo Merging jar parts ...
$copyLine
if errorlevel 1 (
    echo Merge failed. Make sure all part files are in this folder.
    pause
    exit /b 1
)
echo Starting backend on http://127.0.0.1:8080 ...
java "-Dfile.encoding=UTF-8" "-Duser.timezone=Asia/Shanghai" -jar dorm-management.jar
pause
"@
    [IO.File]::WriteAllText((Join-Path $runDir 'join-and-run.bat'), $bat, [Text.Encoding]::GetEncoding(936))
    Copy-Item (Join-Path $root 'backend\src\main\resources\application.yml') (Join-Path $runDir 'application.yml') -Force

    # 校验：合并后的 SHA256 必须与原 jar 一致
    $tmpJar = Join-Path $runDir '.verify.jar'
    $fs = [IO.File]::Create($tmpJar)
    foreach ($n in $names) {
        $b = [IO.File]::ReadAllBytes((Join-Path $runDir $n))
        $fs.Write($b, 0, $b.Length)
    }
    $fs.Close()
    $h1 = (Get-FileHash $jar -Algorithm SHA256).Hash
    $h2 = (Get-FileHash $tmpJar -Algorithm SHA256).Hash
    Remove-Item $tmpJar -Force
    if ($h1 -ne $h2) { throw 'jar split verification FAILED' }
    Write-Host ('  jar split OK ({0} parts, sha256 matches)' -f $parts)
} else {
    Write-Host 'WARN: backend\target\dorm-management.jar not found, skip runnable package.'
}

Remove-Item $stage -Recurse -Force

Write-Host ''
Write-Host 'Result (every file < 25 MB):'
Get-ChildItem $out -Recurse -File | Where-Object { $_.Name -ne 'application.yml' } |
    Sort-Object FullName | ForEach-Object {
        $rel = $_.FullName.Substring($out.Length + 1)
        "{0,-42} {1,7:N2} MB" -f $rel, ($_.Length / 1MB)
    }
