@echo off
chcp 65001 >nul
title 宿舍管理系统 - 前端
cd /d "%~dp0..\frontend"

if not exist "node_modules" (
    echo 未检测到 node_modules，正在安装依赖...
    call npm install
    if errorlevel 1 (
        echo 依赖安装失败。
        pause
        exit /b 1
    )
)

echo 启动前端开发服务器 http://127.0.0.1:5173 ...
call npm run dev
pause
