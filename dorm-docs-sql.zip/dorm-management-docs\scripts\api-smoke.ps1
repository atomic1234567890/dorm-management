﻿# =====================================================================
# 接口冒烟测试脚本（Windows PowerShell）
# 用法：powershell -ExecutionPolicy Bypass -File scripts\api-smoke.ps1
# 前置：后端已启动在 http://127.0.0.1:8080，数据库已导入 schema.sql + data.sql
# =====================================================================
$ErrorActionPreference = 'Stop'
$Base = 'http://127.0.0.1:8080'
$script:pass = 0
$script:fail = 0

function Login($username, $password) {
    $body = @{ username = $username; password = $password } | ConvertTo-Json
    $r = Invoke-RestMethod -Uri "$Base/api/auth/login" -Method Post `
        -ContentType 'application/json; charset=utf-8' `
        -Body ([Text.Encoding]::UTF8.GetBytes($body))
    return $r.data.token
}

function Call($name, $method, $path, $token, $body = $null, $expect = 200) {
    $headers = @{ Authorization = "Bearer $token" }
    $req = @{ Uri = "$Base$path"; Method = $method; Headers = $headers; TimeoutSec = 20 }
    if ($body -ne $null) {
        $json = $body | ConvertTo-Json -Depth 5
        $req.ContentType = 'application/json; charset=utf-8'
        $req.Body = [Text.Encoding]::UTF8.GetBytes($json)
    }
    try {
        $r = Invoke-RestMethod @req
        $code = $r.code
        $msg = $r.msg
        $extra = ''
        if ($r.data -is [System.Management.Automation.PSCustomObject]) {
            if ($r.data.total -ne $null) { $extra = " total=$($r.data.total)" }
        } elseif ($r.data -is [array]) {
            $extra = " count=$($r.data.Count)"
        }
        $ok = if ($expect -is [array]) { $expect -contains $code } else { $code -eq $expect }
        if ($ok) { $script:pass++ } else { $script:fail++ }
        $flag = if ($ok) { 'PASS' } else { 'FAIL' }
        Write-Host ("[{0}] {1,-28} {2} {3}{4}" -f $flag, $name, $code, $msg, $extra)
        return $r
    } catch {
        $script:fail++
        Write-Host ("[FAIL] {0,-28} {1}" -f $name, $_.Exception.Message)
        return $null
    }
}

Write-Host '=== 1. 登录三种角色 ===' -ForegroundColor Cyan
$admin = Login 'admin' '123456'
$manager = Login 'manager01' '123456'
$student = Login '20230001' '123456'
Write-Host "admin token len=$($admin.Length), manager token len=$($manager.Length), student token len=$($student.Length)"

Write-Host '=== 2. 管理员接口 ===' -ForegroundColor Cyan
$dash = Call '看板统计' GET '/api/dashboard/stats' $admin
if ($dash) {
    Write-Host ("       床位 {0} / 已住 {1} / 入住率 {2}% / 待报修 {3} / 在访 {4}" -f `
        $dash.data.bedCount, $dash.data.occupiedCount, $dash.data.occupancyRate, `
        $dash.data.pendingRepair, $dash.data.visiting)
}
Call '楼栋列表' GET '/api/buildings?page=1&size=10' $admin | Out-Null
Call '宿舍列表' GET '/api/dormitories?page=1&size=5' $admin | Out-Null
Call '学生列表' GET '/api/students?page=1&size=5' $admin | Out-Null
Call '报修列表' GET '/api/repairs?page=1&size=5' $admin | Out-Null
Call '访客列表' GET '/api/visitors?page=1&size=5' $admin | Out-Null
Call '公告列表' GET '/api/notices?page=1&size=5' $admin | Out-Null
Call '卫生记录' GET '/api/sanitary?page=1&size=5' $admin | Out-Null
Call '违纪记录' GET '/api/violations?page=1&size=5' $admin | Out-Null
Call '水电费' GET '/api/water-electric?page=1&size=5' $admin | Out-Null
Call '调宿申请' GET '/api/adjust-requests?page=1&size=5' $admin | Out-Null
Call '账号列表' GET '/api/users?page=1&size=5' $admin | Out-Null

Write-Host '=== 3. 学生端接口 ===' -ForegroundColor Cyan
Call '我的宿舍' GET '/api/students/my' $student | Out-Null
$repairs = Call '我的报修' GET '/api/repairs?page=1&size=5' $student
Call '公告(学生)' GET '/api/notices?page=1&size=5' $student | Out-Null
Call '提交报修' POST '/api/repairs' $student @{ type = '网络'; description = '冒烟测试：宿舍网口松动' } | Out-Null
Call '我的水电费' GET '/api/water-electric?page=1&size=5' $student | Out-Null
# 允许两种结果：首次提交成功；重复运行被"待审批"规则拦截，均视为通过
$adj = Call '申请调宿' POST '/api/adjust-requests' $student @{ toDormitoryId = 31; reason = '冒烟测试：申请调宿' } 200,400
if ($adj -and $adj.code -eq 400 -and $adj.msg -match '待审批') {
    Write-Host '       已存在待审批申请，重复提交被正确拦截' -ForegroundColor Yellow
}

Write-Host '=== 4. 权限校验 ===' -ForegroundColor Cyan
$deny = Call '学生访问账号管理(应403)' GET '/api/users?page=1&size=5' $student $null 403
if ($deny -and $deny.code -eq 403) {
    Write-Host '       权限拦截正常：返回 403' -ForegroundColor Green
}
$noToken = $null
try {
    $noToken = Invoke-RestMethod -Uri "$Base/api/students?page=1&size=5" -TimeoutSec 10
} catch { }
if ($noToken -and $noToken.code -eq 401) {
    Write-Host '       未登录拦截正常：返回 401' -ForegroundColor Green
} else {
    Write-Host '       [WARN] 未登录请求未返回 401' -ForegroundColor Yellow
}

Write-Host '=== 5. 宿管端接口 ===' -ForegroundColor Cyan
$mdash = Call '宿管看板' GET '/api/dashboard/stats' $manager
if ($mdash) {
    Write-Host ("       宿管可见床位 {0}（应为 A 栋 216）" -f $mdash.data.bedCount)
}
Call '宿管查学生' GET '/api/students?page=1&size=5' $manager | Out-Null
Call '宿管查访客' GET '/api/visitors?page=1&size=5' $manager | Out-Null
Call '宿管查报修' GET '/api/repairs?page=1&size=5' $manager | Out-Null

Write-Host ''
Write-Host ("=== 结果：通过 {0}，失败 {1} ===" -f $script:pass, $script:fail) -ForegroundColor Cyan
if ($script:fail -gt 0) { exit 1 }
