/**
 * 生产构建预览服务器：托管 frontend/dist，并把 /api 反向代理到后端 8080。
 * 仅依赖 Node 内置模块，用于课程设计演示或没有 Nginx 的环境。
 *
 * 用法：node scripts/serve-dist.cjs [port] [backend]
 *   node scripts/serve-dist.cjs 5173 http://127.0.0.1:8080
 */
const http = require('http')
const fs = require('fs')
const path = require('path')

const port = Number(process.argv[2] || 5173)
const backend = new URL(process.argv[3] || 'http://127.0.0.1:8080')
const root = path.resolve(__dirname, '..', 'frontend', 'dist')

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf'
}

function proxy (req, res) {
  const options = {
    hostname: backend.hostname,
    port: backend.port,
    path: req.url,
    method: req.method,
    headers: { ...req.headers, host: backend.host }
  }
  const upstream = http.request(options, (up) => {
    res.writeHead(up.statusCode, up.headers)
    up.pipe(res)
  })
  upstream.on('error', (err) => {
    res.writeHead(502, { 'Content-Type': 'application/json; charset=utf-8' })
    res.end(JSON.stringify({ code: 502, msg: '后端服务不可用：' + err.message }))
  })
  req.pipe(upstream)
}

const server = http.createServer((req, res) => {
  if (req.url.startsWith('/api')) {
    proxy(req, res)
    return
  }
  const urlPath = decodeURIComponent(req.url.split('?')[0])
  let filePath = path.join(root, urlPath === '/' ? 'index.html' : urlPath)
  if (!filePath.startsWith(root)) {
    res.writeHead(403)
    res.end('Forbidden')
    return
  }
  fs.stat(filePath, (err, stat) => {
    if (err || !stat.isFile()) {
      filePath = path.join(root, 'index.html')
    }
    fs.readFile(filePath, (readErr, data) => {
      if (readErr) {
        res.writeHead(404)
        res.end('Not Found')
        return
      }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(filePath)] || 'application/octet-stream' })
      res.end(data)
    })
  })
})

server.listen(port, '127.0.0.1', () => {
  console.log(`宿舍管理系统已启动： http://127.0.0.1:${port}  (静态目录: ${root}, 后端: ${backend.origin})`)
})
