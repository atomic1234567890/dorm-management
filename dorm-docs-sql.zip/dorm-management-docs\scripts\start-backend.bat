@echo off
chcp 65001 >nul
title 宿舍管理系统 - 后端
cd /d "%~dp0..\backend"

if not exist "target\dorm-management.jar" (
    echo [1/2] 未找到 jar，开始打包...
    call mvn clean package -DskipTests
    if errorlevel 1 (
        echo 打包失败，请检查 Maven 与 JDK 配置。
        pause
        exit /b 1
    )
)

echo [2/2] 启动后端 http://127.0.0.1:8080 ...
java "-Dfile.encoding=UTF-8" "-Duser.timezone=Asia/Shanghai" -jar target\dorm-management.jar
pause
