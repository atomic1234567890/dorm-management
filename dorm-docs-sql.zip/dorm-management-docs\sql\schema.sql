-- =====================================================================
-- 宿舍管理系统 数据库脚本（MySQL 8.0+）
-- 数据库：dorm_db    字符集：utf8mb4    引擎：InnoDB
-- 说明：先执行本脚本建库建表，再执行 data.sql 导入初始化数据
-- =====================================================================

DROP DATABASE IF EXISTS dorm_db;
CREATE DATABASE dorm_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE dorm_db;

-- ---------------------------------------------------------------------
-- 1. 用户表：管理员 / 宿管 / 学生 统一登录入口
-- ---------------------------------------------------------------------
CREATE TABLE sys_user (
    id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    username    VARCHAR(50)  NOT NULL COMMENT '登录账号（学生为学号）',
    password    VARCHAR(100) NOT NULL COMMENT 'BCrypt 加密后的密码',
    real_name   VARCHAR(50)  NOT NULL COMMENT '真实姓名',
    role        VARCHAR(20)  NOT NULL COMMENT '角色：ADMIN 管理员 / MANAGER 宿管 / STUDENT 学生',
    phone       VARCHAR(20)  DEFAULT NULL COMMENT '手机号',
    status      TINYINT      NOT NULL DEFAULT 1 COMMENT '状态：1 启用 / 0 禁用',
    create_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    update_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
    PRIMARY KEY (id),
    UNIQUE KEY uk_username (username),
    KEY idx_role (role)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '用户表';

-- ---------------------------------------------------------------------
-- 2. 楼栋表
-- ---------------------------------------------------------------------
CREATE TABLE building (
    id          BIGINT      NOT NULL AUTO_INCREMENT COMMENT '主键',
    code        VARCHAR(20) NOT NULL COMMENT '楼栋编号，如 A/B/C',
    name        VARCHAR(50) NOT NULL COMMENT '楼栋名称',
    manager_id  BIGINT      DEFAULT NULL COMMENT '负责宿管（sys_user.id）',
    floors      INT         NOT NULL DEFAULT 6 COMMENT '楼层数',
    remark      VARCHAR(255) DEFAULT NULL COMMENT '备注',
    create_time DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_building_code (code),
    KEY idx_building_manager (manager_id),
    CONSTRAINT fk_building_manager FOREIGN KEY (manager_id) REFERENCES sys_user (id) ON DELETE SET NULL
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '楼栋表';

-- ---------------------------------------------------------------------
-- 3. 宿舍表
-- ---------------------------------------------------------------------
CREATE TABLE dormitory (
    id          BIGINT      NOT NULL AUTO_INCREMENT COMMENT '主键',
    building_id BIGINT      NOT NULL COMMENT '所属楼栋',
    room_no     VARCHAR(20) NOT NULL COMMENT '宿舍号，如 101',
    floor       INT         NOT NULL COMMENT '所在楼层',
    capacity    INT         NOT NULL DEFAULT 6 COMMENT '最大入住人数',
    occupied    INT         NOT NULL DEFAULT 0 COMMENT '已住人数（由学生入住/退宿维护）',
    status      TINYINT     NOT NULL DEFAULT 0 COMMENT '状态：0 正常 / 1 满员 / 2 维修中',
    remark      VARCHAR(255) DEFAULT NULL,
    create_time DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_building_room (building_id, room_no),
    KEY idx_dorm_building (building_id),
    CONSTRAINT fk_dorm_building FOREIGN KEY (building_id) REFERENCES building (id) ON DELETE RESTRICT
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '宿舍表';

-- ---------------------------------------------------------------------
-- 4. 学生表
-- ---------------------------------------------------------------------
CREATE TABLE student (
    id           BIGINT      NOT NULL AUTO_INCREMENT COMMENT '主键',
    user_id      BIGINT      DEFAULT NULL COMMENT '关联登录账号',
    student_no   VARCHAR(30) NOT NULL COMMENT '学号',
    name         VARCHAR(50) NOT NULL COMMENT '姓名',
    gender       TINYINT     NOT NULL DEFAULT 1 COMMENT '性别：1 男 / 0 女',
    class_name   VARCHAR(50) DEFAULT NULL COMMENT '班级',
    phone        VARCHAR(20) DEFAULT NULL COMMENT '联系方式',
    dormitory_id BIGINT      DEFAULT NULL COMMENT '所住宿舍，NULL 表示未分配',
    bed_no       INT         DEFAULT NULL COMMENT '床位号',
    status       TINYINT     NOT NULL DEFAULT 1 COMMENT '状态：1 在住 / 0 退宿 / 2 待分配',
    create_time  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_student_no (student_no),
    UNIQUE KEY uk_student_user (user_id),
    KEY idx_student_dorm (dormitory_id),
    CONSTRAINT fk_student_user FOREIGN KEY (user_id) REFERENCES sys_user (id) ON DELETE SET NULL,
    CONSTRAINT fk_student_dorm FOREIGN KEY (dormitory_id) REFERENCES dormitory (id) ON DELETE SET NULL
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '学生表';

-- ---------------------------------------------------------------------
-- 5. 报修表
-- ---------------------------------------------------------------------
CREATE TABLE repair (
    id            BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    student_id    BIGINT       NOT NULL COMMENT '报修学生',
    dormitory_id  BIGINT       NOT NULL COMMENT '报修宿舍',
    type          VARCHAR(20)  NOT NULL COMMENT '报修类型：水电/门窗/家具/网络/其他',
    description   VARCHAR(500) NOT NULL COMMENT '问题描述',
    images        VARCHAR(1000) DEFAULT NULL COMMENT '图片地址，逗号分隔',
    status        TINYINT      NOT NULL DEFAULT 0 COMMENT '状态：0 待派单 / 1 维修中 / 2 已完成 / 3 已取消',
    handler_id    BIGINT       DEFAULT NULL COMMENT '维修人（宿管/管理员）',
    result        VARCHAR(500) DEFAULT NULL COMMENT '处理结果',
    create_time   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '报修时间',
    dispatch_time DATETIME     DEFAULT NULL COMMENT '派单时间',
    finish_time   DATETIME     DEFAULT NULL COMMENT '完成时间',
    update_time   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_repair_student (student_id),
    KEY idx_repair_status (status),
    CONSTRAINT fk_repair_student FOREIGN KEY (student_id) REFERENCES student (id) ON DELETE CASCADE,
    CONSTRAINT fk_repair_dorm FOREIGN KEY (dormitory_id) REFERENCES dormitory (id) ON DELETE CASCADE,
    CONSTRAINT fk_repair_handler FOREIGN KEY (handler_id) REFERENCES sys_user (id) ON DELETE SET NULL
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '报修表';

-- ---------------------------------------------------------------------
-- 6. 访客登记表
-- ---------------------------------------------------------------------
CREATE TABLE visitor (
    id           BIGINT      NOT NULL AUTO_INCREMENT COMMENT '主键',
    name         VARCHAR(50) NOT NULL COMMENT '访客姓名',
    id_card      VARCHAR(20) DEFAULT NULL COMMENT '身份证号',
    phone        VARCHAR(20) DEFAULT NULL COMMENT '联系电话',
    dormitory_id BIGINT      NOT NULL COMMENT '来访宿舍',
    student_id   BIGINT      DEFAULT NULL COMMENT '被访学生',
    visit_time   DATETIME    NOT NULL COMMENT '来访时间',
    leave_time   DATETIME    DEFAULT NULL COMMENT '离开时间',
    status       TINYINT     NOT NULL DEFAULT 0 COMMENT '状态：0 在访 / 1 已离开',
    registrar_id BIGINT      DEFAULT NULL COMMENT '登记人',
    remark       VARCHAR(255) DEFAULT NULL,
    create_time  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_visitor_dorm (dormitory_id),
    KEY idx_visitor_status (status),
    CONSTRAINT fk_visitor_dorm FOREIGN KEY (dormitory_id) REFERENCES dormitory (id) ON DELETE CASCADE,
    CONSTRAINT fk_visitor_student FOREIGN KEY (student_id) REFERENCES student (id) ON DELETE SET NULL,
    CONSTRAINT fk_visitor_registrar FOREIGN KEY (registrar_id) REFERENCES sys_user (id) ON DELETE SET NULL
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '访客登记表';

-- ---------------------------------------------------------------------
-- 7. 公告表
-- ---------------------------------------------------------------------
CREATE TABLE notice (
    id           BIGINT      NOT NULL AUTO_INCREMENT COMMENT '主键',
    title        VARCHAR(100) NOT NULL COMMENT '标题',
    content      TEXT        NOT NULL COMMENT '正文',
    publisher_id BIGINT      DEFAULT NULL COMMENT '发布人',
    status       TINYINT     NOT NULL DEFAULT 1 COMMENT '状态：1 已发布 / 0 草稿',
    create_time  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_notice_time (create_time),
    CONSTRAINT fk_notice_publisher FOREIGN KEY (publisher_id) REFERENCES sys_user (id) ON DELETE SET NULL
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '公告表';

-- ---------------------------------------------------------------------
-- 8. 卫生检查记录
-- ---------------------------------------------------------------------
CREATE TABLE sanitary (
    id           BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    dormitory_id BIGINT       NOT NULL COMMENT '宿舍',
    score        INT          NOT NULL COMMENT '卫生得分 0-100',
    check_date   DATE         NOT NULL COMMENT '检查日期',
    remark       VARCHAR(255) DEFAULT NULL COMMENT '评语',
    checker_id   BIGINT       DEFAULT NULL COMMENT '检查人',
    create_time  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_sanitary_dorm (dormitory_id),
    CONSTRAINT fk_sanitary_dorm FOREIGN KEY (dormitory_id) REFERENCES dormitory (id) ON DELETE CASCADE,
    CONSTRAINT fk_sanitary_checker FOREIGN KEY (checker_id) REFERENCES sys_user (id) ON DELETE SET NULL
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '卫生检查表';

-- ---------------------------------------------------------------------
-- 9. 违纪记录
-- ---------------------------------------------------------------------
CREATE TABLE violation (
    id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    student_id  BIGINT       NOT NULL COMMENT '违纪学生',
    type        VARCHAR(30)  NOT NULL COMMENT '违纪类型',
    description VARCHAR(500) DEFAULT NULL COMMENT '情况说明',
    points      INT          NOT NULL DEFAULT 0 COMMENT '扣分',
    record_date DATE         NOT NULL COMMENT '记录日期',
    recorder_id BIGINT       DEFAULT NULL COMMENT '记录人',
    create_time DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_violation_student (student_id),
    CONSTRAINT fk_violation_student FOREIGN KEY (student_id) REFERENCES student (id) ON DELETE CASCADE,
    CONSTRAINT fk_violation_recorder FOREIGN KEY (recorder_id) REFERENCES sys_user (id) ON DELETE SET NULL
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '违纪记录表';

-- ---------------------------------------------------------------------
-- 10. 水电费表（按宿舍 + 月份唯一）
-- ---------------------------------------------------------------------
CREATE TABLE water_electric (
    id             BIGINT        NOT NULL AUTO_INCREMENT COMMENT '主键',
    dormitory_id   BIGINT        NOT NULL COMMENT '宿舍',
    bill_month     VARCHAR(7)    NOT NULL COMMENT '账期，格式 yyyy-MM',
    water_usage    DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT '用水量（吨）',
    water_fee      DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT '水费（元）',
    electric_usage DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT '用电量（度）',
    electric_fee   DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT '电费（元）',
    total_fee      DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT '合计金额（元）',
    paid           TINYINT       NOT NULL DEFAULT 0 COMMENT '缴费状态：0 未缴 / 1 已缴',
    pay_time       DATETIME      DEFAULT NULL COMMENT '缴费时间',
    create_time    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uk_dorm_month (dormitory_id, bill_month),
    CONSTRAINT fk_we_dorm FOREIGN KEY (dormitory_id) REFERENCES dormitory (id) ON DELETE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '水电费表';

-- ---------------------------------------------------------------------
-- 11. 调宿申请
-- ---------------------------------------------------------------------
CREATE TABLE adjust_request (
    id                 BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    student_id         BIGINT       NOT NULL COMMENT '申请学生',
    from_dormitory_id  BIGINT       DEFAULT NULL COMMENT '原宿舍',
    to_dormitory_id    BIGINT       DEFAULT NULL COMMENT '申请调入宿舍',
    reason             VARCHAR(500) NOT NULL COMMENT '申请理由',
    status             TINYINT      NOT NULL DEFAULT 0 COMMENT '状态：0 待审批 / 1 已通过 / 2 已驳回',
    approver_id        BIGINT       DEFAULT NULL COMMENT '审批人',
    approve_remark     VARCHAR(255) DEFAULT NULL COMMENT '审批意见',
    create_time        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    approve_time       DATETIME     DEFAULT NULL,
    PRIMARY KEY (id),
    KEY idx_adjust_student (student_id),
    KEY idx_adjust_status (status),
    CONSTRAINT fk_adjust_student FOREIGN KEY (student_id) REFERENCES student (id) ON DELETE CASCADE,
    CONSTRAINT fk_adjust_from FOREIGN KEY (from_dormitory_id) REFERENCES dormitory (id) ON DELETE SET NULL,
    CONSTRAINT fk_adjust_to FOREIGN KEY (to_dormitory_id) REFERENCES dormitory (id) ON DELETE SET NULL
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COMMENT = '调宿申请表';
